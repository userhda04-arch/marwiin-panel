if not LPH_OBFUSCATED then
-- ZiBtIGE=
    LPH_JIT = function(...) return ... end
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=
    LPH_JIT_MAX = function(...) return ... end
    LPH_JIT_ULTRA = function(...) return ... end
-- ZCBpIHMgYyBvIHIgZCAuIGdnIC8gZm1h
    LPH_NO_VIRTUALIZE = function(...) return ... end
    LPH_NO_UPVALUES = function(f) return(function(...) return f(...) end) end
    LPH_ENCFUNC = function(...) return ... end
    LPH_FUNCENC = function(...) return ... end
    LPH_ENCSTR = function(...) return ... end
    LPH_STRENC = function(...) return ... end
    LPH_ENCNUM = function(...) return ... end
    LPH_NUMENC = function(...) return ... end
    LPH_HOOK_FIX = function(...) return ... end
    LPH_CRASH = function() return print(debug.traceback()) end
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
end;

local WaveShield = {
    resourceName = GetCurrentResourceName(),
    playerSpawned = false,
    HeartbeatEventToken = GlobalState.HeartbeatEventToken,
    Config = GlobalState[GlobalState.CFct1C6gobnW4qkaQUx3Xk9Q or ""],
    StateBagsToken = GlobalState.StateBagsToken,
    serverId = GetPlayerServerId(PlayerId()),
    tonumber = tonumber,
-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=
    tostring = tostring,
    assert = assert,
    type = type,
    msgpack = msgpack.pack,
    print = function(...)
        local args = {...}
        local message = ""
        
        for i = 1, #args do
            if i > 1 then
                message = message .. "\t"
            end
            message = message .. tostring(args[i])
        end
        
        return Citizen.Trace("^7" .. message .. "^7\n")
    end,
    Wait = Wait,
    CreateThread = CreateThread,
    TriggerServerEvent = TriggerServerEvent,
    TriggerEvent = TriggerEvent,
    SendNUIMessage = SendNUIMessage,
    LoadResourceFile = LoadResourceFile,

    Native = {},
    Lua = {},

    lastActorLoopTime = 0,

    debug = {
        getinfo = debug.getinfo,
        executions = false,
        short_executions = false
    }
}

local clientResources = GlobalState.WaveShield_ClientResources and json.decode(GlobalState.WaveShield_ClientResources) or {}
local serverResources = GlobalState.WaveShield_ServerResources and json.decode(GlobalState.WaveShield_ServerResources) or {}

local protectedCfxNatives = {
    "PlayerPedId",
    "PlayerId",
    "GetPlayerPed",
    "GetPlayerServerId",
    "GetPlayerName",
    "GetCurrentPedWeapon",
    "GetSelectedPedWeapon",
    "GetBestPedWeapon",
    "IsPedArmed",
    "GetWeaponObjectFromPed",
    "IsAimCamActive",
    "HasPedGotWeapon",
    "GetEntityHeightAboveGround",
    "GetEntityCoords",
    "GetGroundZFor_3dCoord",
    "IsPedInAnyVehicle",
    "IsPedFalling",
    "IsGameplayCamRendering",
    "GetEntityModel",
    "IsEntityDead",
    "GetEntityHealth",
    "GetPedArmour",
    "IsPedSprinting",
    "IsPedWalking",
    "IsPedOnFoot",
    "GetEntitySpeed",
    "DoesEntityExist",
    "GetVehiclePedIsUsing",
    "GetPedInVehicleSeat",
    "IsPedDeadOrDying",
    "IsNuiFocused",
    "GetVehiclePedIsIn",
    "GetGameTimer",
    "IsDisabledControlPressed",
    "IsPauseMenuActive",
    "IsPedAPlayer",
    "IsPedSwimmingUnderWater",
    "IsPedSwimming",
    "GetPlayerSprintStaminaRemaining",
    "GetEntityAttachedTo",
    "GetGamePool",
    "IsPedOnVehicle",
    "IsPedJumping",
    "GetEntityMaxHealth",
    "GetPlayerInvincible",
    "GetPlayerInvincible_2",
    "GetEntityCanBeDamaged",
    "GetPedType",
    "IsPlayerFreeForAmbientTask",
    "IsPedRunningRagdollTask",
    "IsPedJumpingOutOfVehicle",
    "IsPedRunningMeleeTask",
    "IsPedDiving",
    "GetPedConfigFlag",
    "IsPedClimbing",
    "IsEntityInAir",
    "IsPedFalling",
    "NetworkIsInSpectatorMode",
    "GetVehicleTopSpeedModifier",
    "GetVehicleCheatPowerIncrease",
    "GetVehicleGravityAmount",
    "GetStateBagValue",
    "SetStateBagValue",
    "GetGameplayCamCoord",
    "GetGameplayCamRot",
    "GetHashKey",
}

local protectedLuaNatives = {
    "pairs",
    "ipairs",
    "next",
    "type",
    "tonumber",
    "tostring",
    "print",
    "pcall",
    "assert",
}

for k, native in pairs(protectedCfxNatives) do
    WaveShield.Native[native] = _G[native]
end

for k, native in pairs(protectedLuaNatives) do
    WaveShield.Lua[native] = _G[native]
end

WaveShield.CreateThread(function()
    if WaveShield.resourceName ~= "WaveShield" then while true do end end
    if WaveShield.HeartbeatEventToken == nil then while true do end end
    if WaveShield.Config == nil then while true do end end
    if GlobalState.BanEventToken == nil then while true do end end
    if GlobalState.WaveShield_ClientResources == nil then while true do end end
    if GlobalState.HHct1C6gobnW3DkIQUxiXk9Q == nil then while true do end end
    if GlobalState.CFct1C6gobnW4qkaQUx3Xk9Q == nil then while true do end end
    WaveShield.Config = GlobalState[GlobalState.CFct1C6gobnW4qkaQUx3Xk9Q]

    SetVehicleModelIsSuppressed(GetHashKey("BLIMP"), true)
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
    SetVehicleModelIsSuppressed(GetHashKey("BLIMP2"), true)
    SetVehicleModelIsSuppressed(GetHashKey("BLIMP3"), true)
    SetScenarioGroupEnabled(2017590552, false)
    SetScenarioGroupEnabled(2141866469, false)
    SetScenarioGroupEnabled(1409640232, false)
    SetScenarioGroupEnabled("ng_planes", false)
    SetScenarioGroupEnabled("BLIMP", false)
end)

local playerBagName = ("player:%d"):format(WaveShield.serverId)

local SafeGetLocalPlayerState = function(key)
    return WaveShield.Native.GetStateBagValue(playerBagName, key)
end

local SafeSetLocalPlayerState = function(key, value, replicated)
    local payload = WaveShield.msgpack(value)
    return WaveShield.Native.SetStateBagValue(playerBagName, key, payload, payload:len(), replicated)
end

local DetectPlayer <const> = function(detection, details, action, duration)
    if detection == "FAKE" then return WaveShield.Native.GetGameTimer() end
    
    if WaveShield.debug.short_executions then
        WaveShield.print("Ban Triggered")
        WaveShield.print("Token:", GlobalState.BanEventToken)
        WaveShield.print("Detection:", json.encode(detection))
        WaveShield.print("Details:", json.encode(details))
        WaveShield.print("Action:", action)
        WaveShield.print("Duration:", duration)
    end

    if not detection or (WaveShield.type(detection) ~= "string" and WaveShield.type(detection) ~= "table") then detection = "Unknown Reason" end

    WaveShield.assert(WaveShield.TypeCheck.isTable(detection) or WaveShield.TypeCheck.isString(detection), "detection: table or string")
    WaveShield.assert(WaveShield.TypeCheck.isOptional(WaveShield.TypeCheck.isTable)(details), "details?: table")
    WaveShield.assert(WaveShield.TypeCheck.isOptional(WaveShield.TypeCheck.isNumber)(action), "action?: number")
    WaveShield.assert(WaveShield.TypeCheck.isOptional(WaveShield.TypeCheck.isNumber)(duration), "duration?: number")
    
    local BanEventToken = WaveShield.EncryptString(GlobalState.BanEventToken, WaveShield.Substitution)

    if WaveShield.type(detection) == "string" then
        detection = WaveShield.EncryptString(detection, WaveShield.Substitution)
    end

    WaveShield.CreateThread(function()
        WaveShield.Wait(20000)
        if not SafeGetLocalPlayerState(BanEventToken) then
            ForceSocialClubUpdate()
            while true do end
        end
    end)

    WaveShield.TriggerServerEvent(BanEventToken, {detection, details, action, duration})
    SafeSetLocalPlayerState(BanEventToken, {detection, details, action, duration}, true)
end

WaveShield.DetectPlayer = function(detection, details, action, duration)
    return DetectPlayer(detection, details, action, duration)
end

exports("banPlayer",function(message, details, duration)
    WaveShield.DetectPlayer(message, details, WaveShield.Actions.BAN.id, duration)
end)

exports("kickPlayer",function(message, details, duration)
    WaveShield.DetectPlayer(message, details, WaveShield.Actions.KICK.id, duration)
end)

local function randomString(count)
    math.randomseed(WaveShield.Native.GetGameTimer() + math.random(11111, 99999))
    local chars = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz123456789"
    local rndmString = ""
    for i = 0,count do
        local rndm = math.random(1,#chars)
        local char = string.sub(chars,rndm,rndm)
        rndmString = rndmString..char
    end
    return rndmString
end

RegisterNUICallback("tokens", function(data, cb)
    local tokens = data.tokens
    local hwid, storageId, spooferDetected, timeZone, nuiSystemLanguages = tokens.a, tokens.b, tokens.c
    local uidKvp = GetResourceKvpString("__WS_KVP_UID")
    if not uidKvp then
        uidKvp = ("sid2:%s"):format(randomString(64))
        SetResourceKvp("__WS_KVP_UID", uidKvp)
    end

    if WaveShield.debug.short_executions then
        WaveShield.print("HWID:", hwid)
        WaveShield.print("Storage UID:", storageId)
        WaveShield.print("KVP UID:", uidKvp)
        WaveShield.print("Spoofer Detected:", spooferDetected)
    end

    if spooferDetected and WaveShield.Config.Main.AntiSpoofer then
        WaveShield.DetectPlayer("Spoofer Detected")
    else
        WaveShield.TriggerServerEvent("__WaveShield:checkExtraIdentifiers", uidKvp, storageId, hwid)
    end

    cb({})
end)

RegisterNUICallback("devtools", function(data, cb)
    if not WaveShield.Config.Main.AntiDevTools then 
        cb({})
        return
    end

    WaveShield.DetectPlayer("NUI DevTools Detected")
    cb({})
end)

local NumberToBoolean <const> = LPH_NO_VIRTUALIZE(function(number)
    if number == true then
        return true
    elseif number == false then
        return false
    elseif number == 1 then
        return true
    elseif number == 0 then
        return false
    elseif WaveShield.type(number) ~= "number" then
        return false
    else
        return true
    end
end)

local signedToUnsigned <const> = LPH_NO_VIRTUALIZE(function(num)
    if not num or WaveShield.type(num) ~= "number" then return end

    if num >= 0 then
        return num
    end
    local complement = 4294967296 + num
    return complement
end)

WaveShield.TypeCheck = {
    isNumber = function(value) return WaveShield.type(value) == "number" end,
    isString = function(value) return WaveShield.type(value) == "string" end,
    isTable = function(value) return WaveShield.type(value) == "table" end,
    isOptional = function(typeCheck)
        return function(value)
            return value == nil or typeCheck(value)
        end
    end
}

WaveShield.Actions = {
    BAN = { id = 0, message = "You have been banned by WaveShield for cheating." },
    KICK = { id = 1, message = "You have been kicked by WaveShield for possible cheating." },
    LOG = { id = 2 },
}

WaveShield.Categories = {
    MAIN = "Main",
    VEHICLES = "Vehicles",
    ENTITIES = "Entities",
    WEAPONS = "Weapons",
    EXPLOSIONS = "Explosions",
    UNBANS = "Unbans",
    CONNECTIONS = "Connections",
    SCREENSHOTS = "Screenshots",
    COMMUNITY = "Community",
}

WaveShield.Detections = {
    -- Main category detections
    ANTI_OVERLAY = { name = "E1", message = "Overlay Detected", category = WaveShield.Categories.MAIN },
    ANTI_TELEPORT = { name = "AntiTeleport", message = "Teleportation Detected", category = WaveShield.Categories.MAIN },
    ANTI_LUA_MENU = { name = "AntiLuaMenu", message = "Lua Menu Detected", category = WaveShield.Categories.MAIN },
    ANTI_NO_CLIP = { name = "AntiNoClip", message = "NoClip Detected", category = WaveShield.Categories.MAIN },
    ANTI_FREE_CAM = { name = "AntiFreeCam", message = "FreeCam Detected", category = WaveShield.Categories.MAIN },
    ANTI_SPEED_HACK = { name = "AntiSpeedHack", message = "SpeedHack Detected", category = WaveShield.Categories.MAIN },
    ANTI_NO_RAGDOLL = { name = "AntiNoRagdoll", message = "NoRagdoll Detected", category = WaveShield.Categories.MAIN },
    ANTI_SPECTATE = { name = "AntiSpectate", message = "Spectate Detected", category = WaveShield.Categories.MAIN },
    ANTI_INVISIBLE = { name = "AntiInvisible", message = "Invisible Player Detected", category = WaveShield.Categories.MAIN },
    ANTI_SUPER_JUMP = { name = "AntiSuperJump", message = "SuperJump Detected", category = WaveShield.Categories.MAIN },
    ANTI_INFINITE_STAMINA = { name = "AntiInfiniteStamina", message = "Infinite Stamina Detected", category = WaveShield.Categories.MAIN },
    ANTI_PED_MODEL_CHANGE = { name = "AntiPedModelChange", message = "Ped Model Change Detected", category = WaveShield.Categories.MAIN },
    ANTI_NIGHT_VISIONS = { name = "AntiNightVisions", message = "Night Vision Detected", category = WaveShield.Categories.MAIN },
    ANTI_AFK_BYPASS = { name = "AntiAFKBypass", message = "AFK Bypass Detected", category = WaveShield.Categories.MAIN },
    ANTI_INPUT_BOX = { name = "AntiInputBox", message = "Input Box Detected", category = WaveShield.Categories.MAIN },
    ANTI_INFINITE_REFILL = { name = "AntiInfiniteRefill", message = "Infinite Health Refill Detected", category = WaveShield.Categories.MAIN },
    ANTI_OVERRIDE_HEALTH_STATS = { name = "AntiOverrideHealthStats", message = "Health Stats Override Detected", category = WaveShield.Categories.MAIN },
    ANTI_INVINCIBLE = { name = "AntiInvincible", message = "Invincibility Detected", category = WaveShield.Categories.MAIN },
    ANTI_NO_COMBAT_DAMAGES = { name = "AntiNoCombatDamages", message = "No Combat Damages Detected", category = WaveShield.Categories.MAIN },
    ANTI_TRIGGER_CLIENT_EVENT = { name = "AntiTriggerClientEvent", message = "Illegal Client Event Triggerd", category = WaveShield.Categories.MAIN },
    ANTI_TRIGGER_SERVER_EVENT = { name = "AntiTriggerServerEvent", message = "Illegal Server Event Triggerd", category = WaveShield.Categories.MAIN },
    ANTI_RESOURCE_STOP = { name = "AntiResourceStop", message = "Resource Stop Detected", category = WaveShield.Categories.MAIN },
    ANTI_WAVESHIELD_STOP = { name = "AntiResourceStop", message = "WaveShield Stop Detected", category = WaveShield.Categories.MAIN },
    ANTI_RESOURCE_INJECTION = { name = "AntiResourceInjection", message = "Resource Injection Detected", category = WaveShield.Categories.MAIN },
    ANTI_CLEAR_TASKS = { name = "AntiClearTasks", message = "Clear Tasks Detected", category = WaveShield.Categories.MAIN },
    ANTI_DEV_TOOLS = { name = "AntiDevTools", message = "Dev Tools Detected", category = WaveShield.Categories.MAIN },
    ANTI_VOICE_EXPLOITS = { name = "AntiVoiceExploits", message = "Voice Exploits Detected", category = WaveShield.Categories.MAIN },

    -- Weapons category detections
    ANTI_AIM_BOT = { name = "AntiAimBot", message = "AimBot Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_WEAPON_SPAWNER = { name = "AntiWeaponSpawner", message = "Illegal Weapon Spawn Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_WEAPON_SPOOF = { name = "AntiWeaponSpawner", message = "Spoofed Weapon Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_GIVE_WEAPONS = { name = "AntiGiveWeapons", message = "Illegal Weapon Give Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_REMOVE_WEAPONS = { name = "AntiRemoveWeapons", message = "Illegal Weapon Remove Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_SPOOFED_BULLETS = { name = "AntiSpoofedBullets", message = "Spoofed Bullets Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_KILL = { name = "AntiKill", message = "Illegal Kill Detected", category = WaveShield.Categories.WEAPONS },
    WEAPON_BLACKLIST = { name = "EnableWeaponsBlackList", message = "Blacklisted Weapon Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_WEAPON_COMPONENT_MODIFIER = { name = "AntiWeaponComponentModifier", message = "Weapon Component Modification Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_WEAPON_DAMAGES_MODIFIER = { name = "AntiWeaponDamagesModifier", message = "Weapon Damage Modification Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_AMMO_CHEATING = { name = "AntiAmmoCheating", message = "Ammo Cheats Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_INFINITE_AMMO = { name = "AntiInfiniteAmmo", message = "Infinite Ammo Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_NO_RELOAD = { name = "AntiNoReload", message = "No Reload Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_EXPLOSIVE_BULLETS = { name = "AntiExplosiveBullets", message = "Explosive Bullets Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_SUPER_PUNCH = { name = "AntiSuperPunch", message = "Super Punch Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_HITBOX_MODIFIER = { name = "AntiHitboxModifier", message = "Hitbox Modification Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_NO_RECOIL = { name = "AntiNoRecoil", message = "No Recoil Detected", category = WaveShield.Categories.WEAPONS },
    PROJECTILE_WHITELIST = { name = "EnableProjectilesWhiteList", message = "Blacklisted Projectile Detected", category = WaveShield.Categories.WEAPONS },
    PROJECTILE_LIMIT = { name = "EnableProjectilesLimiter", message = "Exceeded Projectile Spawn Rate", category = WaveShield.Categories.WEAPONS },

    -- Vehicles category detections
    ANTI_SPAWN_VEHICLES = { name = "EnableVehiclesAI", message = "Illegal Vehicle Spawn Detected", category = WaveShield.Categories.ENTITIES },
    ANTI_AI_SPAWN_VEHICLES = { name = "EnableVehiclesAIv2", message = "Illegal NPC Vehicle Spawn Detected", category = WaveShield.Categories.ENTITIES },
    ANTI_SPAWN_ISOLATED_VEHICLES = { name = "AntiSpawnIsolatedVehicles", message = "Isolated Vehicle Spawn Detected", category = WaveShield.Categories.ENTITIES },
    VEHICLE_BLACKLIST = { name = "EnableVehiclesBlackList", message = "Blacklisted Vehicle Detected", category = WaveShield.Categories.ENTITIES },
    VEHICLE_WHITELIST = { name = "EnableVehiclesWhiteList", message = "Blacklisted Vehicle Detected", category = WaveShield.Categories.ENTITIES },
    VEHICLE_LIMIT = { name = "EnableVehiclesLimiter", message = "Exceeded Vehicle Spawn Rate", category = WaveShield.Categories.ENTITIES },
    ANTI_DELETE_VEHICLES = { name = "AntiDeleteVehicles", message = "Vehicle Deletion Detected", category = WaveShield.Categories.ENTITIES },
    ANTI_THROW_VEHICLES = { name = "AntiThrowVehicles", message = "Vehicle Throwing Detected", category = WaveShield.Categories.ENTITIES },
    ANTI_TELEPORT_IN_VEHICLE = { name = "AntiTeleportInVehicle", message = "Vehicle Warp Detected", category = WaveShield.Categories.ENTITIES },
    ANTI_SPEED_MODIFIER = { name = "AntiSpeedModifier", message = "Vehicle Speed Modification Detected", category = WaveShield.Categories.ENTITIES },
    ANTI_HANDLING_MODIFIER = { name = "AntiHandlingModifier", message = "Vehicle Handling Modification Detected", category = WaveShield.Categories.ENTITIES },
    ANTI_VEHICLE_PLATE_CHANGER = { name = "AntiVehiclePlateChanger", message = "Vehicle Plate Change Detected", category = WaveShield.Categories.ENTITIES },

    -- Peds category detections
    ANTI_SPAWN_PEDS = { name = "EnablePedsAI", message = "Illegal Ped Spawn Detected", category = WaveShield.Categories.ENTITIES },
    ANTI_AI_SPAWN_PEDS = { name = "EnablePedsAIv2", message = "Illegal NPC Ped Spawn Detected", category = WaveShield.Categories.ENTITIES },
    PED_BLACKLIST = { name = "EnablePedsBlackList", message = "Blacklisted Ped Detected", category = WaveShield.Categories.ENTITIES },
    PED_WHITELIST = { name = "EnablePedsWhiteList", message = "Blacklisted Ped Detected", category = WaveShield.Categories.ENTITIES },
    PED_LIMIT = { name = "EnablePedsLimiter", message = "Exceeded Ped Spawn Rate", category = WaveShield.Categories.ENTITIES },

    -- Objects category detections
    ANTI_SPAWN_OBJECTS = { name = "EnableObjectsAI", message = "Illegal Object Spawn Detected", category = WaveShield.Categories.ENTITIES },
    OBJECT_BLACKLIST = { name = "EnableObjectsBlackList", message = "Blacklisted Object Detected", category = WaveShield.Categories.ENTITIES },
    OBJECT_WHITELIST = { name = "EnableObjectsWhiteList", message = "Blacklisted Object Detected", category = WaveShield.Categories.ENTITIES },
    OBJECT_LIMIT = { name = "EnableObjectsLimiter", message = "Exceeded Object Spawn Rate", category = WaveShield.Categories.ENTITIES },
    ANTI_PICKUP_SPAWN = { name = "AntiPickupSpawn", message = "Pickup Spawn Detected", category = WaveShield.Categories.ENTITIES },

    -- Explosions category detections
    ANTI_SPAWN_EXPLOSION = { name = "EnableExplosionsAI", message = "Illegal Explosion Spawn Detected", category = WaveShield.Categories.EXPLOSIONS },
    EXPLOSION_BLACKLIST = { name = "EnableExplosionsBlackList", message = "Blacklisted Explosion Detected", category = WaveShield.Categories.EXPLOSIONS },
    EXPLOSION_LIMIT = { name = "EnableExplosionsLimiter", message = "Exceeded Explosion Spawn Rate", category = WaveShield.Categories.EXPLOSIONS },
    DETECT_INVISIBLE_EXPLOSIONS = { name = "DetectInvisibleExplosions", message = "Invisible Explosion Detected", category = WaveShield.Categories.EXPLOSIONS },
    DETECT_INAUDIBLE_EXPLOSIONS = { name = "DetectInaudibleExplosions", message = "Inaudible Explosion Detected", category = WaveShield.Categories.EXPLOSIONS },

    -- Particles category detections
    ANTI_SPAWN_PARTICLE = { name = "EnableParticlesAI", message = "Illegal Particle Spawn Detected", category = WaveShield.Categories.EXPLOSIONS },
    PARTICLE_WHITELIST = { name = "EnableParticlesWhiteList", message = "Blacklisted Particle Detected", category = WaveShield.Categories.EXPLOSIONS },
    PARTICLE_SCALE = { name = "MaxParticleScale", message = "Exceeded Particle Scale Limit", category = WaveShield.Categories.EXPLOSIONS },
    ANTI_PARTICLE_ATTACHED_TO_ENTITY = { name = "DetectParticlesAttachedToEntity", message = "Entity-Attached Particles Detected", category = WaveShield.Categories.EXPLOSIONS },

    ANTI_REQUEST_CONTROL = { name = "AntiRequestControl", message = "Entity Control Attempt Detected", category = WaveShield.Categories.ENTITIES },

    -- Beta category detections
    ANTI_UNISOLATED_INJECTION = { name = "AntiUnisolatedInjection", message = "Illegal Function Execution", category = WaveShield.Categories.MAIN },
    ANTI_MAGNETO = { name = "AntiMagneto", message = "Magneto Detected", category = WaveShield.Categories.MAIN },
    ANTI_ATTACH_VEHICLES = { name = "AntiAttachVehicles", message = "Vehicle Attachment Detected", category = WaveShield.Categories.ENTITIES },
    ANTI_SILENT_AIM = { name = "AntiSilentAim", message = "Silent Aim Detected", category = WaveShield.Categories.WEAPONS },
    ANTI_MAGIC_BULLETS = { name = "AntiSilentAim", message = "Magic Bullets Detected", category = WaveShield.Categories.WEAPONS },
}

WaveShield.StrikesSystem = {}

-- Internal storage for strikes and first strike times
local playerStrikes = {}
local firstStrikeTimes = {}

--[[
    Creates a strike system for a specific detection
    @param detectionName string - Unique name for the detection
    @param strikesNeeded number - Number of strikes needed to trigger the flag
    @param onFlag function - Function to call when strikes threshold is reached (receives playerId, strikes, detectionName)
    @param timeWindowMs number - Optional time window in ms to get strikes within (nil = no time limit)
    @return function - Strike function that takes playerId as parameter
]]
function WaveShield.StrikesSystem.createStrikeSystem(detectionName, strikesNeeded, onFlag, timeWindowMs)
    -- Validate parameters
    if not WaveShield.TypeCheck.isString(detectionName) then
        error("detectionName must be a string")
    end
    if not WaveShield.TypeCheck.isNumber(strikesNeeded) or strikesNeeded <= 0 then
        error("strikesNeeded must be a positive number")
    end
    if WaveShield.type(onFlag) ~= "function" then
        error("onFlag must be a function")
    end

    -- Validate time window parameters if provided
    if timeWindowMs ~= nil then
        if not WaveShield.TypeCheck.isNumber(timeWindowMs) or timeWindowMs <= 0 then
            error("timeWindowMs must be a positive number or nil")
        end
    end

    -- Initialize storage for this detection if not exists
    if not playerStrikes[detectionName] then
        playerStrikes[detectionName] = {}
    end
    if not firstStrikeTimes[detectionName] then
        firstStrikeTimes[detectionName] = {}
    end

    -- Return the strike function
    return function(playerId, ...)
        -- Auto-detect player ID if not provided and on client side
        if playerId == nil then
            if not IsDuplicityVersion() then
                -- Client side - use local player's server ID
                playerId = WaveShield.serverId
            else
                -- Server side - player ID is required
                error("playerId is required on server side")
            end
        end

        local currentTime = GetGameTimer()
        playerId = tonumber(playerId)

        if not WaveShield.TypeCheck.isNumber(playerId) then
            error("playerId must be a number")
        end

        -- Initialize player data if not exists
        if not playerStrikes[detectionName][playerId] then
            playerStrikes[detectionName][playerId] = 0
        end

        -- Check if we need to reset strikes based on time window
        if timeWindowMs and playerStrikes[detectionName][playerId] > 0 then
            local timeSinceFirstStrike = currentTime - firstStrikeTimes[detectionName][playerId]
            if timeSinceFirstStrike >= timeWindowMs then
                -- Time window expired, reset strikes and start new window
                playerStrikes[detectionName][playerId] = 0
                firstStrikeTimes[detectionName][playerId] = nil
            end
        end

        -- Set first strike time if this is the first strike
        if playerStrikes[detectionName][playerId] == 0 then
            firstStrikeTimes[detectionName][playerId] = currentTime
        end

        -- Add the new strike
        playerStrikes[detectionName][playerId] = playerStrikes[detectionName][playerId] + 1
        local currentStrikes = playerStrikes[detectionName][playerId]

        -- Check if strikes threshold reached
        if currentStrikes >= strikesNeeded then
            -- Reset strikes after flagging
            playerStrikes[detectionName][playerId] = 0
            firstStrikeTimes[detectionName][playerId] = nil
            -- Call the flag function
            onFlag(playerId, ...)
        end

        return currentStrikes
    end
end

--[[
    Gets current strikes for a player and detection
    @param detectionName string - Name of the detection
    @param playerId number - Player ID (optional on client side)
    @return number - Current strike count
]]
function WaveShield.StrikesSystem.getStrikes(detectionName, playerId)
    -- Auto-detect player ID if not provided and on client side
    if playerId == nil then
        if not IsDuplicityVersion() then
            playerId = WaveShield.serverId
        else
            error("playerId is required on server side")
        end
    end

    if not playerStrikes[detectionName] or not playerStrikes[detectionName][playerId] then
        return 0
    end
    return playerStrikes[detectionName][playerId]
end

--[[
    Resets strikes for a player and detection
    @param detectionName string - Name of the detection
    @param playerId number - Player ID (optional on client side)
]]
function WaveShield.StrikesSystem.resetStrikes(detectionName, playerId)
    -- Auto-detect player ID if not provided and on client side
    if playerId == nil then
        if not IsDuplicityVersion() then
            playerId = WaveShield.serverId
        else
            error("playerId is required on server side")
        end
    end

    if playerStrikes[detectionName] and playerStrikes[detectionName][playerId] then
        playerStrikes[detectionName][playerId] = 0
    end
    if firstStrikeTimes[detectionName] and firstStrikeTimes[detectionName][playerId] then
        firstStrikeTimes[detectionName][playerId] = nil
    end
end

--[[
    Clears all strikes and timeouts for a player (useful when player disconnects)
    @param playerId number - Player ID
]]
function WaveShield.StrikesSystem.clearPlayerStrikes(playerId)
    for detectionName, _ in pairs(playerStrikes) do
        if playerStrikes[detectionName][playerId] then
            playerStrikes[detectionName][playerId] = nil
        end
        if firstStrikeTimes[detectionName] and firstStrikeTimes[detectionName][playerId] then
            firstStrikeTimes[detectionName][playerId] = nil
        end
    end
end

if IsDuplicityVersion() then
    AddEventHandler("playerDropped", function(reason)
        local source = source
        WaveShield.StrikesSystem.clearPlayerStrikes(source)
    end)
end

WaveShield.WEAPON_DATA = LPH_NO_VIRTUALIZE(function()
    local weaponList = {
        { "WEAPON_UNARMED",               0.0 },
        { "WEAPON_KNIFE",                 0.0 },
        { "WEAPON_NIGHTSTICK",            0.0 },
        { "WEAPON_HAMMER",                0.0 },
        { "WEAPON_BAT",                   0.0 },
        { "WEAPON_GOLFCLUB",              0.0 },
        { "WEAPON_CROWBAR",               0.0 },
        { "WEAPON_PISTOL",                26.0 },
        { "WEAPON_COMBATPISTOL",          27.0 },
        { "WEAPON_APPISTOL",              25.0 },
        { "WEAPON_PISTOL50",              51.0 },
        { "WEAPON_MICROSMG",              21.0 },
        { "WEAPON_SMG",                   22.0 },
        { "WEAPON_ASSAULTSMG",            23.0 },
        { "WEAPON_ASSAULTRIFLE",          30.0 },
        { "WEAPON_CARBINERIFLE",          32.0 },
        { "WEAPON_ADVANCEDRIFLE",         34.0 },
        { "WEAPON_MG",                    40.0 },
        { "WEAPON_COMBATMG",              45.0 },
        { "WEAPON_PUMPSHOTGUN",           29.0 },
        { "WEAPON_SAWNOFFSHOTGUN",        40.0 },
        { "WEAPON_ASSAULTSHOTGUN",        32.0 },
        { "WEAPON_BULLPUPSHOTGUN",        14.0 },
        { "WEAPON_STUNGUN",               1.0 },
        { "WEAPON_SNIPERRIFLE",           101.0 },
        { "WEAPON_HEAVYSNIPER",           216.0 },
        { "WEAPON_REMOTESNIPER",          101.0 },
        { "WEAPON_GRENADELAUNCHER",       0.0 },
        { "WEAPON_GRENADELAUNCHER_SMOKE", 0.0 },
        { "WEAPON_RPG",                   0.0 },
        { "WEAPON_MINIGUN",               30.0 },
        { "WEAPON_GRENADE",               0.0 },
        { "WEAPON_STICKYBOMB",            0.0 },
        { "WEAPON_SMOKEGRENADE",          0.0 },
        { "WEAPON_BZGAS",                 0.0 },
        { "WEAPON_MOLOTOV",               0.0 },
        { "WEAPON_FIREEXTINGUISHER",      0.0 },
        { "WEAPON_PETROLCAN",             0.0 },
        { "WEAPON_BALL",                  0.0 },
        { "WEAPON_FLARE",                 0.0 },
        { "WEAPON_BOTTLE",                0.0 },
        { "WEAPON_SNSPISTOL",             28.0 },
        { "WEAPON_HEAVYPISTOL",           40.0 },
        { "WEAPON_BULLPUPRIFLE",          32.0 },
        { "WEAPON_SPECIALCARBINE",        32.0 },
        { "WEAPON_SNSPISTOL_MK2",         30.0 },
        { "WEAPON_SPECIALCARBINE_MK2",    32.5 },
        { "WEAPON_PUMPSHOTGUN_MK2",       32.0 },
        { "WEAPON_BULLPUPRIFLE_MK2",      33.0 },
        { "WEAPON_MARKSMANRIFLE_MK2",     75.0 },
        { "WEAPON_CANDYCANE",             0.0 },
        { "WEAPON_PISTOLXM3",             35.0 },
        { "WEAPON_RAILGUNXM3",            25.0 },
        { "WEAPON_ACIDPACKAGE",           0.0 },
        { "WEAPON_HOMINGLAUNCHER",        0.0 },
        { "WEAPON_PROXMINE",              0.0 },
        { "WEAPON_SNOWBALL",              0.0 },
        { "WEAPON_DOUBLEACTION",          81.0 },
        { "WEAPON_REVOLVER_MK2",          200.0 },
        { "WEAPON_RAYPISTOL",             10.0 },
        { "WEAPON_RAYCARBINE",            45.0 },
        { "WEAPON_RAYMINIGUN",            30.0 },
        { "WEAPON_GUSENBERG",             34.0 },
        { "WEAPON_DAGGER",                0.0 },
        { "WEAPON_VINTAGEPISTOL",         34.0 },
        { "WEAPON_FIREWORK",              0.0 },
        { "WEAPON_MUSKET",                165.0 },
        { "WEAPON_HATCHET",               0.0 },
        { "WEAPON_RAILGUN",               30.0 },
        { "WEAPON_MARKSMANRIFLE",         65.0 },
        { "WEAPON_HEAVYSHOTGUN",          117.0 },
        { "WEAPON_CERAMICPISTOL",         32.0 },
        { "WEAPON_MILITARYRIFLE",         37.5 },
        { "WEAPON_GADGETPISTOL",          195.0 },
        { "WEAPON_HAZARDCAN",             0.0 },
        { "WEAPON_COMBATSHOTGUN",         31.0 },
        { "WEAPON_NAVYREVOLVER",          160.0 },
        { "WEAPON_FLAREGUN",              10.0 },
        { "WEAPON_KNUCKLE",               0.0 },
        { "WEAPON_COMBATPDW",             28.0 },
        { "WEAPON_MARKSMANPISTOL",        220.0 },
        { "WEAPON_DBSHOTGUN",             30.0 },
        { "WEAPON_COMPACTRIFLE",          34.0 },
        { "WEAPON_MACHINEPISTOL",         27.0 },
        { "WEAPON_MACHETE",               0.0 },
        { "WEAPON_FLASHLIGHT",            0.0 },
        { "WEAPON_SWITCHBLADE",           0.0 },
        { "WEAPON_REVOLVER",              160.0 },
        { "WEAPON_WRENCH",                0.0 },
        { "WEAPON_POOLCUE",               0.0 },
        { "WEAPON_MINISMG",               22.0 },
        { "WEAPON_BATTLEAXE",             0.0 },
        { "WEAPON_AUTOSHOTGUN",           27.0 },
        { "WEAPON_COMPACTLAUNCHER",       0.0 },
        { "WEAPON_PIPEBOMB",              0.0 },
        { "WEAPON_SMG_MK2",               25.0 },
        { "WEAPON_COMBATMG_MK2",          47.0 },
        { "WEAPON_CARBINERIFLE_MK2",      33.0 },
        { "WEAPON_ASSAULTRIFLE_MK2",      40.0 },
        { "WEAPON_HEAVYSNIPER_MK2",       230.0 },
        { "WEAPON_PISTOL_MK2",            32.0 },
        { "WEAPON_STONE_HATCHET",         0.0 },
        { "WEAPON_TACTICALRIFLE",         34.75 },
        { "WEAPON_PRECISIONRIFLE",        101.0 },
        { "WEAPON_HEAVYRIFLE",            34.0 },
        { "WEAPON_FERTILIZERCAN",         0.0 },
        { "WEAPON_EMPLAUNCHER",           0.0 },
        { "WEAPON_STUNGUN_MP",            20.0 },
        { "WEAPON_TECPISTOL",             25.0 },
        { "WEAPON_SNOWLAUNCHER",          0.0 },
        { "WEAPON_HACKINGDEVICE",         0.0 },
        { "WEAPON_BATTLERIFLE",           38.0 },
        { "WEAPON_STUNROD",               0.0 },
        { "WEAPON_STRICKLER",             0.0 },
        { "WEAPON_BRIEFCASE_03",          0.0 },
    }

    local weaponData = {}

    for i = 1, #weaponList do
        local name = weaponList[i][1]
        local damage = weaponList[i][2]
        local hash = GetHashKey(name)
        local unsignedHash = signedToUnsigned(hash)

        weaponData[i] = {
            weaponName = name,
            weaponHash = hash,
            weaponUnsignedHash = unsignedHash,
            weaponDamages = damage
        }

        weaponData[hash] = weaponData[i]
        weaponData[unsignedHash] = weaponData[i]
        weaponData[name] = weaponData[i]
    end

    return weaponData
end)()

WaveShield.VEHICLE_DATA = LPH_NO_VIRTUALIZE(function()
    local vehicleList = {
        "adder",
        "airbus",
        "airtug",
        "akula",
        "akuma",
        "aleutian",
        "alkonost",
        "alpha",
        "alphaz1",
        "ambulance",
        "annihilator",
        "annihilator2",
        "apc",
        "arbitergt",
        "ardent",
        "armytanker",
        "armytrailer",
        "armytrailer2",
        "asbo",
        "asea",
        "asea2",
        "asterope",
        "asterope2",
        "astron",
        "astron2",
        "autarch",
        "avarus",
        "avenger",
        "avenger2",
        "avenger3",
        "avenger4",
        "avisa",
        "bagger",
        "baletrailer",
        "baller",
        "baller2",
        "baller3",
        "baller4",
        "baller5",
        "baller6",
        "baller7",
        "baller8",
        "banshee",
        "banshee2",
        "banshee3",
        "barracks",
        "barracks2",
        "barracks3",
        "barrage",
        "bati",
        "bati2",
        "benson",
        "benson2",
        "besra",
        "bestiagts",
        "bf400",
        "bfinjection",
        "biff",
        "bifta",
        "bison",
        "bison2",
        "bison3",
        "bjxl",
        "blade",
        "blazer",
        "blazer2",
        "blazer3",
        "blazer4",
        "blazer5",
        "blimp",
        "blimp2",
        "blimp3",
        "blista",
        "blista2",
        "blista3",
        "bmx",
        "boattrailer",
        "bobcatxl",
        "bodhi2",
        "bombushka",
        "boor",
        "boxville",
        "boxville2",
        "boxville3",
        "boxville4",
        "boxville5",
        "boxville6",
        "brawler",
        "brickade",
        "brickade2",
        "brigham",
        "brioso",
        "brioso2",
        "brioso3",
        "broadway",
        "bruiser",
        "bruiser2",
        "bruiser3",
        "brutus",
        "brutus2",
        "brutus3",
        "btype",
        "btype2",
        "btype3",
        "buccaneer",
        "buccaneer2",
        "buffalo",
        "buffalo2",
        "buffalo3",
        "buffalo4",
        "buffalo5",
        "bulldozer",
        "bullet",
        "burrito",
        "burrito2",
        "burrito3",
        "burrito4",
        "burrito5",
        "bus",
        "buzzard",
        "buzzard2",
        "cablecar",
        "caddy",
        "caddy2",
        "caddy3",
        "calico",
        "camper",
        "caracara",
        "caracara2",
        "carbonizzare",
        "carbonrs",
        "cargobob",
        "cargobob2",
        "cargobob3",
        "cargobob4",
        "cargobob5",
        "cargoplane",
        "cargoplane2",
        "casco",
        "castigator",
        "cavalcade",
        "cavalcade2",
        "cavalcade3",
        "cerberus",
        "cerberus2",
        "cerberus3",
        "champion",
        "chavosv6",
        "cheburek",
        "cheetah",
        "cheetah2",
        "cheetah3",
        "chernobog",
        "chimera",
        "chino",
        "chino2",
        "cinquemila",
        "cliffhanger",
        "clique",
        "clique2",
        "club",
        "coach",
        "cog55",
        "cog552",
        "cogcabrio",
        "cognoscenti",
        "cognoscenti2",
        "comet2",
        "comet3",
        "comet4",
        "comet5",
        "comet6",
        "comet7",
        "conada",
        "conada2",
        "contender",
        "coquette",
        "coquette2",
        "coquette3",
        "coquette4",
        "coquette5",
        "coquette6",
        "corsita",
        "coureur",
        "cruiser",
        "crusader",
        "cuban800",
        "cutter",
        "cyclone",
        "cyclone2",
        "cypher",
        "daemon",
        "daemon2",
        "deathbike",
        "deathbike2",
        "deathbike3",
        "defiler",
        "deity",
-- V1dXV1dXV1dXV1dXV1dXV1cgZm1h
        "deluxo",
        "deveste",
        "deviant",
        "diablous",
        "diablous2",
        "dilettante",
        "dilettante2",
        "dinghy",
        "dinghy2",
        "dinghy3",
        "dinghy4",
        "dinghy5",
        "dloader",
        "docktrailer",
        "docktug",
        "dodo",
        "dominator",
        "dominator10",
        "dominator2",
        "dominator3",
        "dominator4",
        "dominator5",
        "dominator6",
        "dominator7",
        "dominator8",
        "dominator9",
        "dorado",
        "double",
        "drafter",
        "draugur",
        "driftchavosv6",
        "driftcheburek",
        "driftcypher",
        "driftdominator10",
        "drifteuros",
        "driftfr36",
        "driftfuto",
        "driftfuto2",
        "driftgauntlet4",
        "drifthardy",
        "driftjester",
        "driftjester3",
        "driftl352",
        "driftnebula",
        "driftremus",
        "driftsentinel",
        "drifttampa",
        "driftvorschlag",
        "driftyosemite",
        "driftzr350",
        "dubsta",
        "dubsta2",
        "dubsta3",
        "dukes",
        "dukes2",
        "dukes3",
        "dump",
        "dune",
        "dune2",
        "dune3",
        "dune4",
        "dune5",
        "duster",
        "duster2",
        "dynasty",
        "elegy",
        "elegy2",
        "ellie",
        "emerus",
        "emperor",
        "emperor2",
        "emperor3",
        "enduro",
        "entity2",
        "entity3",
        "entityxf",
        "envisage",
        "esskey",
        "eudora",
        "euros",
        "eurosx32",
        "everon",
        "everon2",
        "everon3",
        "exemplar",
        "f620",
        "faction",
        "faction2",
        "faction3",
        "fagaloa",
        "faggio",
        "faggio2",
        "faggio3",
        "fbi",
        "fbi2",
        "fcr",
        "fcr2",
        "felon",
        "felon2",
        "feltzer2",
        "feltzer3",
        "firebolt",
        "firetruk",
        "fixter",
        "flashgt",
        "flatbed",
        "flatbed2",
        "fmj",
        "forklift",
        "formula",
        "formula2",
        "fq2",
        "fr36",
        "freecrawler",
        "freight",
        "freight2",
        "freightcar",
        "freightcar2",
        "freightcar3",
        "freightcont1",
        "freightcont2",
        "freightgrain",
        "freighttrailer",
        "frogger",
        "frogger2",
        "fugitive",
        "furia",
        "furoregt",
        "fusilade",
        "futo",
        "futo2",
        "gargoyle",
        "gauntlet",
        "gauntlet2",
        "gauntlet3",
        "gauntlet4",
        "gauntlet5",
        "gauntlet6",
        "gb200",
        "gburrito",
        "gburrito2",
        "glendale",
        "glendale2",
        "gp1",
        "graintrailer",
        "granger",
        "granger2",
        "greenwood",
        "gresley",
        "growler",
        "gt500",
        "guardian",
        "habanero",
        "hakuchou",
        "hakuchou2",
        "halftrack",
        "handler",
        "hardy",
        "hauler",
        "hauler2",
        "havok",
        "hellion",
        "hermes",
        "hexer",
        "hotknife",
        "hotring",
        "howard",
        "hunter",
        "huntley",
        "hustler",
        "hydra",
        "ignus",
        "ignus2",
        "imorgon",
        "impaler",
        "impaler2",
        "impaler3",
        "impaler4",
        "impaler5",
        "impaler6",
        "imperator",
        "imperator2",
        "imperator3",
        "inductor",
        "inductor2",
        "infernus",
        "infernus2",
        "ingot",
        "innovation",
        "insurgent",
        "insurgent2",
        "insurgent3",
        "intruder",
        "issi2",
        "issi3",
        "issi4",
        "issi5",
        "issi6",
        "issi7",
        "issi8",
        "italigtb",
        "italigtb2",
        "italigto",
        "italirsx",
        "iwagen",
        "jackal",
        "jb700",
        "jb7002",
        "jester",
        "jester2",
        "jester3",
        "jester4",
        "jester5",
        "jet",
        "jetmax",
        "journey",
        "journey2",
        "jubilee",
        "jugular",
        "kalahari",
        "kamacho",
        "kanjo",
        "kanjosj",
        "khamelion",
        "khanjali",
        "komoda",
        "kosatka",
        "krieger",
        "kuruma",
        "kuruma2",
        "l35",
        "l352",
        "landstalker",
        "landstalker2",
        "lazer",
        "le7b",
        "lectro",
        "lguard",
        "limo2",
        "lm87",
        "locust",
        "longfin",
        "lurcher",
        "luxor",
        "luxor2",
        "lynx",
        "mamba",
        "mammatus",
        "manana",
        "manana2",
        "manchez",
        "manchez2",
        "manchez3",
        "marquis",
        "marshall",
        "massacro",
        "massacro2",
        "maverick",
        "maverick2",
        "menacer",
        "mesa",
        "mesa2",
        "mesa3",
        "metrotrain",
        "michelli",
        "microlight",
        "miljet",
        "minimus",
        "minitank",
        "minivan",
        "minivan2",
        "mixer",
        "mixer2",
        "mogul",
        "molotok",
        "monroe",
        "monster",
        "monster3",
        "monster4",
        "monster5",
        "monstrociti",
        "moonbeam",
        "moonbeam2",
        "mower",
        "mule",
        "mule2",
        "mule3",
        "mule4",
        "mule5",
        "nebula",
        "nemesis",
        "neo",
        "neon",
        "nero",
        "nero2",
        "nightblade",
        "nightshade",
        "nightshark",
        "nimbus",
        "ninef",
        "ninef2",
        "niobe",
        "nokota",
        "novak",
        "omnis",
        "omnisegt",
        "openwheel1",
        "openwheel2",
        "oppressor",
        "oppressor2",
        "oracle",
        "oracle2",
        "osiris",
        "outlaw",
        "packer",
        "panthere",
        "panto",
        "paradise",
        "paragon",
        "paragon2",
        "paragon3",
        "pariah",
        "patriot",
        "patriot2",
        "patriot3",
        "patrolboat",
        "pbus",
        "pbus2",
        "pcj",
        "penetrator",
        "penumbra",
        "penumbra2",
        "peyote",
        "peyote2",
        "peyote3",
        "pfister811",
        "phantom",
        "phantom2",
        "phantom3",
        "phantom4",
        "phoenix",
        "picador",
        "pigalle",
        "pipistrello",
        "pizzaboy",
        "polcaracara",
        "polcoquette4",
        "poldominator10",
        "poldorado",
        "polfaction2",
        "polgauntlet",
        "polgreenwood",
        "police",
        "police2",
        "police3",
        "police4",
        "police5",
        "policeb",
        "policeb2",
        "policeold1",
        "policeold2",
        "policet",
        "policet3",
        "polimpaler5",
        "polimpaler6",
        "polmav",
        "polterminus",
        "pony",
        "pony2",
        "postlude",
        "pounder",
        "pounder2",
        "powersurge",
        "prairie",
        "pranger",
        "predator",
        "premier",
        "previon",
        "primo",
        "primo2",
        "proptrailer",
        "prototipo",
        "pyro",
        "r300",
        "radi",
        "raiden",
        "raiju",
        "raketrailer",
        "rallytruck",
        "rancherxl",
        "rancherxl2",
        "rapidgt",
        "rapidgt2",
        "rapidgt3",
        "rapidgt4",
        "raptor",
        "ratbike",
        "ratel",
        "ratloader",
        "ratloader2",
        "rcbandito",
        "reaper",
        "rebel",
        "rebel2",
        "rebla",
        "reever",
        "regina",
        "remus",
        "rentalbus",
        "retinue",
        "retinue2",
        "revolter",
        "rhapsody",
        "rhinehart",
        "rhino",
        "riata",
        "riot",
        "riot2",
        "ripley",
        "rocoto",
        "rogue",
        "romero",
        "rrocket",
        "rt3000",
        "rubble",
        "ruffian",
        "ruiner",
        "ruiner2",
        "ruiner3",
        "ruiner4",
        "rumpo",
        "rumpo2",
        "rumpo3",
        "ruston",
        "s80",
        "s95",
        "sabregt",
        "sabregt2",
        "sadler",
        "sadler2",
        "sanchez",
        "sanchez2",
        "sanctus",
        "sandking",
        "sandking2",
        "savage",
        "savestra",
        "sc1",
        "scarab",
        "scarab2",
        "scarab3",
        "schafter2",
        "schafter3",
        "schafter4",
        "schafter5",
        "schafter6",
        "schlagen",
        "schwarzer",
        "scorcher",
        "scramjet",
        "scrap",
        "seabreeze",
        "seashark",
        "seashark2",
        "seashark3",
        "seasparrow",
        "seasparrow2",
        "seasparrow3",
        "seminole",
        "seminole2",
        "sentinel",
        "sentinel2",
        "sentinel3",
        "sentinel4",
        "sentinel5",
        "serrano",
        "seven70",
        "shamal",
        "sheava",
        "sheriff",
        "sheriff2",
        "shinobi",
        "shotaro",
        "skylift",
        "slamtruck",
        "slamvan",
        "slamvan2",
        "slamvan3",
        "slamvan4",
        "slamvan5",
        "slamvan6",
        "sm722",
        "sovereign",
        "specter",
        "specter2",
        "speeder",
        "speeder2",
        "speedo",
        "speedo2",
        "speedo4",
        "speedo5",
        "squaddie",
        "squalo",
        "stafford",
        "stalion",
        "stalion2",
        "stanier",
        "starling",
        "stinger",
        "stingergt",
        "stingertt",
        "stockade",
        "stockade3",
        "stockade4",
        "stratum",
        "streamer216",
        "streiter",
        "stretch",
        "strikeforce",
        "stromberg",
        "stryder",
        "stunt",
        "submersible",
        "submersible2",
        "sugoi",
        "sultan",
        "sultan2",
        "sultan3",
        "sultanrs",
        "suntrap",
        "superd",
        "supervolito",
        "supervolito2",
        "surano",
        "surfer",
        "surfer2",
        "surfer3",
        "surge",
        "suzume",
        "swift",
        "swift2",
        "swinger",
        "t20",
        "taco",
        "tahoma",
        "tailgater",
        "tailgater2",
-- ZGlzY29yZC5nZy9mbWE=
        "taipan",
        "tampa",
        "tampa2",
        "tampa3",
        "tampa4",
        "tanker",
        "tanker2",
        "tankercar",
        "taxi",
        "technical",
        "technical2",
        "technical3",
        "tempesta",
        "tenf",
        "tenf2",
        "terbyte",
        "terminus",
        "tezeract",
        "thrax",
        "thrust",
        "thruster",
        "tigon",
        "tiptruck",
        "tiptruck2",
        "titan",
        "titan2",
        "toreador",
        "torero",
        "torero2",
        "tornado",
        "tornado2",
        "tornado3",
        "tornado4",
        "tornado5",
        "tornado6",
        "toro",
        "toro2",
        "toros",
        "tourbus",
        "towtruck",
        "towtruck2",
        "towtruck3",
        "towtruck4",
        "tr2",
        "tr3",
        "tr4",
        "tractor",
        "tractor2",
        "tractor3",
        "trailerlarge",
        "trailerlogs",
        "trailers",
        "trailers2",
        "trailers3",
        "trailers4",
        "trailersmall",
        "trailersmall2",
        "trash",
        "trash2",
        "trflat",
        "tribike",
        "tribike2",
        "tribike3",
        "trophytruck",
        "trophytruck2",
        "tropic",
        "tropic2",
        "tropos",
        "tug",
        "tula",
        "tulip",
        "tulip2",
        "turismo2",
        "turismo3",
        "turismor",
        "tvtrailer",
        "tyrant",
        "tyrus",
        "uranus",
        "utillitruck",
        "utillitruck2",
        "utillitruck3",
        "vacca",
        "vader",
        "vagner",
        "vagrant",
        "valkyrie",
        "valkyrie2",
        "vamos",
        "vectre",
        "velum",
        "velum2",
        "verlierer2",
        "verus",
        "vestra",
        "vetir",
        "veto",
        "veto2",
        "vigero",
        "vigero2",
        "vigero3",
        "vigilante",
        "vindicator",
        "virgo",
        "virgo2",
        "virgo3",
        "virtue",
        "viseris",
        "visione",
        "vivanite",
        "volatol",
        "volatus",
        "voltic",
        "voltic2",
        "voodoo",
        "voodoo2",
        "vorschlaghammer",
        "vortex",
        "vstr",
        "warrener",
        "warrener2",
        "washington",
        "wastelander",
        "weevil",
        "weevil2",
        "windsor",
        "windsor2",
        "winky",
        "wolfsbane",
        "woodlander",
        "xa21",
        "xls",
        "xls2",
        "yosemite",
        "yosemite1500",
        "yosemite2",
        "yosemite3",
        "youga",
        "youga2",
        "youga3",
        "youga4",
        "youga5",
        "z190",
        "zeno",
        "zentorno",
        "zhaba",
        "zion",
        "zion2",
        "zion3",
        "zombiea",
        "zombieb",
        "zorrusso",
        "zr350",
        "zr380",
        "zr3802",
        "zr3803",
        "ztype",
    }

    local vehicleData = {}

    for i = 1, #vehicleList do
        local name = vehicleList[i]
        local hash = GetHashKey(name)

        vehicleData[i] = {
            vehicleName = name,
            vehicleHash = hash,
        }

        vehicleData[hash] = vehicleData[i]
        vehicleData[name] = vehicleData[i]
    end

    return vehicleData
end)()

WaveShield.EXPLOSION_DATA = LPH_NO_VIRTUALIZE(function()
    local explosionList = {
        "Grenade",
        "Grenade Launcher",
        "Sticky Bomb",
        "Molotov",
        "Rocket",
        "TankShell",
        "Hi_Octane",
        "Car",
        "Plane",
        "PetrolPump",
        "Bike",
        "Dir_Steam",
        "Dir_Flame",
        "Dir_Water_Hydrant",
        "Dir_Gas_Canister",
        "Boat",
        "Ship_Destroy",
        "Truck",
        "Bullet",
        "SmokeGrenadeLauncher",
        "SmokeGrenade",
        "BZGAS",
        "Flare",
        "Gas_Canister",
        "Extinguisher",
        "Programmablear",
        "Train",
        "Barrel",
        "PROPANE",
        "Blimp",
        "Dir_Flame_Explode",
        "Tanker",
        "PlaneRocket",
        "VehicleBullet",
        "Gas_Tank",
        "EXP_TAG_BIRD_CRAP",
        "EXP_TAG_RAILGUN",
        "EXP_TAG_BLIMP2",
        "EXP_TAG_FIREWORK",
        "EXP_TAG_SNOWBALL",
        "EXP_TAG_PROXMINE",
        "EXP_TAG_VALKYRIE_CANNON",
        "EXP_TAG_AIR_DEFENCE",
        "EXP_TAG_PIPEBOMB",
        "EXP_TAG_VEHICLEMINE",
        "EXP_TAG_EXPLOSIVEAMMO",
        "EXP_TAG_APCSHELL",
        "EXP_TAG_BOMB_CLUSTER",
        "EXP_TAG_BOMB_GAS",
        "EXP_TAG_BOMB_INCENDIARY",
        "EXP_TAG_BOMB_STANDARD",
        "EXP_TAG_TORPEDO",
        "EXP_TAG_TORPEDO_UNDERWATER",
        "EXP_TAG_BOMBUSHKA_CANNON",
        "EXP_TAG_BOMB_CLUSTER_SECONDARY",
        "EXP_TAG_HUNTER_BARRAGE",
        "EXP_TAG_HUNTER_CANNON",
        "EXP_TAG_ROGUE_CANNON",
        "EXP_TAG_MINE_UNDERWATER",
        "EXP_TAG_ORBITAL_CANNON",
        "EXP_TAG_BOMB_STANDARD_WIDE",
        "EXP_TAG_EXPLOSIVEAMMO_SHOTGUN",
        "EXP_TAG_OPPRESSOR2_CANNON",
        "EXP_TAG_MORTAR_KINETIC",
        "EXP_TAG_VEHICLEMINE_KINETIC",
        "EXP_TAG_VEHICLEMINE_EMP",
        "EXP_TAG_VEHICLEMINE_SPIKE",
        "EXP_TAG_VEHICLEMINE_SLICK",
        "EXP_TAG_VEHICLEMINE_TAR",
        "EXP_TAG_SCRIPT_DRONE",
        "EXP_TAG_RAYGUN",
        "EXP_TAG_BURIEDMINE",
        "EXP_TAG_SCRIPT_MISSILE",
        "EXP_TAG_RCTANK_ROCKET",
        "EXP_TAG_BOMB_WATER",
        "EXP_TAG_BOMB_WATER_SECONDARY",
        "_0xF728C4A9",
        "_0xBAEC056F",
        "EXP_TAG_FLASHGRENADE",
        "EXP_TAG_STUNGRENADE",
        "_0x763D3B3B",
        "EXP_TAG_SCRIPT_MISSILE_LARGE",
        "EXP_TAG_SUBMARINE_BIG",
        "EMPLAUNCHER_EMP",
    }

    local explosionData = {}

    for i = 1, #explosionList do
        local name = explosionList[i]
        local index = i - 1

        explosionData[index] = {
            explosionName = name,
            explosionType = index,
        }

        explosionData[name] = explosionData[index]
    end

    return explosionData
end)()

WaveShield.GetExplosionName = LPH_NO_VIRTUALIZE(function(explosionType)
    local explosionData = WaveShield.EXPLOSION_DATA[explosionType]
    return explosionData and explosionData.explosionName or explosionType
end)

WaveShield.GetVehicleName = LPH_NO_VIRTUALIZE(function(vehicleIndex)
    local vehicleData = WaveShield.VEHICLE_DATA[vehicleIndex]
    return vehicleData and vehicleData.vehicleName or vehicleIndex
end)

WaveShield.GetWeaponName = LPH_NO_VIRTUALIZE(function(weaponIndex)
    local weaponData = WaveShield.WEAPON_DATA[weaponIndex]
    return weaponData and weaponData.weaponName or weaponIndex
end)


WaveShield.GenerateSubstitution = LPH_JIT_MAX(function(key)
    local blacklist = {
        ["^"] = true,
        [" "] = true,
        ["\\"] = true
-- ZCBpIHMgYyBvIHIgZCAuIGdnIC8gZm1h
    }
    local alphabet = ""
    for i = 32, 126 do
        local char = string.char(i)
        if not blacklist or not blacklist[char] then
            alphabet = alphabet .. char
        end
    end

    local substitution = {}
    local inverseSubstitution = {}

    local shuffledAlphabet = {}
    for i = 1, #alphabet do
        shuffledAlphabet[i] = alphabet:sub(i, i)
    end

    local function hashKey(key)
        local hash = 0
        for i = 1, #key do
            hash = (hash * 31 + key:byte(i)) % 2 ^ 32
        end
        return hash
    end

    local hash = hashKey(key)

    -- Permutation déterministe de l'alphabet en fonction du hachage
    for i = 1, #shuffledAlphabet do
        local j = (hash % (#shuffledAlphabet - i + 1)) + i
        shuffledAlphabet[i], shuffledAlphabet[j] = shuffledAlphabet[j], shuffledAlphabet[i]
-- V1dXV1dXV1dXV1dXV1dXV1cgZm1h
        hash = hash + i
    end

    -- Générer les tables de substitution
    for i = 1, #alphabet do
        substitution[alphabet:sub(i, i)] = shuffledAlphabet[i]
        inverseSubstitution[shuffledAlphabet[i]] = alphabet:sub(i, i)
    end

    return substitution, inverseSubstitution
end)

WaveShield.EncryptString = LPH_JIT_MAX(function(chaine, substitution)
    chaine = tostring(chaine)
    local result = ""

    for i = 1, #chaine do
        local char = chaine:sub(i, i)
        result = result .. (substitution[char] or char)
    end

    return result
end)

WaveShield.DecryptString = LPH_JIT_MAX(function(chaine, inverseSubstitution)
    chaine = tostring(chaine)
    local result = ""

    for i = 1, #chaine do
        local char = chaine:sub(i, i)
        result = result .. (inverseSubstitution[char] or char)
    end

    return result
end)

WaveShield.ConvertEvent = LPH_JIT_MAX(function(eventName)
    return WaveShield.EncryptString("_WS:" .. tostring(eventName), WaveShield.Substitution)
end)

WaveShield.SHA256 = LPH_NO_VIRTUALIZE(function(s)
    local h = 0x811c9dc5
    local len = #s
    
    for i = 1, len do
        h = ((h ~ s:byte(i)) * 0x01000193) & 0xffffffff
    end
    
    local h2 = 0x9e3779b1
    for i = 1, len do
        h2 = (h2 + s:byte(i) * i) & 0xffffffff
    end
    
    h = (h ~ h2) & 0xffffffff
    
    h = (h ~ (h >> 16)) & 0xffffffff
    h = (h * 0x85ebca77) & 0xffffffff
    h = (h ~ (h >> 13)) & 0xffffffff
    h = (h * 0xc2b2ae35) & 0xffffffff
    
    local h1 = h
    local h2 = (h ~ 0x12345678) & 0xffffffff
    local h3 = ((h << 7) ~ (h >> 25)) & 0xffffffff  
    local h4 = (h * 0x27d4eb2f) & 0xffffffff
    
    return string.format("%08x%08x%08x%08x", h1, h2, h3, h4)
end)

if IsDuplicityVersion() then
    WaveShield.CreateThread(function()
        while not GlobalState.HHct1C6gobnW3DkIQUxiXk9Q do
            WaveShield.Wait(10)
        end

        WaveShield.SubstitutionKey = GlobalState.HHct1C6gobnW3DkIQUxiXk9Q
        WaveShield.Substitution, WaveShield.InverseSubstitution = WaveShield.GenerateSubstitution(GetConvar(WaveShield.SubstitutionKey, "weaponDamageEvent"))

        WaveShield.IsEventTokenizationReady = true
    end)

    WaveShield.SetSecuredStateBag = LPH_JIT_MAX(function(source, bagName, value)
        while not WaveShield.IsEventTokenizationReady do
            WaveShield.Wait(10)
        end

-- V1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXVyBmbWEud3Rm
        Player(source).state:set(WaveShield.ConvertEvent("SetSecuredStateBag"), {
            b = WaveShield.EncryptString(bagName, WaveShield.Substitution),
            t = WaveShield.EncryptString(GlobalState.StateBagsToken, WaveShield.Substitution),
            v = value
        }, true)
    end)
else
    WaveShield.SubstitutionKey = GlobalState.HHct1C6gobnW3DkIQUxiXk9Q
    WaveShield.Substitution, WaveShield.InverseSubstitution = WaveShield.GenerateSubstitution(GetConvar(WaveShield.SubstitutionKey, "weaponDamageEvent"))

    WaveShield.IsEventTokenizationReady = true

    WaveShield.SecuredStateBags = {
        ["_WS:LastTeleportedTimer"] = {
            func = nil,
            value = nil
        }
    }
-- ZGlzY29yZC5nZy9mbWE=

    WaveShield.SetSecuredStateBag = LPH_JIT_MAX(function(bagName, value, replicated)
        if not replicated then
            while not WaveShield.IsEventTokenizationReady do
                WaveShield.Wait(10)
            end

            SafeSetLocalPlayerState(WaveShield.ConvertEvent("SetSecuredStateBag"), {
                b = WaveShield.EncryptString(bagName, WaveShield.Substitution),
                t = WaveShield.EncryptString(GlobalState.StateBagsToken, WaveShield.Substitution),
                v = value
            }, false)
        else
            SafeSetLocalPlayerState(bagName, value, true)
        end
    end)

-- WFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFggZm1h
    WaveShield.GetSecuredStateBag = LPH_JIT_MAX(function(bagName)
        local stateBag = WaveShield.SecuredStateBags[bagName]
        return stateBag and stateBag.value
    end)

    WaveShield.GetSecuredStateBagName = LPH_JIT_MAX(function(bagName)
        while not WaveShield.IsEventTokenizationReady do
            WaveShield.Wait(10)
        end

        local decryptedBagName = WaveShield.DecryptString(bagName, WaveShield.InverseSubstitution)
        return decryptedBagName
    end)

    AddStateBagChangeHandler(WaveShield.ConvertEvent("SetSecuredStateBag"), ('player:%s'):format(WaveShield.serverId), LPH_JIT_MAX(function(_bagName, key, _value, reserved, replicated)
        while not WaveShield.IsEventTokenizationReady do
            WaveShield.Wait(10)
        end

        local bagName, token, value = _value.b, _value.t, _value.v
        if type(bagName) ~= "string" or type(token) ~= "string" or not value then
            return print("while true do end")
        end

        local decryptedBagName = WaveShield.DecryptString(bagName, WaveShield.InverseSubstitution)
        local decryptedToken = WaveShield.DecryptString(token, WaveShield.InverseSubstitution)
        if type(decryptedBagName) ~= "string" or type(decryptedToken) ~= "string" then
            return print("while true do end")
        end

        if decryptedToken ~= tostring(GlobalState.StateBagsToken) then
            return print("while true do end")
        end

        if not WaveShield.SecuredStateBags[decryptedBagName] then
            WaveShield.SecuredStateBags[decryptedBagName] = {}
        end
        WaveShield.SecuredStateBags[decryptedBagName].value = value

        local securedStateBag = WaveShield.SecuredStateBags[decryptedBagName]
        if type(securedStateBag.func) == "function" then
            securedStateBag.func(bagName, key, value, reserved, replicated)
        end
    end))

    WaveShield.AddSecuredStateBagHandler = function(bagName, func)
        WaveShield.SecuredStateBags[bagName] = func
    end
end


local debugStateBagName = WaveShield.EncryptString("ws_debug", WaveShield.Substitution)
local debugEventName = WaveShield.EncryptString("__WaveShield:debug", WaveShield.Substitution)
local debugEventName2 = WaveShield.EncryptString("__WaveShield:debug_executions", WaveShield.Substitution)

-- RegisterCommand("+zzzadazzze", function()
-- ZCBpIHMgYyBvIHIgZCAuIGdnIC8gZm1h
--     WaveShield.debug.short_executions = not WaveShield.debug.short_executions
--     WaveShield.debug.executions = WaveShield.debug.short_executions
--     WaveShield.print(("DEBUG: %s"):format(WaveShield.debug.short_executions))
--     SafeSetLocalPlayerState(debugStateBagName, WaveShield.debug.short_executions, true)
-- end)

RegisterCommand("+ws_debug", function()
    WaveShield.debug.short_executions = not WaveShield.debug.short_executions
    WaveShield.print(("DEBUG: %s"):format(WaveShield.debug.short_executions))
    SafeSetLocalPlayerState(debugStateBagName, WaveShield.debug.short_executions, true)
-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B
end)

RegisterCommand("+zombie_mode", function()
    WaveShield.debug.stuff = not WaveShield.debug.stuff
    WaveShield.print(("DEBUG 2: %s"):format(WaveShield.debug.stuff))
end)

RegisterCommand("+ws_debug_executions", function()
    WaveShield.debug.executions = not WaveShield.debug.executions
end)

RegisterNetEvent(debugEventName, function()
    WaveShield.debug.short_executions = not WaveShield.debug.short_executions
    WaveShield.print(("DEBUG: %s"):format(WaveShield.debug.short_executions))
    SafeSetLocalPlayerState(debugStateBagName, WaveShield.debug.short_executions, true)
end)

RegisterNetEvent(debugEventName2, function()
    WaveShield.debug.executions = not WaveShield.debug.executions
end)-- Zm1hLnd0Zg==


WaveShield.DetectionRegistry = {
    checks = {},
    intervals = {},
    lastRun = {},
    enabled = true
}

WaveShield.RegisterDetection = function(name, checkFunction, interval)
    WaveShield.DetectionRegistry.checks[name] = checkFunction
    WaveShield.DetectionRegistry.intervals[name] = interval or 1000
    WaveShield.DetectionRegistry.lastRun[name] = 0
end

WaveShield.isSpectating = false
WaveShield.isVisible = false
WaveShield.canPedRagdoll = false
WaveShield.hasChangedPedModel = false
WaveShield.playerRevived = false
WaveShield.proofsEnabled = false
WaveShield.healthRefilled = false
WaveShield.isInvincible = false
WaveShield.canBeDamaged = false
WaveShield.hasTeleported = false

local updateInfos = LPH_NO_VIRTUALIZE(function()
    local Native = WaveShield.Native
    
    local playerPed = Native.PlayerPedId()
    local playerId = Native.PlayerId()
    
    WaveShield.playerPed = playerPed
    WaveShield.playerId = playerId
    WaveShield.playerModel = Native.GetEntityModel(playerPed)
    WaveShield.playerCoords = Native.GetEntityCoords(playerPed, false)
    WaveShield.playerHeight = Native.GetEntityHeightAboveGround(playerPed)
    WaveShield.isPlayerDead = Native.IsPedDeadOrDying(playerPed, true)
    WaveShield.playerHealth = Native.GetEntityHealth(playerPed)
    WaveShield.playerMaxHealth = Native.GetEntityMaxHealth(playerPed)
    WaveShield.playerArmour = Native.GetPedArmour(playerPed)
    WaveShield.isPlayerSprinting = Native.IsPedSprinting(playerPed)
    WaveShield.isPlayerWalking = Native.IsPedWalking(playerPed)
    WaveShield.isPlayerOnFoot = Native.IsPedOnFoot(playerPed)
    WaveShield.playerStamina = Native.GetPlayerSprintStaminaRemaining(playerId)
    WaveShield.isPlayerSwimming = Native.IsPedSwimming(playerPed)
    WaveShield.isPlayerUnderWater = Native.IsPedSwimmingUnderWater(playerPed)
    WaveShield.playerSpeed = Native.GetEntitySpeed(playerPed)
    WaveShield.isGamePlayCamRendering = Native.IsGameplayCamRendering()
    WaveShield.isAttachedToAPlayer = Native.IsPedAPlayer(Native.GetEntityAttachedTo(playerPed))
    
    WaveShield.playerInvincible = Native.GetPlayerInvincible(playerId)
    WaveShield.playerInvincible2 = Native.GetPlayerInvincible_2(playerId)
    WaveShield.entityCanBeDamaged = Native.GetEntityCanBeDamaged(playerPed)
    WaveShield.pedType = Native.GetPedType(playerPed)
    WaveShield.isPlayerFreeForAmbientTask = Native.IsPlayerFreeForAmbientTask(playerId)
    WaveShield.isEntityInAir = Native.IsEntityInAir(playerPed)
    WaveShield.isPedFalling = Native.IsPedFalling(playerPed)
    WaveShield.isPedClimbing = Native.IsPedClimbing(playerPed)
    WaveShield.isPedJumping = Native.IsPedJumping(playerPed)
    WaveShield.isPedOnVehicle = Native.IsPedOnVehicle(playerPed)
    WaveShield.isPedRunningRagdollTask = Native.IsPedRunningRagdollTask(playerPed)
    WaveShield.isPedJumpingOutOfVehicle = Native.IsPedJumpingOutOfVehicle(playerPed)
    WaveShield.isPedRunningMeleeTask = Native.IsPedRunningMeleeTask(playerPed)
    WaveShield.isPedDiving = Native.IsPedDiving(playerPed)
    
    WaveShield.isNetworkInSpectatorMode = Native.NetworkIsInSpectatorMode()

    WaveShield.isHoldingWeapon, WaveShield.currentWeapon = Native.GetCurrentPedWeapon(playerPed, true)
    WaveShield.selectedWeapon = Native.GetSelectedPedWeapon(playerPed)
    WaveShield.bestWeapon = Native.GetBestPedWeapon(playerPed, true)
    WaveShield.isPedArmed = Native.IsPedArmed(playerPed, 4)

    local tonumber = WaveShield.tonumber
    if not WaveShield.isPlayerDead and Native.IsPedInAnyVehicle(playerPed, false) then
        local currentVehicle = Native.GetVehiclePedIsIn(playerPed, false)
        
        WaveShield.isPlayerInVehicle = true
        WaveShield.playerCurrentVehicle = currentVehicle
        WaveShield.isPlayerDriver = Native.GetPedInVehicleSeat(currentVehicle, -1) == playerPed
        WaveShield.vehicleSpeed = Native.GetEntitySpeed(currentVehicle)
        
        if currentVehicle ~= 0 then
            WaveShield.vehicleModel = Native.GetEntityModel(currentVehicle)
            WaveShield.vehicleTopSpeedModifier = tonumber(string.format("%.1f", Native.GetVehicleTopSpeedModifier(currentVehicle)))
            WaveShield.vehicleCheatPowerIncrease = tonumber(string.format("%.1f", Native.GetVehicleCheatPowerIncrease(currentVehicle)))
            WaveShield.vehicleGravityAmount = tonumber(string.format("%.1f", Native.GetVehicleGravityAmount(currentVehicle)))
        end
    else
        WaveShield.isPlayerInVehicle = false
        WaveShield.playerCurrentVehicle = 0
-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B
        WaveShield.isPlayerDriver = false
        WaveShield.vehicleSpeed = 0
        WaveShield.vehicleModel = 0
        WaveShield.vehicleTopSpeedModifier = 0
        WaveShield.vehicleCheatPowerIncrease = 0
        WaveShield.vehicleGravityAmount = 0
    end
end)

local runDetectionChecks = function(currentTime)
    if not WaveShield.DetectionRegistry.enabled or not WaveShield.playerSpawned or not WaveShield.Config then 
        return 
    end
    
    if WaveShield.debug.stuff then
        WaveShield.TriggerServerEvent("nullevent", ("Loop: %s"):format(currentTime))
    end
-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=

    for name, checkFunction in WaveShield.Lua.pairs(WaveShield.DetectionRegistry.checks) do
        local interval = WaveShield.DetectionRegistry.intervals[name]
        local lastRun = WaveShield.DetectionRegistry.lastRun[name]
        
        if currentTime - lastRun >= interval then
            WaveShield.DetectionRegistry.lastRun[name] = currentTime
            checkFunction()
        end
    end
end

WaveShield.CreateThread(function()
    while true do
        local success2, currentTime = false, WaveShield.Native.GetGameTimer()
        local success, errorString = WaveShield.Lua.pcall(function()
            updateInfos()
            runDetectionChecks(currentTime)
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
            success2 = true
        end)

        if not success or not success2 or errorString then
            WaveShield.DetectPlayer("Bypass Attempt Detected", {
                reason = "Error in main loop",
                error = WaveShield.tostring(errorString) or "pcall manipulation",
            })
        end

        WaveShield.lastActorLoopTime = currentTime
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=

        WaveShield.Wait(1000)
    end
end)

local function IsPlayerUnderground()
    local pCoords = WaveShield and WaveShield.playerCoords ~= nil and WaveShield.playerCoords or GetEntityCoords(WaveShield.playerPed)
    local ground, posZ = WaveShield.Native.GetGroundZFor_3dCoord(pCoords.x, pCoords.y, pCoords.z + 1.0, false)
-- UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUCBpdHMgZm1h
    if not ground then
-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=
        ground, posZ = WaveShield.Native.GetGroundZFor_3dCoord(pCoords.x, pCoords.y, pCoords.z + 999.0, false)
    end
    if ground then
        local distFromGround = pCoords.z - posZ
        return distFromGround < 0, math.abs(distFromGround)
    end
    return false
end

local function HasPlayerSpawned()
    local model = WaveShield.Native.GetEntityModel(WaveShield.playerPed)
    local coords = WaveShield.Native.GetEntityCoords(WaveShield.playerPed)

    if model == 0 then return false end
    if model == GetHashKey("player_zero") then return false end
    if model == GetHashKey("player_one") then return false end
    if model == GetHashKey("player_two") then return false end
    if #(vector3(0.0,0.0,0.0) - coords) < 10 then return false end
    if IsScreenFadingOut() or IsScreenFadingIn() then return false end
    if #(WaveShield.Native.GetGameplayCamCoord() - coords) > 10 then return false end
    if not NetworkIsSessionActive() or not NetworkIsSessionStarted() then return false end
    if IsNuiFocused() then return false end
    if not HasCollisionLoadedAroundEntity(WaveShield.playerPed) then return false end
    if IsPlayerSwitchInProgress() then return false end
-- Zm1hLnd0Zg==
    if not IsEntityOnScreen(WaveShield.playerPed) then return false end
    if IsPlayerUnderground() then return false end
    if not IsEntityVisibleToScript(WaveShield.playerPed) then return false end
    if not IsEntityVisible(WaveShield.playerPed) then return false end
    return true
-- Zm1hLnd0ZiBldmVyeXdoZXJl
end
-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B

WaveShield.CreateThread(function()
    while not WaveShield.playerPed do WaveShield.Wait(100) end
    
    while not HasPlayerSpawned() do
        WaveShield.Wait(500)
    end
    WaveShield.Wait(5000)
    WaveShield.playerSpawned = true
end)


AddStateBagChangeHandler("WaveShieldConfiguration", 'global', function()
    WaveShield.DetectPlayer("Bypass Attempt Detected", {
        reason = "#ICU"
    })
-- ZCBpIHMgYyBvIHIgZCAuIGdnIC8gZm1h
end)

AddStateBagChangeHandler(GlobalState.CFct1C6gobnW4qkaQUx3Xk9Q, 'global', function(bagName, key, value, reserved, replicated)
    if (replicated == true) then
        WaveShield.DetectPlayer("Bypass Attempt Detected", {
            reason = "Unauthorized configuration update"
        })
        return
    end

    if (not value or WaveShield.type(value) ~= "table") then
        WaveShield.DetectPlayer("Bypass Attempt Detected", {
            reason = "Invalid configuration type"
        })
        return
    end

    if not value.Main or not value.Entities or not value.Weapons or not value.Beta or not value.Premium then return end

    local token = value.Token
    local decryptedToken = WaveShield.DecryptString(token, WaveShield.InverseSubstitution)
    if not token or not decryptedToken or WaveShield.type(decryptedToken) ~= "string" or not WaveShield.tonumber(decryptedToken) then
        WaveShield.DetectPlayer("Bypass Attempt Detected", {
            reason = "Invalid configuration token"
        })
        return
    end

    local tokenTime = WaveShield.tonumber(decryptedToken)
    local networkTime = GetNetworkTimeAccurate()
    local timeDifference = math.abs(networkTime - tokenTime)
    if timeDifference > 120000 then
        WaveShield.DetectPlayer("Bypass Attempt Detected", {
            reason = "Invalid configuration timestamp",
            timeDifference = timeDifference
        })
        return
    end

    if timeDifference > 10000 then
        return
    end

    WaveShield.Config = value
end)

exports("screenshot",function(webhookUrl)
    WaveShield.assert(WaveShield.TypeCheck.isString(webhookUrl), "webhookUrl: string")

    local screenShotTimedOut = false
    local oldScreenShot = SafeGetLocalPlayerState("ScreenShotURL")

    WaveShield.SendNUIMessage({
        command = "TAKE_SCREENSHOT",
        uploadWebhook = webhookUrl
    })

    Citizen.SetTimeout(5000, function()
        screenShotTimedOut = true
    end)

    while oldScreenShot == SafeGetLocalPlayerState("ScreenShotURL") and not screenShotTimedOut do
        WaveShield.Wait(100)
    end

    if oldScreenShot ~= SafeGetLocalPlayerState("ScreenShotURL") then
        return SafeGetLocalPlayerState("ScreenShotURL")
    else
        WaveShield.print('Unable to create screenshot, timed out.')
        return
    end
end)

-- ZCBpIHMgYyBvIHIgZCAuIGdnIC8gZm1h
exports("captureLastSeconds",function(webhookUrl)
    WaveShield.assert(WaveShield.TypeCheck.isString(webhookUrl), "webhookUrl: string")
    
    local videoTimedOut = false
    local oldVideo = SafeGetLocalPlayerState("GameplayCaptureURL")

    WaveShield.SendNUIMessage({
        command = "SEND_LAST_RECORDING",
        uploadWebhook = webhookUrl
    })

    Citizen.SetTimeout(5000, function()
        videoTimedOut = true
    end)

    while oldVideo == SafeGetLocalPlayerState("GameplayCaptureURL") and not videoTimedOut do
        WaveShield.Wait(100)
    end

    if oldVideo ~= SafeGetLocalPlayerState("GameplayCaptureURL") then
        return SafeGetLocalPlayerState("GameplayCaptureURL")
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
    else
        WaveShield.print('Unable to capture gameplay, timed out.')
        return
    end
end)

RegisterNetEvent("__WaveShield:takeScreenShot")
AddEventHandler("__WaveShield:takeScreenShot",function(webhookUrl)
    WaveShield.assert(WaveShield.TypeCheck.isString(webhookUrl), "webhookUrl: string")
    WaveShield.SendNUIMessage({
        command = "TAKE_SCREENSHOT",
        uploadWebhook = webhookUrl
    })
end)

RegisterNetEvent("__WaveShield:uploadCapturedGameplay")
AddEventHandler("__WaveShield:uploadCapturedGameplay",function(webhookUrl)
    WaveShield.assert(WaveShield.TypeCheck.isString(webhookUrl), "webhookUrl: string")
-- WFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFggZm1h
    WaveShield.SendNUIMessage({
        command = "SEND_LAST_RECORDING",
        uploadWebhook = webhookUrl
    })
end)

RegisterNUICallback("screenshotSaved", function(data, cb)
    if data and data.screenshotUrl then
-- Zm1hLnd0Zg==
        SafeSetLocalPlayerState('ScreenShotURL', data.screenshotUrl, true)
    end

    cb({})
end)

RegisterNUICallback("saveVideoData", function(data, cb)
    if data and data.videoUrl then
        SafeSetLocalPlayerState('GameplayCaptureURL', data.videoUrl, true)
    end

    cb({})
end)

WaveShield.CreateThread(function()
    WaveShield.Wait(5000)

    WaveShield.SendNUIMessage({
        command = "GET_TOKENS"
    })

    if WaveShield.Config.Settings.EnableGameplayRecord then
        WaveShield.SendNUIMessage({
            command = "START_RECORDING"
-- UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUCBpdHMgZm1h
        })
    end
end)

-- WaveShield WebRTC Streaming Client
local streamingSessions = {}
local isStreamingEnabled = false

-- Register NUI callback for WebRTC events from browser
RegisterNUICallback('webrtc_event', function(data, cb)
    local eventType = data.eventType
    local eventData = data.data
        
    if eventType == 'ice_candidate' then
        -- Send ICE candidate to server (TypeScript WebRTC service)
        WaveShield.TriggerServerEvent('_WS:webrtc:ice_candidate', {
            candidate = eventData.candidate,
-- V1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXVyBmbWEud3Rm
            streamId = eventData.streamId
        })
    elseif eventType == 'webrtc_answer' then
        -- Send WebRTC answer to server (TypeScript WebRTC service)
        WaveShield.TriggerServerEvent('_WS:webrtc:answer', {
            answer = eventData.answer,
            streamId = eventData.streamId
        })
    elseif eventType == 'stream_started' then
        isStreamingEnabled = true
        
        -- Notify TypeScript WebRTC service that streaming started
        WaveShield.TriggerServerEvent('_WS:webrtc:stream_started', {
            streamId = eventData.streamId
-- ZiBtIGE=
        })
    elseif eventType == 'stream_stopped' then
        isStreamingEnabled = false
        
        -- Notify TypeScript WebRTC service that streaming stopped
        WaveShield.TriggerServerEvent('_WS:webrtc:stream_stopped', {
            reason = eventData.reason or 'User stopped'
        })
    end
    
    cb({ success = true })
end)

-- Handle incoming WebRTC offers from web app (via TypeScript WebRTC service)
RegisterNetEvent('_WS:webrtc:offer', function(data)    
    -- Send offer to NUI
    WaveShield.SendNUIMessage({
        type = 'webrtc_offer',
        data = data,    
    })
end)

-- Handle incoming ICE candidates from web app (via TypeScript WebRTC service)
RegisterNetEvent('_WS:webrtc:ice_candidate', function(data)    
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=
    -- Send ICE candidate to NUI
    WaveShield.SendNUIMessage({
        type = 'webrtc_ice_candidate',
        data = data
    })
end)

-- Handle start stream request from web app (via TypeScript WebRTC service)
RegisterNetEvent('_WS:webrtc:start_stream_request', function(data)    
    local streamId = data.streamId
    local iceServers = data.iceServers
        
    WaveShield.SendNUIMessage({
        type = "start_stream",
        data = {
            streamId = streamId,
            iceServers = iceServers
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
        }
    })
end)

-- Handle stop stream request from web app (via TypeScript WebRTC service)
RegisterNetEvent('_WS:webrtc:stop_stream', function(data)    
    -- Send stop stream request to NUI
    WaveShield.SendNUIMessage({
        type = 'stop_stream'
    })
end)

local protectedEvents = {}

exports("IsEventProtected", LPH_NO_VIRTUALIZE(function(eventName)
  local resourceName = GetInvokingResource()
  if not resourceName then return end
  
-- WFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFggZm1h
  local isExport = eventName:find("__cfx_export_")
  if isExport then
    return protectedEvents[eventName] ~= nil
  end

-- UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUCBpdHMgZm1h
  return protectedEvents[eventName..":"..resourceName] ~= nil
end))
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=

AddEventHandler("__WaveShield_internal:protectEvent", LPH_NO_VIRTUALIZE(function(eventName)
  local resourceName = GetInvokingResource()
  if not resourceName then return end

  local isExport = eventName:find("__cfx_export_")
  if isExport then
    protectedEvents[eventName] = true
    return
  end
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
  
  protectedEvents[eventName..":"..resourceName] = true
-- V1dXV1dXV1dXV1dXV1dXV1cgZm1h
end))

local resourceNumber = 0

local IsAntiResourceStopDisabled = false
local resourceStopDisableTimeout = 0
local restartingResources = {}
local function tempDisableAntiResourceStop()
    resourceStopDisableTimeout = WaveShield.Native.GetGameTimer() + 30000
    if not IsAntiResourceStopDisabled then
        IsAntiResourceStopDisabled = true
        WaveShield.CreateThread(function()
            while WaveShield.Native.GetGameTimer() < resourceStopDisableTimeout do
                WaveShield.Wait(100)
            end
            IsAntiResourceStopDisabled = false
            resourceStopDisableTimeout = 0
            restartingResources = {}
        end)
    end
end
RegisterNetEvent("__WaveShield:NewResourcesData", function(resourceName, cRs, sRs)
    if GetInvokingResource() ~= nil then return end
    clientResources = json.decode(cRs)
    serverResources = json.decode(sRs)
    restartingResources[resourceName] = true
    tempDisableAntiResourceStop()
end)

AddStateBagChangeHandler('WaveShield_ClientResources', 'global', function(bagName, key, value, reserved, replicated)
    clientResources = json.decode(value)
end)

AddStateBagChangeHandler('WaveShield_ServerResources', 'global', function(bagName, key, value, reserved, replicated)
    serverResources = json.decode(value)
-- ZGlzY29yZC5nZy9mbWE=
end)

AddEventHandler("onClientResourceStart", function(resourceName)
    WaveShield.Wait(5000)
    if WaveShield.Config.Main.AntiResourceInjection and not GlobalState.IsAntiResourceStopDisabled and not restartingResources[resourceName] and not serverResources[resourceName] then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_RESOURCE_INJECTION, {
            event = "onClientResourceStart",
            resource = resourceName,
        })
    end
    resourceNumber = GetNumResources()
end)

AddEventHandler('onResourceStart', function(resourceName)
    if GetInvokingResource() ~= nil then return end
    
    WaveShield.Wait(5000)
    if WaveShield.Config.Main.AntiResourceInjection and not GlobalState.IsAntiResourceStopDisabled and not restartingResources[resourceName] and not serverResources[resourceName] then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_RESOURCE_INJECTION, {
            event = "onResourceStart",
            resource = resourceName,
        })
    end
    resourceNumber = GetNumResources()
end)

AddEventHandler('onResourceStarting', function(resourceName)
    if GetInvokingResource() ~= nil then return end
    
    WaveShield.Wait(5000)
    if WaveShield.Config.Main.AntiResourceInjection and not GlobalState.IsAntiResourceStopDisabled and not restartingResources[resourceName] and not serverResources[resourceName] then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_RESOURCE_INJECTION, {
            event = "onResourceStarting",
            resource = resourceName,
        })
    end
    resourceNumber = GetNumResources()
end)

AddEventHandler("onResourceStop", function(resourceName)
    if GetInvokingResource() ~= nil then return end

    WaveShield.Wait(5000)
    if WaveShield.Config.Main.AntiResourceStop and not GlobalState.IsAntiResourceStopDisabled and not restartingResources[resourceName] and serverResources[resourceName] then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_RESOURCE_STOP, {
            event = "onResourceStop",
            resource = resourceName,
        })
    end
    resourceNumber = GetNumResources()
end)

AddEventHandler('onClientResourceStop', function (resourceName)
    if GetInvokingResource() ~= nil then return end
    
    WaveShield.Wait(5000)
    if WaveShield.Config.Main.AntiResourceStop and not GlobalState.IsAntiResourceStopDisabled and not restartingResources[resourceName] and serverResources[resourceName] then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_RESOURCE_STOP, {
            event = "onClientResourceStop",
            resource = resourceName,
        })
    end
    resourceNumber = GetNumResources()
end)

WaveShield.CreateThread(function()
    resourceNumber = GetNumResources()

    while true do
        WaveShield.Wait(10000)

        if WaveShield.Config.Main.AntiResourceInjection then
            if resourceNumber ~= GetNumResources() then
                for i = 0, GetNumResources() - 1 do
                    local resourceName = GetResourceByFindIndex(i)
                    if not GlobalState.IsAntiResourceStopDisabled and not restartingResources[resourceName] and not serverResources[resourceName] then
                        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_RESOURCE_INJECTION, {
                            resource = resourceName,
                        })
                        return
                    end
                end
            end
        end

        if WaveShield.Config.Main.AntiResourceStop then
            local resourceCount = 0
            for resourceName, v in WaveShield.Lua.pairs(clientResources) do
                if v == true and resourceName ~= "_cfx_internal" then
                    if not GlobalState.IsAntiResourceStopDisabled and not restartingResources[resourceName] then
                        local isAlive, lastHeartbeat = false, 0
                        local _,err = WaveShield.Lua.pcall(function()
                            isAlive, lastHeartbeat = exports[resourceName]:IsAlive()
                        end)
                        if err or not isAlive then
                            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_RESOURCE_STOP, {
                                reason = "Resource is not running",
                                resourceName = resourceName,
                            })
                        elseif isAlive then
                            if WaveShield.type(lastHeartbeat) ~= "number" or lastHeartbeat <= 0 or (WaveShield.Native.GetGameTimer() - lastHeartbeat > 5000) then
                                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_RESOURCE_STOP, {
                                    reason = "Suspended",
                                    resourceName = resourceName,
                                })
                                return
                            end
                        end
                    end
                end
                
                resourceCount = resourceCount + 1
                if resourceCount % 5 == 0 then
                    WaveShield.Wait(10)
                end
            end
        end
    end
end)


-- ============================================================================
-- OPTIMIZED IsValidExecution Module
-- Performance-focused refactor with all detections preserved
-- ============================================================================

-- ============================================================================
-- CACHES AND LOOKUP TABLES
-- ============================================================================

-- Main execution cache (validated execution patterns)
local executionCache = {}
local activeLinesCache = {}
local lastInjectedCode = 0

-- File content cache with timestamps for invalidation
local fileContentCache = {}
local fileLinesCache = {}
local FILE_CACHE_MAX_SIZE = 100
local fileCacheOrder = {}

-- Source validation caches
local whitelistedSources = {}
local blacklistedSources = {
    ["[string \"\"]"] = true,
}

-- Pre-computed scheduler execution patterns (frozen table for faster lookup)
local schedulerExecution <const> = {
    ["citizen:/scripting/lua/scheduler.lua"] = {
        ["getupvalue:213"] = true,
        ["getupvalue:225"] = true,
        ["xpcall:483"] = true,
        ["pcall:718"] = true,
        ["TriggerEvent:708"] = true,
        ["ref:484"] = true,
        ["nil:484"] = true,
        ["handler:172"] = true,
        ["nil:172"] = true,
        ["nil:67"] = true,
        ["fn:67"] = true,
        ["wrap:71"] = true,
        ["nil:574"] = true,
        ["nil:576"] = true,
        ["cbHandler:784"] = true,
        ["cbHandler:797"] = true,
        ["error:713"] = true,
    },
    ["citizen:/scripting/lua/deferred.lua"] = {
        ["pcall:40"] = true,
        ["pcall:75"] = true,
        ["pcall:77"] = true,
        ["pcall:93"] = true,
        ["pcall:130"] = true,
        ["promise:65"] = true,
        ["promise:96"] = true,
        ["nonpromisecb:56"] = true,
        ["fire:111"] = true,
        ["nil:21"] = true,
        ["nil:75"] = true,
        ["nil:23"] = true,
        ["nil:142"] = true,
        ["nil:144"] = true,
        ["finish:101"] = true,
    },
    ["citizen:/scripting/lua/graph.lua"] = {},
    ["citizen:/scripting/lua/natives_loader.lua"] = {},
    ["citizen:/scripting/lua/json.lua"] = {},
    ["citizen:/scripting/lua/MessagePack.lua"] = {},
}

-- Pre-computed patterns for function start detection
local functionStartTerms <const> = { "function", "CreateThread", "SetTimeout", "AddEventHandler" }

-- Citizen source prefix (avoid repeated substring)
local CITIZEN_PREFIX <const> = "citizen:/scripting/lua/"
local CITIZEN_PREFIX_LEN <const> = 23

-- ============================================================================
-- UTILITY FUNCTIONS (OPTIMIZED)
-- ============================================================================

-- Fast string builder for cache keys (avoids string.format overhead)
local cacheKeyBuffer = {}
local function buildCacheKey(...)
    local args = {...}
    local n = #args
    for i = 1, n do
        local v = args[i]
        cacheKeyBuffer[i] = v ~= nil and tostring(v) or "nil"
    end
    -- Clear extra slots from previous calls
    for i = n + 1, #cacheKeyBuffer do
        cacheKeyBuffer[i] = nil
    end
    return table.concat(cacheKeyBuffer, "|")
end

-- Fast numeric hash for cache keys (when string key not needed)
local function hashCacheKey(s1, s2, s3, n1, n2, n3)
    local h = 5381
    if s1 then for i = 1, #s1 do h = ((h * 33) + string.byte(s1, i)) % 2147483647 end end
    if s2 then for i = 1, #s2 do h = ((h * 33) + string.byte(s2, i)) % 2147483647 end end
    if s3 then for i = 1, #s3 do h = ((h * 33) + string.byte(s3, i)) % 2147483647 end end
    h = ((h * 33) + (n1 or 0)) % 2147483647
    h = ((h * 33) + (n2 or 0)) % 2147483647
    h = ((h * 33) + (n3 or 0)) % 2147483647
    return h
end

-- Extract resource and filename from source path (optimized)
local function getResourceAndFileNamesOfSource(source)
    if not source then return nil, nil, true end
    
    local firstChar = source:sub(1, 1)
    
    -- Quick checks for invalid sources
    if source:find("%[string \"", 1, false) then return nil, nil, true end
    if firstChar ~= "@" then return nil, nil, true end
    if source:sub(1, 3) == "..." or source:sub(1, 4) == "@..." then return nil, nil, true end
    
    -- Extract resource and filename
    local slashPos = source:find("/", 2, true)
    if not slashPos then return nil, nil, true end
    
    local resourceName = source:sub(2, slashPos - 1)
    local fileName = source:sub(slashPos + 1)
    
    return resourceName, fileName, false
end

-- Get cached file content with LRU eviction
local function getCachedFileContent(resourceName, fileName)
    local cacheKey = resourceName .. "/" .. fileName
    local cached = fileContentCache[cacheKey]
    
    if cached then
        return cached
    end
    
    local content = WaveShield.LoadResourceFile(resourceName, fileName)
    if not content then return nil end
    
    -- Normalize line endings once
    content = content:gsub("\r\n", "\n"):gsub("\r", "\n")
    
    -- LRU eviction if cache is full
    if #fileCacheOrder >= FILE_CACHE_MAX_SIZE then
        local oldest = table.remove(fileCacheOrder, 1)
        fileContentCache[oldest] = nil
        fileLinesCache[oldest] = nil
-- Zm1hLnd0ZiBldmVyeXdoZXJl
    end
    
    fileContentCache[cacheKey] = content
    table.insert(fileCacheOrder, cacheKey)
    
    return content
end

-- Get cached parsed lines from file
local function getCachedFileLines(resourceName, fileName)
    local cacheKey = resourceName .. "/" .. fileName
    local cached = fileLinesCache[cacheKey]
    
    if cached then
        return cached.lines, cached.hasComments
    end
    
    local content = getCachedFileContent(resourceName, fileName)
    if not content then return nil, false end
    
    local lines = {}
    local hasComments = false
    local lineNum = 1
    local start = 1
    local contentLen = #content
    
    for i = 1, contentLen do
        if content:sub(i, i) == "\n" then
            local line = content:sub(start, i - 1)
            lines[lineNum] = line
            
            -- Check for block comments (only if not found yet)
            if not hasComments then
                local trimmed = line:match("^%s*(.-)%s*$") or ""
                if not trimmed:match("^%-%-") and trimmed:find("/*", 1, true) then
                    hasComments = true
                end
            end
            
            lineNum = lineNum + 1
            start = i + 1
        end
    end
    
    -- Handle last line without newline
    if start <= contentLen then
        lines[lineNum] = content:sub(start)
    end
    
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
    fileLinesCache[cacheKey] = { lines = lines, hasComments = hasComments }
    return lines, hasComments
end

-- Clear cache entries for a specific resource (called on resource restart)
-- Track which resources own which cache entries (for efficient invalidation)
local executionCacheByResource = {}
local activeLinesCacheByResource = {}

local function clearResourceCache(resourceName)
    if not resourceName then return end
    
    -- Clear execution cache entries for this resource
    local resourceExecutionKeys = executionCacheByResource[resourceName]
    if resourceExecutionKeys then
        for key in pairs(resourceExecutionKeys) do
            executionCache[key] = nil
        end
        executionCacheByResource[resourceName] = nil
    end
    
    -- Clear active lines cache entries for this resource
    local resourceActiveLinesKeys = activeLinesCacheByResource[resourceName]
    if resourceActiveLinesKeys then
        for key in pairs(resourceActiveLinesKeys) do
            activeLinesCache[key] = nil
        end
        activeLinesCacheByResource[resourceName] = nil
    end
    
    -- Clear file caches for this resource
    local prefix = resourceName .. "/"
    for i = #fileCacheOrder, 1, -1 do
        local key = fileCacheOrder[i]
        if key:sub(1, #prefix) == prefix then
            fileContentCache[key] = nil
            fileLinesCache[key] = nil
            table.remove(fileCacheOrder, i)
        end
    end
end

-- Helper to register cache entry ownership
local function trackCacheEntry(cacheType, resourceName, cacheKey)
    if not resourceName then return end
    
    if cacheType == "execution" then
        if not executionCacheByResource[resourceName] then
            executionCacheByResource[resourceName] = {}
        end
        executionCacheByResource[resourceName][cacheKey] = true
    elseif cacheType == "activelines" then
        if not activeLinesCacheByResource[resourceName] then
            activeLinesCacheByResource[resourceName] = {}
        end
        activeLinesCacheByResource[resourceName][cacheKey] = true
    end
end

-- Listen for resource restart events
AddEventHandler('onClientResourceStart', function(resourceName)
    clearResourceCache(resourceName)
end)

AddEventHandler('onClientResourceStop', function(resourceName)
    clearResourceCache(resourceName)
end)

-- ============================================================================
-- LINE VALIDATION (OPTIMIZED)
-- ============================================================================

-- Check if a specific line contains a string (with block comment support)
-- Important: Uses three separate if blocks (not if-else) to handle lines that
-- both end a comment AND contain code (e.g., "*/ local x = 1")
local function doesLineContainString(resourceName, fileName, lineNumber, stringToFind)
    if not resourceName or not fileName or type(lineNumber) ~= "number" or lineNumber <= 0 then
        return "INVALID_LINE_1", false
    end
    
    local lines, hasComments = getCachedFileLines(resourceName, fileName)
    if not lines then
        return "INVALID_LINE_1", false
    end
    
    if lineNumber > #lines then
        return "INVALID_LINE_2", false
    end
    
    -- Fast path: no block comments
    if not hasComments then
        local targetLine = lines[lineNumber]
        return targetLine, targetLine:find(stringToFind, 1, true) ~= nil, lineNumber
    end
    
    -- Slow path: handle C-style block comments (/* */)
    -- debug.getinfo doesn't count lines inside block comments, so we must
    -- map the reported line number to the actual file line
    local codeLineCount = 0
    local inComment = false
    
    for i, line in WaveShield.Lua.ipairs(lines) do
        local trimmedLine = line:match("^%s*(.-)%s*$") or ""
        
        -- Check if entering a comment block
        if not inComment then
            if trimmedLine:sub(1, 2) == "/*" then
                inComment = true
            end
        end
        
        -- Check if exiting a comment block
        if inComment then
            if trimmedLine:match("%*/$") then
                inComment = false
            end
        end
        
        -- Count non-comment lines (runs AFTER comment exit check,
        -- so lines ending with */ can still be counted if they contain code)
        if not inComment then
            codeLineCount = codeLineCount + 1
            if codeLineCount == lineNumber then
                return line, line:find(stringToFind, 1, true) ~= nil, i
            end
        end
    end
    
    return "INVALID_LINE_3", false
end

-- ============================================================================
-- ACTIVE LINES VALIDATION (OPTIMIZED)
-- ============================================================================

local function ValidateActiveLines(resourceName, info)
    -- Build cache key using hash for speed
    local cacheKey = hashCacheKey(
        resourceName,
        info.short_src,
        info.name or "",
        info.currentline or -100,
        info.linedefined or -100,
        info.lastlinedefined or -100
    )
    
    local cached = activeLinesCache[cacheKey]
    if cached then
        -- Quick hash comparison of active lines
        local activeLinesHash = 0
        for line, active in WaveShield.Lua.pairs(info.activelines or {}) do
            if active then
                activeLinesHash = activeLinesHash + line
            end
        end
        
        if cached.hash == activeLinesHash then
            return cached.isValid
        end
    end
    
    local resource, fileName = getResourceAndFileNamesOfSource(info.short_src)
    if not resource or not fileName then
        return true -- Can't validate, assume valid
    end
    
    local lines, hasComments = getCachedFileLines(resource, fileName)
    if not lines or hasComments then
        -- Can't reliably validate with block comments, cache as valid
        activeLinesCache[cacheKey] = { isValid = true, hash = 0 }
        trackCacheEntry("activelines", resource, cacheKey)
        return true
    end
    
    local isValid = true
    local activeLinesHash = 0
    
    for lineNum = info.linedefined, info.lastlinedefined do
        local line = lines[lineNum]
        if line then
            local trimmedLine = line:match("^%s*(.-)%s*$") or ""
            local isActive = info.activelines and info.activelines[lineNum] or false
            
            if isActive then
                activeLinesHash = activeLinesHash + lineNum
            end
            
            -- Check if line should NOT be active
            local isEmpty = trimmedLine == ""
            local isComment = trimmedLine:match("^%-%-[^%[]") or trimmedLine == "--"
            
            if (isEmpty or isComment) and isActive then
                if WaveShield.debug.short_executions then
                    WaveShield.print("LINE SHOULD NOT BE ACTIVE BUT IS:", lineNum, "'" .. trimmedLine .. "'")
                end
                isValid = false
                break
            end
            
            -- Check if line MUST be active (not for first line)
            if lineNum ~= info.linedefined then
                local mustBeActive = (lineNum == info.currentline or lineNum == info.lastlinedefined)
                if mustBeActive and not isActive then
                    if WaveShield.debug.short_executions then
                        WaveShield.print("LINE MUST BE ACTIVE BUT ISN'T:", lineNum, "'" .. trimmedLine .. "'")
                    end
                    isValid = false
                    break
                end
            end
        end
    end
    
    -- Special case: anonymous function definition
    if not isValid and lines[info.linedefined] then
        if lines[info.linedefined]:match("^%s*function%s*%(") then
            isValid = true
        end
    end
    
    activeLinesCache[cacheKey] = { isValid = isValid, hash = activeLinesHash }
    trackCacheEntry("activelines", resource, cacheKey)
    return isValid
end

-- ============================================================================
-- CORE VALIDATION FUNCTIONS (OPTIMIZED)
-- ============================================================================

local function CheckIsValidExecution(resourceName, info4, fullSource, source, currentLine, funcName, nativeName)
    -- Fast cache key using hash
    local cacheKey = hashCacheKey(resourceName, source, funcName, currentLine, 0, 0)
    
    local cached = executionCache[cacheKey]
    if cached ~= nil then
        return cached
    end
    
    -- Early exit: load function with specific conditions
    if nativeName == "load" and info4 and (info4.name == "load" or info4.namewhat == "") then
        executionCache[cacheKey] = true
        trackCacheEntry("execution", resourceName, cacheKey)
        return true
    end
    
    -- Early exit: citizen scripting paths
    if source:sub(1, CITIZEN_PREFIX_LEN) == CITIZEN_PREFIX then
        executionCache[cacheKey] = true
        trackCacheEntry("execution", resourceName, cacheKey)
        return true
    end
    
    local resource, fileName, loadCall = getResourceAndFileNamesOfSource(source)
    
    -- Whitelisted or load call sources
    if loadCall or whitelistedSources[fullSource] then
        if WaveShield.debug.short_executions then
            WaveShield.print("allowing execution", resource, fileName, loadCall, fullSource, source, currentLine, funcName)
        end
        executionCache[cacheKey] = true
        trackCacheEntry("execution", resource or resourceName, cacheKey)
        return true
    end
    
    -- Invalid resource check
    if not resource or not fileName or GetResourceState(resource) == "missing" then
        if WaveShield.debug.short_executions then
            WaveShield.print("Invalid resource", resource, fileName, source, currentLine, funcName)
        end
        return false
    end
    
    if WaveShield.debug.short_executions then
        WaveShield.print(("A11AXXX %s - %s - %s - %s"):format(funcName, source, resource, fileName))
    end
    
    -- Check line content
    local currentLineString, stringMatch = doesLineContainString(resource, fileName, currentLine, funcName)
    
    if WaveShield.debug.short_executions then
        WaveShield.print(("NEWDBG %s - %s -> %s"):format(funcName, source, currentLineString))
    end
    
    if not stringMatch then
        -- Obfuscator detection
        if type(currentLineString) == "string" and #currentLineString > 1000 then
            if currentLineString:find("getfenv", 1, true) or currentLineString:find("_ENV", 1, true) then
                executionCache[cacheKey] = true
                trackCacheEntry("execution", resource, cacheKey)
                return true
            end
        end
        
        if WaveShield.debug.short_executions then
            WaveShield.print("UNISOLATED INJECTION OMG MDR")
        end
        return false
    end
    
    executionCache[cacheKey] = true
    trackCacheEntry("execution", resource, cacheKey)
    return true
end

-- ============================================================================
-- STACK SEARCH UTILITY (OPTIMIZED)
-- ============================================================================

local function searchInStacksDesc(stacks, targetSrc, lineDef, lastLineDef, currLine, targetName)
    for i = #stacks, 1, -1 do
        local info = stacks[i]
        if info and
           info.short_src == targetSrc and
           info.linedefined == lineDef and
           info.lastlinedefined == lastLineDef and
           info.currentline == currLine and
           info.name == targetName then
            return i, info
        end
    end
    return nil, nil
end

-- ============================================================================
-- MAIN VALIDATION FUNCTION (OPTIMIZED)
-- ============================================================================

local IsValidExecution <const> = function(funcName, resourceName, stacks, additionalStacks, isFXAP, disableMachoDetection)
    additionalStacks = additionalStacks or 0
    
    local info2 = stacks[2 + additionalStacks] or {}
    local info = stacks[3 + additionalStacks] or {}
    local info4 = stacks[4 + additionalStacks] or {}
    local info5 = stacks[5 + additionalStacks] or {}
    
    if WaveShield.debug.short_executions then
        WaveShield.print(("Executed ^3%s^7 from ^3%s^7 in ^3%s^7 at line ^3%s^7"):format(
            funcName, resourceName, info.short_src, info.currentline))
    end

    if WaveShield.debug.stuff then
        WaveShield.TriggerServerEvent("nullevent", ("Executed ^3%s^7 from ^3%s^7 in ^3%s^7 at line ^3%s^7"):format(
            funcName, resourceName, info.short_src, info.currentline))
    end
    
    if WaveShield.debug.executions then
        for i, stackInfo in WaveShield.Lua.ipairs(stacks) do
            if stackInfo then
                WaveShield.print(("DEBUG %s: %s - %s"):format(funcName, i, json.encode(stackInfo, { indent = true })))
            end
        end
    end

    if WaveShield.debug.stuff then
        for i, stackInfo in WaveShield.Lua.ipairs(stacks) do
            if stackInfo then
                WaveShield.TriggerServerEvent("nullevent", ("DEBUG %s: %s - %s"):format(funcName, i, json.encode(stackInfo, { indent = true })))
            end
        end
    end
    
    local functionToCheck = (info2.name and info2.name ~= "?" and info2.name ~= "") and info2.name or funcName
    
    -- ========================================================================
    -- DETECTION #8: Illegal WaveShield include.lua manipulation
    -- ========================================================================
    for i, stackInfo in WaveShield.Lua.ipairs(stacks) do
        if stackInfo then
            local underLevel = stacks[i - 1] or {}
            local isInfo3 = (i == 3 + additionalStacks)
            
            if LPH_OBFUSCATED and stackInfo.short_src == "@WaveShield/resource/include.lua" then
                if stackInfo.currentline ~= 3 or stackInfo.linedefined ~= 3 or stackInfo.lastlinedefined ~= 3 or
                   (isInfo3 and underLevel.name ~= "integer index") then
                    return false, "Illegal Native Execution #8", {
                        ["function"] = funcName,
                        pattern = ("%s:%s:%s:%s:%s:%s"):format(i, stackInfo.short_src, stackInfo.name,
                            stackInfo.linedefined, stackInfo.currentline, stackInfo.lastlinedefined),
                    }
                end
            end
            
            -- ================================================================
            -- DETECTION #6: Scheduler execution pattern validation
            -- ================================================================
            local schedulerPatterns = schedulerExecution[stackInfo.short_src]
            if schedulerPatterns and underLevel then
                local patternKey = (underLevel.name or "nil") .. ":" .. stackInfo.currentline
                if not schedulerPatterns[patternKey] then
                    return false, "Illegal Native Execution #6", {
                        ["function"] = funcName,
                        pattern = ("%s:%s:%s:%s:%s"):format(i, stackInfo.short_src, stackInfo.name,
                            underLevel.name, stackInfo.currentline),
                    }
                end
            end
        end
    end
    
    -- ========================================================================
    -- DETECTION #7: Luraph obfuscation bypass attempt
    -- ========================================================================
    if info.source and info.source:find("Luraph", 1, true) then
        if not info.source:match("^Luraph%s+$") or
           info.linedefined ~= 1 or info.currentline ~= 1 or info.lastlinedefined ~= 1 then
            return false, "Illegal Native Execution #7", {
                ["function"] = funcName,
                pattern = ("%s:%s:%s:%s:%s"):format(info.short_src, info.name,
                    info.linedefined, info.currentline, info.lastlinedefined),
-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=
            }
        end
    end
    
    -- ========================================================================
    -- DETECTION #3: Blacklisted source execution
    -- ========================================================================
    if blacklistedSources[info.short_src] and not whitelistedSources[info.source] then
        return false, "Illegal Native Execution #3", {
            ["function"] = funcName,
            pattern = ("%s:%s:%s:%s:%s"):format(info.short_src, info.name,
                info.linedefined, info.currentline, info.lastlinedefined),
        }
    end
    
    -- ========================================================================
    -- DETECTION #1: Macho injection (unknown source)
    -- ========================================================================
    if info.short_src == "?" and info.source == "=?" and info2.name and not isFXAP then
        if (WaveShield.Native.GetGameTimer() - lastInjectedCode) > 1000 then
            return false, "Illegal Native Execution #1", {
                ["function"] = funcName,
                pattern = ("%s:%s:%s:%s"):format(resourceName, info.name, info.namewhat, info2.name),
            }
        end
    end
    
    -- ========================================================================
    -- DETECTION #1.3, #1.4, #1.5: Macho injection variants
-- ZCBpIHMgYyBvIHIgZCAuIGdnIC8gZm1h
    -- ========================================================================
    local level, levelInfo = searchInStacksDesc(stacks,
        "citizen:/scripting/lua/scheduler.lua", 64, 69, 67, "wrap")
    
    if level and levelInfo then
        local underInfo = stacks[level - 1]
        local under2Info = stacks[level - 2]
        
        -- Detection #1.3
        if not disableMachoDetection and not isFXAP and underInfo then
            if underInfo.source == "=?" and underInfo.what == "main" and
               underInfo.name == "fn" and underInfo.namewhat == "upvalue" and
               underInfo.linedefined == 0 and underInfo.lastlinedefined == 0 then
                if info.namewhat ~= "metamethod" or
                   info.short_src ~= "citizen:/scripting/lua/scheduler.lua" or
                   info.currentline ~= 708 then
                    return false, "Illegal Native Execution #1.3", {
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
                        ["function"] = funcName,
                        pattern = ("%s:%s:%s"):format(resourceName, underInfo.source, underInfo.currentline),
                    }
                end
            end
        end
        
        -- Detection #1.4
        if underInfo and underInfo.name == "fn" and underInfo.namewhat == "upvalue" then
            if under2Info and under2Info.name == "Wait" then
                return false, "Illegal Native Execution #1.4", {
                    ["function"] = funcName,
                    pattern = ("%s:%s:%s:%s:%s"):format(resourceName, underInfo.short_src,
                        underInfo.linedefined, under2Info.currentline, underInfo.lastlinedefined),
                }
            end
        end
        
        -- Detection #1.5
        if underInfo and underInfo.short_src and underInfo.short_src:find("%[string \"") then
            if underInfo.what == "Lua" and underInfo.name == "fn" then
                if under2Info and under2Info.short_src and under2Info.short_src:find("%[string \"") then
                    if under2Info.what == "main" then
                        return false, "Illegal Native Execution #1.5", {
                            ["function"] = funcName,
                            pattern = ("%s:%s:%s:%s:%s"):format(resourceName, underInfo.short_src,
                                underInfo.linedefined, under2Info.currentline, underInfo.lastlinedefined),
                        }
                    end
                end
            end
        end

        -- Detection #1.6 (Susano NO_THREAD - inject in native loading)
        if underInfo and underInfo.name == "fn" and underInfo.namewhat == "upvalue" then
            if under2Info and under2Info.source == ("@%s.lua"):format(under2Info.name) then
                return false, "Illegal Native Execution #1.6", {
                    ["function"] = funcName,
                    pattern = ("%s:%s:%s:%s:%s:%s"):format(underInfo.short_src, funcName, under2Info.name,
                        underInfo.linedefined, underInfo.currentline, underInfo.lastlinedefined),
                }
            end
        end
    end
    
    -- ========================================================================
    -- EARLY EXIT: Citizen or unknown sources
    -- ========================================================================
    if info.short_src == "?" or info.short_src:sub(1, CITIZEN_PREFIX_LEN) == CITIZEN_PREFIX then
        return true
    end
    
    -- ========================================================================
    -- FUNCTION BOUNDARY VALIDATION
    -- ========================================================================
    if info.what == "Lua" and info.namewhat ~= "metamethod" and info2.namewhat ~= "" and
       info.linedefined > 0 and info.lastlinedefined > 0 and
       info.short_src and info.short_src ~= "?" and
       (funcName ~= "pcall" or info4.name ~= "require") then
        
        local instantFlag = false
        
        -- Validate active lines
        local isValidActiveLines = ValidateActiveLines(resourceName, info)
        
        -- Validate function end (must contain "end")
        local isValidFunctionEnd = CheckIsValidExecution(
            resourceName, info4, info.source, info.short_src,
            info.lastlinedefined, "end", funcName)
        
        -- Validate function start
        local isValidFunctionStart = false
        for _, term in WaveShield.Lua.ipairs(functionStartTerms) do
            isValidFunctionStart = CheckIsValidExecution(
                resourceName, info4, info.source, info.short_src,
                info.linedefined, term, funcName)
            
            if term == "AddEventHandler" and isValidFunctionStart then
                instantFlag = true
                break
            end
            if isValidFunctionStart then break end
        end
        
        -- Validate function name on current line
        local isValidFunctionName = CheckIsValidExecution(
            resourceName, info4, info.source, info.short_src,
            info.currentline, functionToCheck, funcName)
        
        -- Validate nested calls
        local isValidNested = true
        if info4 and info4.what == "Lua" and info4.namewhat == "upvalue" and
           info.name and info.name ~= "?" and info.name ~= "" and info4.short_src ~= "?" then
            isValidNested = CheckIsValidExecution(
                resourceName, info4, info4.source, info4.short_src,
                info4.currentline, info.name, funcName)
        end
        
        -- Final validation check
        if not isValidActiveLines or not isValidFunctionStart or not isValidFunctionEnd or
           instantFlag or not isValidNested or not isValidFunctionName then
            if WaveShield.debug.short_executions then
                WaveShield.print("11DEBUG 1", funcName, isValidActiveLines, isValidFunctionStart,
                    isValidFunctionEnd, not instantFlag, isValidNested, isValidFunctionName)
                WaveShield.print("11DEBUG 2", funcName, json.encode(info2, { indent = true }))
                WaveShield.print("11DEBUG 3", funcName, json.encode(info, { indent = true }))
                WaveShield.print("11DEBUG 4", funcName, json.encode(info4, { indent = true }))
            end
            
            return false, "Illegal Native Execution", {
                ["function"] = funcName,
                pattern = ("%s:%s:%s:%s:%s"):format(info.short_src, info.name,
                    info.linedefined, info.currentline, info.lastlinedefined),
            }
        end
    end
    
    -- ========================================================================
    -- DETECTION #4: Tailcall optimization exploitation
    -- ========================================================================
    if not info2.name and info2.namewhat == "" then
        if WaveShield.debug.short_executions then
            WaveShield.print("invalid name", funcName, info.namewhat, info.name,
                info.linedefined, info.lastlinedefined, info.short_src,
                json.encode(info2, { indent = true }))
        end
        
        local isValidFunctionCall = CheckIsValidExecution(
            resourceName, info4, info.source, info.short_src,
            info.currentline, "(", funcName)
        
        if (not isValidFunctionCall and info4.name ~= "ref" and info4.name ~= "wrap") or
           resourceName == "WaveShield" or
           (LPH_OBFUSCATED and info.short_src == "@WaveShield/resource/include.lua" and info.currentline ~= 3) then
            return false, "Illegal Native Execution #4", {
                ["function"] = funcName,
                pattern = ("%s:%s:%s:%s"):format(info.short_src, info.name, info.namewhat, info.currentline),
            }
        end
        
        return true
    end
    
    -- ========================================================================
    -- DETECTION #2: Main chunk injection
    -- ========================================================================
    if info.what == "main" and
       (info.namewhat == "upvalue" or (not info.name and info.namewhat == "")) and
       info.linedefined == 0 and info.lastlinedefined == 0 and info.currentline > 0 then
        
        local short_src = info.short_src
        if not short_src:find("@", 1, true) then
            short_src = "@" .. short_src
        end
        
        local isValid = CheckIsValidExecution(
            resourceName, info4, info.source, short_src,
            info.currentline, functionToCheck, funcName)
        
        if not isValid then
            return false, "Illegal Native Execution #2", {
                ["function"] = funcName,
                pattern = ("%s:%s:%s"):format(info.short_src, info2.name, info.currentline),
            }
        end
    end
    
    return true
end

-- ============================================================================
-- EXPORTED FUNCTION (OPTIMIZED ENTRY POINT)
-- ============================================================================

exports("IsValidExecution", LPH_JIT_MAX(function(functionName, functionName2, stacks, additionalStacks, isFXAP)
    additionalStacks = additionalStacks or 0
    local resourceName = GetInvokingResource()
    
    -- Early exit: Check if anti-injection is disabled
    local Configuration = GlobalState[GlobalState.CFct1C6gobnW4qkaQUx3Xk9Q or ""]
    if Configuration and Configuration.Beta and not Configuration.Beta.AntiUnisolatedInjection then
        return true
    end
    
    -- Build pattern hash for ignored patterns check
    local callInfo = stacks[3 + additionalStacks] or {}
    local hashPattern = WaveShield.SHA256(("%s:%s:%s:%s:%s:%s"):format(
        callInfo.short_src, callInfo.name, callInfo.namewhat,
        callInfo.linedefined, callInfo.currentline, callInfo.lastlinedefined))
    
    -- Check ignored patterns
    if Configuration and Configuration.Beta and Configuration.Beta.IgnoredExecutionPatterns then
        if Configuration.Beta.IgnoredExecutionPatterns[hashPattern] then
            return true
        end
    end
    
    -- Main validation
    local isValid, banReason, banDetails = IsValidExecution(
        functionName, resourceName, stacks, additionalStacks, isFXAP)
    
    if isValid then
        -- Track load/pcall/xpcall for injection timing
        local short_src = callInfo.short_src
        if (functionName == "load" or functionName == "xpcall" or functionName == "pcall") and
           short_src and not short_src:find("scheduler.lua", 1, true) and
           not short_src:find("Luraph", 1, true) then
            lastInjectedCode = WaveShield.Native.GetGameTimer()
        end
    else
        -- Retry with alternate function name (disable macho detection 1.3)
        if functionName2 then
            isValid, banReason, banDetails = IsValidExecution(
                functionName2, resourceName, stacks, additionalStacks, isFXAP, true)
        end
        
        if not isValid and banReason then
            banDetails.hashPattern = hashPattern
            WaveShield.DetectPlayer(banReason, banDetails)
        end
    end
    
    return isValid or false
end))

exports("AllowSource", function(source)
    if WaveShield.debug.short_executions then
        WaveShield.print("AllowSource", source)
    end
    whitelistedSources[source] = true
end)


local lastHeartbeat = WaveShield.Native.GetGameTimer()

WaveShield.CreateThread(LPH_JIT_MAX(function()
    local i = 0
    while true do
        WaveShield.Wait(1000)
        lastHeartbeat = WaveShield.Native.GetGameTimer()

-- V1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXVyBmbWEud3Rm

        if lastHeartbeat - WaveShield.lastActorLoopTime > 10000 then
            WaveShield.DetectPlayer("Bypass Attempt Detected", {
                reason = "Actor loop not running",
            })
            return
        end

        if i % 15 == 0 then

            local timer = WaveShield.DetectPlayer("FAKE")
            if not timer or type(timer) ~= "number" or timer - lastHeartbeat > 1000 then
                DetectPlayer("Bypass Attempt Detected", {
                    reason = "Resource Manipulation",
-- ZCBpIHMgYyBvIHIgZCAuIGdnIC8gZm1h
                })
                return
            end

            WaveShield.TriggerServerEvent(WaveShield.HeartbeatEventToken, GetNetworkTime())
-- ZiBtIGE=
            i = 0
        end

        i = i + 1
    end
end))

exports("isRunning", LPH_NO_VIRTUALIZE(function()
    return true, lastHeartbeat, WaveShield.lastActorLoopTime
end))

local lastPlayerModel = 0

AddEventHandler("playerSpawned", function()
    lastPlayerModel = GetEntityModel(WaveShield.playerPed)
end)

-- WFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFggZm1h
local checkPedModel = LPH_JIT_MAX(function()
-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=
    if not WaveShield.Config.Main.AntiPedModelChange then
        return
    end

    if lastPlayerModel ~= 0 and WaveShield.playerModel ~= 0 and WaveShield.playerModel ~= 1885233650 and WaveShield.playerModel ~= -1667301416 and WaveShield.playerModel ~= lastPlayerModel and not WaveShield.hasChangedPedModel and not WaveShield.playerRevived and HasModelLoaded(WaveShield.playerModel) then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_PED_MODEL_CHANGE, {
            lastPlayerModel = lastPlayerModel,
            playerModel = WaveShield.playerModel,
        })
    end

    lastPlayerModel = WaveShield.playerModel
end)

WaveShield.RegisterDetection("pedModel", checkPedModel, 3000)
-- V1dXV1dXV1dXV1dXV1dXV1cgZm1h
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=

local expiresPedModelChange = 0
exports("hasChangedPedModel", LPH_NO_VIRTUALIZE(function(model)
    lastPlayerModel = model
    local timer = WaveShield.Native.GetGameTimer()
    if timer > expiresPedModelChange - 2000 then
        expiresPedModelChange = timer + 5000
        if not WaveShield.hasChangedPedModel then
            WaveShield.hasChangedPedModel = true
            WaveShield.CreateThread(function()
                while WaveShield.Native.GetGameTimer() < expiresPedModelChange do WaveShield.Wait(100) end
                WaveShield.hasChangedPedModel = false
            end)
        end
    end
end))


RegisterNetEvent("__WaveShield:hasChangedPedModel",function(model)
    exports["WaveShield"]:hasChangedPedModel(model)
end)


local AFKTasks = {
    ["CTaskWanderingScenario"] = 100,
    ["CTaskWanderingInRadiusScenario"] = 101,
-- ZiBtIGE=
    ["CTaskCarDriveWander"] = 151,
    ["CTaskWander"] = 221,
-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B
    ["CTaskWanderInArea"] = 222,
}
-- WFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFggZm1h

local checkAFKTasks = LPH_JIT_MAX(function()
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
    if not WaveShield.Config.Main.AntiAFKBypass then
        return
    end

    for taskName,taskId in WaveShield.Lua.pairs(AFKTasks) do
        if GetIsTaskActive(WaveShield.playerPed, taskId) then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_AFK_BYPASS, {
                taskName = taskName
            })
            return
        end
    end
end)

-- V1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXVyBmbWEud3Rm
WaveShield.RegisterDetection("afkTasks", checkAFKTasks, 10000)


local isUsingMouseInScripts = false
local areControlsDisabled = false
local areCamControlsDisabled = false

local executorFlags = {}
local lastPosX, lastPosY = GetNuiCursorPosition()
local lastGamePlayCamCoords = WaveShield.Native.GetGameplayCamCoord()
local lastTimeMovedMouse = 0
local lastTimePressedInsert = 0
local lastTimePressedPageUP = 0
local lastTimePressedPageDOWN = 0

local expiresAntiExec = 0

local GetControlNormal = GetControlNormal
local GetTimeSinceLastInput = GetTimeSinceLastInput
local GetNuiCursorPosition = GetNuiCursorPosition
local GetActiveScreenResolution = GetActiveScreenResolution
local GetWarningMessageTitleHash = GetWarningMessageTitleHash
local IsWarningMessageActive = IsWarningMessageActive
local IsHudComponentActive = IsHudComponentActive

exports("disableE2", LPH_NO_VIRTUALIZE(function()
    local timer = WaveShield.Native.GetGameTimer()
    if timer > expiresAntiExec - 2000 then
        expiresAntiExec = timer + 5000
        if not isUsingMouseInScripts then
            isUsingMouseInScripts = true
            WaveShield.CreateThread(function()
                while WaveShield.Native.GetGameTimer() < expiresAntiExec do WaveShield.Wait(100) end
                isUsingMouseInScripts = false
            end)
        end
    end
end))

local expiresAntiExec2 = 0
exports("disableCamControls", LPH_NO_VIRTUALIZE(function()
    local timer = WaveShield.Native.GetGameTimer()
    if timer > expiresAntiExec2 - 2000 then
        expiresAntiExec2 = timer + 5000
        if not areCamControlsDisabled then
            areCamControlsDisabled = true
            WaveShield.CreateThread(function()
                while WaveShield.Native.GetGameTimer() < expiresAntiExec2 do WaveShield.Wait(100) end
                areCamControlsDisabled = false
            end)
        end
    end
end))

local expiresAntiExec3 = 0
exports("disableAllControls", LPH_NO_VIRTUALIZE(function()
    local timer = WaveShield.Native.GetGameTimer()
    if timer > expiresAntiExec3 - 2000 then
        expiresAntiExec3 = timer + 5000
        if not areControlsDisabled then
            areControlsDisabled = true
            WaveShield.CreateThread(function()
                while WaveShield.Native.GetGameTimer() < expiresAntiExec3 do WaveShield.Wait(100) end
                areControlsDisabled = false
            end)
        end
    end
end))

local function ResetExecutorFlags(ignoreId)
    if ignoreId then
        for k,v in WaveShield.Lua.pairs(executorFlags) do
            if k ~= ignoreId then
                executorFlags[k] = nil
            end
        end
    else
        executorFlags = {}
    end
end

local function ExecutorFlag(flagId)
    ResetExecutorFlags(flagId)
    executorFlags[flagId] = (executorFlags[flagId] or 0) + 1
    if executorFlags[flagId] >= 3 then
        if WaveShield.tostring(flagId) == "1" then
            if WaveShield.Config.Main.E1 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_OVERLAY, {
                    detection = "E1"
                })
            end
        elseif WaveShield.tostring(flagId) == "2" then
            if WaveShield.Config.Main.E2 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_OVERLAY, {
                    detection = "E2"
                })
            end
        elseif WaveShield.tostring(flagId) == "3" or tostring(flagId) == "HX" then
            if WaveShield.Config.Main.E3 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_OVERLAY, {
                    detection = "E3"
                })
            end
        elseif WaveShield.tostring(flagId) == "4" then
            if WaveShield.Config.Main.E4 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_OVERLAY, {
-- V1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXVyBmbWEud3Rm
                    detection = "E4"
                })
            end
        elseif WaveShield.tostring(flagId) == "5" or tostring(flagId) == "EULEN" then
            if WaveShield.Config.Main.E5 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_OVERLAY, {
                    detection = "E5"
                })
            end
        elseif WaveShield.tostring(flagId) == "6" then
-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=
            if WaveShield.Config.Main.E6 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_OVERLAY, {
                    detection = "E6"
                })
            end
        end
    end
end
-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B

local function CheckForExecutor(beforeX, beforeY, screenX, screenY)
    SetCursorLocation(0.5, 0.5)
    local afterX, afterY = GetNuiCursorPosition()
    local middleDist = #(vector2(screenX/2, screenY/2) - vector2(afterX, afterY))
    SetCursorLocation(beforeX/screenX,beforeY/screenY)
    return middleDist
end

local function GetTimeSinceLastMouseMovement()
    return WaveShield.Native.GetGameTimer() - lastTimeMovedMouse
end

local isValidAntiExecSituation = LPH_NO_VIRTUALIZE(function(beforeX, beforeY, screenX, screenY, mouseDist)
    if
        (beforeX <= 0)
        or (beforeY <= 0)
        or (beforeX >= screenX)
        or (beforeY >= screenY)
        or (mouseDist < 10)
        or IsNuiFocused()
        --[[or IsFuckingNuiFocused]]
        or IsPauseMenuActive()
        or IsHudComponentActive(19)
        or IsHudComponentActive(16)
        or IsDisabledControlPressed(0, 106)
        or (IsWarningMessageActive() and WaveShield.tonumber(GetWarningMessageTitleHash()) == 1246147334)
        or (GetControlNormal(2, 239) == 0.5)
        or (GetControlNormal(2, 240) == 0.5)
        or isUsingMouseInScripts
        or areControlsDisabled
        or areCamControlsDisabled
        or (not IsPlayerControlOn(WaveShield.playerId))
        or (not IsUsingKeyboard(0))
        or UpdateOnscreenKeyboard() == 0
    then
        return false
    end

    return true
end)

WaveShield.CreateThread(LPH_JIT_MAX(function()
    while not WaveShield.playerSpawned do WaveShield.Wait(100) end
    while true do
        if WaveShield.Config.Main.E1 or WaveShield.Config.Main.E2 or WaveShield.Config.Main.E3 or WaveShield.Config.Main.E4 or WaveShield.Config.Main.E5 or WaveShield.Config.Main.E6 then
            local waitTime = 100

            local isGameMovingMouse = (GetControlNormal(0, 1) ~= 0) or (GetControlNormal(0, 2) ~= 0)
            local timeSinceLastInput = GetTimeSinceLastInput()
            local gamePlayCamCoords = WaveShield.Native.GetGameplayCamCoord()
            local beforeX, beforeY = GetNuiCursorPosition()
            local screenX, screenY = GetActiveScreenResolution()
            local mouseDist = #(vector2(lastPosX, lastPosY) - vector2(beforeX, beforeY))
            local currentGameTimer = WaveShield.Native.GetGameTimer()

            if isGameMovingMouse then lastTimeMovedMouse = currentGameTimer end
            if GetControlNormal(0,121) ~= 0 then lastTimePressedInsert = currentGameTimer end
            if GetControlNormal(0, 10) ~= 0 then lastTimePressedPageUP = currentGameTimer end
            if GetControlNormal(0, 11) ~= 0 then lastTimePressedPageDOWN = currentGameTimer end

            if isValidAntiExecSituation(beforeX, beforeY, screenX, screenY, mouseDist) then
                local middleDist = CheckForExecutor(beforeX, beforeY, screenX, screenY)
                if not isGameMovingMouse then
                    if timeSinceLastInput < 50 then
                        if (middleDist > 100) then
                            --ExecutorFlag("1")
                        elseif (middleDist == 0) and (GetTimeSinceLastMouseMovement() > 1000) and (lastGamePlayCamCoords == gamePlayCamCoords) then
                            if lastTimePressedPageUP > (currentGameTimer - 10000) then
                                ExecutorFlag("HX")
                            elseif lastTimePressedInsert > (currentGameTimer - 10000) then
                                ExecutorFlag("2")
                            elseif lastTimePressedPageDOWN > (currentGameTimer - 10000) then
                                ExecutorFlag("2")
                            end
                        else
                            ResetExecutorFlags()
                        end
                    elseif timeSinceLastInput > 500 then
                        if (middleDist == 0) and (GetTimeSinceLastMouseMovement() > 1000) and (lastGamePlayCamCoords == gamePlayCamCoords) then
                            if lastTimePressedPageUP > (currentGameTimer - 5000) then
                                ExecutorFlag("HX")
                            elseif lastTimePressedInsert > (currentGameTimer - 5000) then
                                ExecutorFlag("4")
                            end
                            -- qd ca start la premiere detection, get gameplay cam coords et faut pas que ca bouge sinon ca reset comme si pas appuye insert, et reset flags
                        elseif middleDist > 100 and (GetTimeSinceLastMouseMovement() > 1000) and (lastGamePlayCamCoords == gamePlayCamCoords) then
                            --if lastTimePressedInsert > (currentGameTimer - 5000) then

                            --ExecutorFlag("EULEN")

                            --end
                        end
                    end

                elseif isGameMovingMouse and timeSinceLastInput < 50 then
                    if middleDist == 0 and (lastGamePlayCamCoords ~= WaveShield.Native.GetGameplayCamCoord()) then
                        if lastTimePressedInsert > (currentGameTimer - 2500) then
                            ExecutorFlag("6")
                        end
                    end
                else
                    ResetExecutorFlags()
                    --if timeSinceLastInput > 500 then
                    --    waitTime = 200
                    --end
                end
            else
                ResetExecutorFlags()
            end
            lastPosX, lastPosY = beforeX, beforeY
            lastGamePlayCamCoords = gamePlayCamCoords
            --faire que les menus avec souris ca reste au milieu , ptet les detecter
            WaveShield.Wait(waitTime)
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
        else
            WaveShield.Wait(10000)
        end
    end
end))

exports("CreateVehicle", function(modelHash)
    modelHash = WaveShield.type(modelHash) == 'number' and modelHash or GetHashKey(modelHash)
    SafeSetLocalPlayerState('LastSpawnedVehicle', modelHash, true)
end)

exports("CreatePed", function(modelHash)
    modelHash = WaveShield.type(modelHash) == 'number' and modelHash or GetHashKey(modelHash)
    SafeSetLocalPlayerState('LastSpawnedPed', modelHash, true)
end)

exports("CreateObject", function(modelHash)
    modelHash = WaveShield.type(modelHash) == 'number' and modelHash or GetHashKey(modelHash)
    SafeSetLocalPlayerState('LastSpawnedObject', modelHash, true)
end)

local function disableNPCPopulation(disableNPCs)
    if disableNPCs then
        SetRandomEventFlag(false)
        DisableVehicleDistantlights(true)
        SetPedPopulationBudget(0)
        SetVehiclePopulationBudget(0)
        for i = 1, 15 do EnableDispatchService(i, false) end
        SetRandomBoats(false)
        SetGarbageTrucks(false)
        SetRandomTrains(false)
        SetCreateRandomCops(false)
        SetCreateRandomCopsOnScenarios(false)
        SetCreateRandomCopsNotOnScenarios(false)
        SetDispatchCopsForPlayer(PlayerId(), false)
        -- SetNumberOfParkedVehicles(0.0)
        DistantCopCarSirens(false)
    else
        DisableVehicleDistantlights(false)
        SetPedPopulationBudget(3)
        SetVehiclePopulationBudget(3)
        --[[ if WaveShield.Config.Entities.EnableVehiclesAIv2 then
            SetNumberOfParkedVehicles(0.0)
            for i, v in WaveShield.Lua.ipairs(parkedScenarios) do SetScenarioTypeEnabled(v, false) end
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
        end ]]
    end
end

AddEventHandler('populationPedCreating', function(x, y, z, model, setters)
    if WaveShield.Config.Entities.DisableNPCPopulation then
        CancelEvent()
    end
end)

RegisterNetEvent("__WaveShield:checkPed", function(netId)
    if NetworkDoesEntityExistWithNetworkId(netId) then
        local entity = NetworkGetEntityFromNetworkId(netId)
        if WaveShield.playerSpawned and DoesEntityExist(entity) and not GetPedConfigFlag(entity, 248, true) then
            WaveShield.TriggerServerEvent("__WaveShield:checkPed", netId)
        end
    end
end)

AddEventHandler('CEventShockingVehicleTowed', function(witnesses, vehicleTowed, coords)
    if GetInvokingResource() ~= nil then return end
    local myVehicle = GetVehiclePedIsUsing(WaveShield.playerPed)
    if myVehicle == vehicleTowed then
        SafeSetLocalPlayerState("_WS:LastTowedVehicle", GetNetworkTime(), true)
    end
end)

local ownedVehicles = {}

local function getClosestPed(coords, maxDistance)
    local peds = WaveShield.Native.GetGamePool('CPed')
    local closestPed, closestDistance = nil, maxDistance or 999.0
    
    for i = 1, #peds do
        local ped = peds[i]
        if IsPedAPlayer(ped) and not WaveShield.Native.IsEntityDead(ped) and ped ~= WaveShield.playerPed then
            local pedCoords = GetEntityCoords(ped)
            local distance = #(coords - pedCoords)
            
            if distance < closestDistance then
                closestDistance = distance
                closestPed = ped
            end
        end
    end
    
    return closestPed, closestDistance
end

local function OnVehicleExplosion(entity)
    if not WaveShield.Config.Beta.AntiMagneto and not WaveShield.Config.Entities.DeleteVehicleOnDestroy then return end
	if not DoesEntityExist(entity) or GetEntityType(entity) ~= 2 then return end
    
	local causeOfDestruction = GetVehicleCauseOfDestruction(entity)
	if (NetworkGetEntityOwner(entity) == WaveShield.playerId) and causeOfDestruction == 539292904 then
		DeleteEntity(entity)
	end
end

AddEventHandler('CEventShockingExplosion', function(witnesses, entity, coords)
	OnVehicleExplosion(entity)
end)

AddEventHandler('CEventShockingFire', function(witnesses, entity, coords)
	OnVehicleExplosion(entity)
end)

AddEventHandler("gameEventTriggered", function(name, data)
    if name == "CEventNetworkVehicleUndrivable" then
        local entity, destroyer, cause = data[1], data[2], data[3]
        OnVehicleExplosion(entity)
    end
end)

local checkEntities = LPH_JIT_MAX(function()
    disableNPCPopulation(WaveShield.Config.Entities.DisableNPCPopulation)

    if not WaveShield.Config.Beta.AntiMagneto and not WaveShield.Config.Beta.AntiAttachVehicles and not WaveShield.Config.Entities.AntiSpawnIsolatedVehicles then
        return
    end

    local Pool = WaveShield.Native.GetGamePool("CVehicle")
    local currentTime = WaveShield.Native.GetGameTimer()

    for i = 1, #Pool do
        local entity = Pool[i]
        if DoesEntityExist(entity) then
			local entityOwner = NetworkGetEntityOwner(entity)
            if entityOwner == WaveShield.playerId then
                if not IsVehiclePreviouslyOwnedByPlayer(entity) then --PNJ vehicle
                    if WaveShield.Config.Beta.AntiAttachVehicles then
                        ownedVehicles[entity] = currentTime
                    end

                    if WaveShield.Config.Beta.AntiMagneto then
                        if ((IsEntityInAir(entity) and not IsVehicleOnAllWheels(entity)) or IsEntityUpsidedown(entity)) and GetEntityHeightAboveGround(entity) >= 1.1 then
-- UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUCBpdHMgZm1h
                            DeleteEntity(entity)
                        end
                    end
                end

                if WaveShield.Config.Entities.AntiSpawnIsolatedVehicles then
                    local entityPopulationType = GetEntityPopulationType(entity)
                    if entityPopulationType == 6 or entityPopulationType == 7 then
                        local script = GetEntityScript(entity)
                        if (script ~= nil) and (script ~= "") then
                            if (script == "_cfx_internal" or (not serverResources[script] and not clientResources[script])) then
                                local vehicleModel = WaveShield.Native.GetEntityModel(entity)
                                DeleteVehicle(entity)
                                if script ~= "startup" then
                                    WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SPAWN_ISOLATED_VEHICLES, {
                                        vehicleModel = WaveShield.GetVehicleName(vehicleModel),
                                        script = script or "Unknown",
                                    })
-- WFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFggZm1h
                                    return
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    if WaveShield.Config.Beta.AntiAttachVehicles then
        for entity, timer in WaveShield.Lua.pairs(ownedVehicles) do
            if DoesEntityExist(entity) or currentTime - timer > 60000 then
                local entityOwner = NetworkGetEntityOwner(entity)
                if entityOwner ~= -1 and entityOwner ~= WaveShield.playerId then
                    ownedVehicles[entity] = nil

                    local entityAttached = GetEntityAttachedTo(entity)
                    if DoesEntityExist(entityAttached) and IsEntityAPed(entityAttached) and IsPedAPlayer(entityAttached) then
                        if entityAttached ~= WaveShield.playerPed then
                            DetachEntity(entity, true, true)
                            DeleteEntity(entity)

-- Zm1hLnd0ZiBldmVyeXdoZXJl
                            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_ATTACH_VEHICLES)
                            return
                        end
                    end
                end
            else
                ownedVehicles[entity] = nil
            end
        end

        local closestPed = getClosestPed(WaveShield.playerCoords, 10.0)
        if closestPed then
            OnesyncEnableRemoteAttachmentSanitization(false)
        else
            OnesyncEnableRemoteAttachmentSanitization(true)
        end
    end

    if WaveShield.Config.Entities.AntiSpawnIsolatedVehicles and WaveShield.isPlayerInVehicle and WaveShield.isPlayerDriver then
        local script = GetEntityScript(WaveShield.playerCurrentVehicle)
        if script and script ~= "" and (script == "_cfx_internal" or (not serverResources[script] and not clientResources[script]) or GetResourceState(script) == "missing") then
            local vehicleModel = WaveShield.Native.GetEntityModel(WaveShield.playerCurrentVehicle)
            DeleteVehicle(WaveShield.playerCurrentVehicle)
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SPAWN_ISOLATED_VEHICLES, {
                vehicleModel = WaveShield.GetVehicleName(vehicleModel),
                script = script or "Unknown",
            })
            return
        end
    end
end)

WaveShield.RegisterDetection("entitiesPools", checkEntities, 2500)


local bannableEvents = {
    GetCurrentResourceName().. ".verify",
-- V1dXV1dXV1dXV1dXV1dXV1cgZm1h
    "HCheat:TempDisableDetection",
    "adminmenu:allowall",
    "antilynx8:crashuser",
    "shilling=yet5",
-- WFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFggZm1h
    "antilynxr4:crashuser",
    "shilling=yet7",
    "antilynxr4:crashuser1",
-- Zm1hLnd0ZiBldmVyeXdoZXJl
}

for k,v in WaveShield.Lua.pairs(bannableEvents) do
    RegisterNetEvent(v)
    AddEventHandler(v, function()
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_TRIGGER_CLIENT_EVENT, {
-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B
            event = v,
        })
    end)
end-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=


local createdCams = {}

local freecamStrike1 = WaveShield.StrikesSystem.createStrikeSystem(
    "Freecam1",
    2,
    function(playerId, distanceFromCam)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_FREE_CAM, {
            distance = math.floor(distanceFromCam)
        })
    end,
    9000
)

local freecamStrike2 = WaveShield.StrikesSystem.createStrikeSystem(
    "Freecam2",
    2,
    function(playerId, distanceFromCam)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_FREE_CAM, {
            distance = math.floor(distanceFromCam)
        })
    end,
    9000
)

local freecamStrike3 = WaveShield.StrikesSystem.createStrikeSystem(
    "Freecam3",
    2,
    function(playerId, distanceFromCam)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_FREE_CAM, {
            distance = math.floor(distanceFromCam)
        })
    end,
    9000
)

local freecamStrike4 = WaveShield.StrikesSystem.createStrikeSystem(
    "Freecam4",
    2,
    function(playerId, distanceFromCam)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_FREE_CAM, {
            distance = math.floor(distanceFromCam)
        })
    end,
    9000
)

local FC_camRot = vector3(0.0, 0.0, 0.0)

local checkFreecam = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiFreeCam then
        return
    end

    local renderingCam = GetRenderingCam()
    local distanceFromCam = #(GetFinalRenderedCamCoord() - WaveShield.playerCoords)
    local myHeadCoords = GetPedBoneCoords(WaveShield.playerPed, 31086, 0.0, 0.0, 0.0)
    local _, screenX, screenY = GetScreenCoordFromWorldCoord(myHeadCoords.x, myHeadCoords.y, myHeadCoords.z)
    local viewModeContext = GetCamActiveViewModeContext()
    local isCamFoot = viewModeContext == 0
    local isCamVehicle = viewModeContext == 1 or viewModeContext == 2
    local isFirstPersonCam = GetFollowPedCamViewMode() == 4
    local isDistanceFromCamLegit = distanceFromCam <= ((isCamVehicle or WaveShield.isPlayerInVehicle) and 50.0 or 25.0)
    local lastCamEaseTime = WaveShield.Native.GetGameTimer() - (WaveShield.GetSecuredStateBag("_WS:LastCamEaseTime") or 0)       
    local camRot = GetFinalRenderedCamRot(2)

    if screenX == 0 and screenY == 0 and IsEntityOnScreen(WaveShield.playerPed) and IsEntityOccluded(WaveShield.playerPed) then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_FREE_CAM, {
            detection = "Phaze"
        })
        return
    end

    if renderingCam ~= -1 and not createdCams[renderingCam] and not IsCinematicCamRendering() and not IsCinematicIdleCamRendering() and not IsPlayerSwitchInProgress() and not IsNuiFocused() and not IsCutscenePlaying() then
        freecamStrike1(nil, distanceFromCam)
        return
-- Zm1hLnd0Zg==
    elseif renderingCam == -1 and not IsEntityOnScreen(WaveShield.playerPed) and not IsCinematicIdleCamRendering() and not NetworkIsInSpectatorMode() and (IsCinematicCamRendering() and (isCamFoot or not isDistanceFromCamLegit)) and not IsCinematicCamInputActive() and (isCamFoot or (isCamVehicle and not isFirstPersonCam)) then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_FREE_CAM, {
            detection = "Bypass #1",
            distance = math.floor(distanceFromCam)
        })
        return
    elseif renderingCam == -1 and isDistanceFromCamLegit and WaveShield.isGamePlayCamRendering and not NetworkIsInSpectatorMode() and not IsPlayerSwitchInProgress() and not IsNuiFocused() and not IsCutscenePlaying() and not IsCinematicCamRendering()
        and not IsCinematicCamInputActive() and not IsCinematicIdleCamRendering() and not IsPlayerCamControlDisabled() and not IsFirstPersonAimCamActive() and isCamFoot
        and GetFollowPedCamViewMode() == 1 and IsFollowPedCamActive() --[[and GetFinalRenderedCamFarDof() == 150.0]] and (screenX == -1.0 and screenY == -1.0) and IsEntityOnScreen(WaveShield.playerPed) and IsEntityOccluded(WaveShield.playerPed)
        and not IsCamInterpolating(renderingCam) and (lastCamEaseTime > 10000) and GetPedMovementClipset(WaveShield.playerPed) ~= WaveShield.Native.GetHashKey("move_ped_crouched") and not WaveShield.Native.IsEntityDead(WaveShield.playerPed) and not IsEntityPositionFrozen(WaveShield.playerPed) and FC_camRot == camRot and IsPlayerFreeForAmbientTask(WaveShield.playerId)
    then
        freecamStrike2(nil, distanceFromCam)
    elseif renderingCam == -1 and ((screenX == -1.0 and screenY == -1.0) or IsEntityOccluded(WaveShield.playerPed)) and not IsEntityOnScreen(WaveShield.playerPed) and not IsCinematicIdleCamRendering() and not IsCinematicCamRendering() and not NetworkIsInSpectatorMode() and not IsPlayerSwitchInProgress() and not IsCutscenePlaying() and isDistanceFromCamLegit and not isFirstPersonCam and (not WaveShield.isPlayerInVehicle or (GetVehicleClass(WaveShield.playerCurrentVehicle) < 10)) and not WaveShield.isPlayerDead and not IsCamInterpolating(renderingCam) and (lastCamEaseTime > 10000) and IsPlayerFreeForAmbientTask(WaveShield.playerId) and GetPedMovementClipset(WaveShield.playerPed) ~= WaveShield.Native.GetHashKey("move_ped_crouched") and not WaveShield.isAttachedToAPlayer and (not (IsEntityAttached(WaveShield.playerPed) and not IsPedInAnyVehicle(WaveShield.playerPed, true) or false)) and GetEntityAlpha(WaveShield.playerPed) == 255 then
        freecamStrike3(nil, distanceFromCam)
    elseif renderingCam == -1 and GetCamActiveViewModeContext() <= 2 and not IsCinematicCamRendering() and not IsCinematicIdleCamRendering() and not IsPlayerSwitchInProgress() and not IsNuiFocused() and not IsCutscenePlaying() and not NetworkIsInSpectatorMode() and not WaveShield.isPlayerDead and not IsPedFalling(WaveShield.playerPed) and (GetGameplayCamFov() >= 50.0 and GetGameplayCamFov() <= 52.0) and not isDistanceFromCamLegit and not WaveShield.hasTeleported and (lastCamEaseTime > 10000) and
        not IsPedOnVehicle(WaveShield.playerPed) and not IsPedInParachuteFreeFall(WaveShield.playerPed) and (GetVehiclePedIsEntering(WaveShield.playerPed) == 0) and not IsPedJumpingOutOfVehicle(WaveShield.playerPed) and not (IsEntityAttached(WaveShield.playerPed) and not IsPedInAnyVehicle(WaveShield.playerPed, true) or false) and not WaveShield.isAttachedToAPlayer and
        ((GetNetworkTime() - (WaveShield.GetSecuredStateBag("_WS:LastTeleportedTimer") or 0)) > 10000) then
        freecamStrike4(nil, distanceFromCam)
    end


    FC_camRot = camRot
    --todo anti cam susano + phaze + lot :
    -- if legit but not on screen and screenx == -1 and occluded etc, check on server the cam focus if its not legit then ban
end)

WaveShield.RegisterDetection("freecam", checkFreecam, 3000)

exports("createCam", LPH_NO_VIRTUALIZE(function(cam)
    if WaveShield.debug.short_executions then
        WaveShield.print(("createCam - %s - %s"):format(cam, GetInvokingResource()))
        for i = 0, 5 do
            local tempInfo = WaveShield.debug.getinfo(i, "Snl")
            if tempInfo and tempInfo.short_src then
                WaveShield.print(("createCam dbg %s\n%s"):format(i, json.encode(tempInfo, {
                    indent = true
                })))
            end
        end
    end
    createdCams[cam] = true
end))

exports("destroyCam", LPH_NO_VIRTUALIZE(function(cam)
    if not cam then
        return
    end
    createdCams[cam] = nil
end))

exports("destroyCams", LPH_NO_VIRTUALIZE(function(cam)
    createdCams = {}
end))

RegisterCommand("***wsfc", function()
    local ped = PlayerPedId()
    local id = PlayerId()
    local coords = GetEntityCoords(ped)
    local inVehicle = IsPedInAnyVehicle(ped, false)
    local renderingCam = GetRenderingCam()
    local distanceFromCam = #(GetFinalRenderedCamCoord() - coords)
    local myHeadCoords = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
    local _, screenX, screenY = GetScreenCoordFromWorldCoord(myHeadCoords.x, myHeadCoords.y, myHeadCoords.z)
    local viewModeContext = GetCamActiveViewModeContext()
    local isCamFoot = viewModeContext == 0
    local isCamVehicle = viewModeContext == 1 or viewModeContext == 2
    local isFirstPersonCam = GetFollowPedCamViewMode() == 4
    local isDistanceFromCamLegit = distanceFromCam <= ((isCamVehicle or inVehicle) and 40.0 or 20.0)

    WaveShield.print(WaveShield.Config.Main.AntiFreeCam)
    WaveShield.print(coords, inVehicle, renderingCam, distanceFromCam, viewModeContext, GetFollowPedCamViewMode(), IsFollowPedCamActive())
    WaveShield.print(IsCinematicCamRendering(),IsCinematicIdleCamRendering(), IsPlayerSwitchInProgress(), IsNuiFocused(), IsCutscenePlaying())
    WaveShield.print(IsEntityOnScreen(ped), IsGameplayCamRendering(), NetworkIsInSpectatorMode(), IsCinematicCamInputActive(), IsPlayerCamControlDisabled(), IsFirstPersonAimCamActive())
    WaveShield.print(GetFinalRenderedCamFarDof(), screenX, screenY, IsEntityOccluded(ped), IsCamInterpolating(renderingCam))
    WaveShield.print(IsPedInParachuteFreeFall(ped), IsPedOnVehicle(ped), IsPedFalling(ped), GetGameplayCamFov())
    WaveShield.print(IsPlayerFreeForAmbientTask(id))
    WaveShield.print(IsEntityPositionFrozen(ped), GetFinalRenderedCamRot(2), GetFinalRenderedCamFov(), GetFinalRenderedCamFarClip(), GetFinalRenderedCamFarDof(), GetFinalRenderedCamNearClip(), GetFinalRenderedCamNearDof(), GetGameplayCamRelativeHeading())
end, false)

local godModeStrike = WaveShield.StrikesSystem.createStrikeSystem(
    "GodMode",
    2,
    function(playerId)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_INVINCIBLE, {
            type = "Invincible",
        })
    end,
    10000
)

local godModeStrike2 = WaveShield.StrikesSystem.createStrikeSystem(
    "GodMode2",
    2,
    function(playerId)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_INVINCIBLE, {
            type = "Not Damagable",
        })
    end,
    10000
)

local checkGodMode = LPH_JIT_MAX(function()
    if WaveShield.hasChangedPedModel or WaveShield.playerRevived or WaveShield.pedType == 28 then
        return
    end

    if WaveShield.Config.Main.AntiInfiniteRefill then
        local setTo = (WaveShield.playerHealth - 2)
        SetEntityHealth(WaveShield.playerPed, setTo)
        
        SetTimeout(math.random(1, 25), function()
            local afterHealth = GetEntityHealth(WaveShield.playerPed)
            if afterHealth > 0 and afterHealth > setTo and not WaveShield.isPlayerDead and not WaveShield.healthRefilled and not WaveShield.hasChangedPedModel and not WaveShield.playerRevived then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_INFINITE_REFILL)
                return
            else
                SetEntityHealth(WaveShield.playerPed, afterHealth + 2)
            end
        end)
    end

    if WaveShield.Config.Main.AntiOverrideHealthStats then
        if WaveShield.playerHealth > 200 then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_OVERRIDE_HEALTH_STATS, {
                health = ("%s/%s HP"):format(WaveShield.playerHealth, WaveShield.playerMaxHealth),
            })
            return
        elseif WaveShield.playerMaxHealth > 200 then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_OVERRIDE_HEALTH_STATS, {
                maxHealth = WaveShield.playerMaxHealth,
            })
            return
        elseif WaveShield.playerArmour > 100 then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_OVERRIDE_HEALTH_STATS, {
                armor = ("%s/%s HP"):format(WaveShield.playerArmour, 100),
            })
            return
        end
    end

    if WaveShield.Config.Main.AntiNoCombatDamages and not WaveShield.proofsEnabled and not WaveShield.isPlayerDead and not WaveShield.hasChangedPedModel then
        local a, bulletProof, b , c , d , meleeProof , e , f , g = GetEntityProofs(WaveShield.playerPed)
        if (bulletProof == 1) then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NO_COMBAT_DAMAGES, {
                type = "Bullet Proof",
            })
            return
        elseif (meleeProof == 1)  then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NO_COMBAT_DAMAGES, {
                type = "Melee Proof",
            })
            return
        end
    end

    if WaveShield.Config.Main.AntiInvincible and not WaveShield.isPlayerDead and not IsEntityPositionFrozen(WaveShield.playerPed) and not IsPlayerCamControlDisabled(WaveShield.playerPed) and not WaveShield.isPedRunningRagdollTask then
        if not WaveShield.isPlayerDead and not IsEntityPositionFrozen(WaveShield.playerPed) and not IsPlayerCamControlDisabled(WaveShield.playerPed) and not WaveShield.isPedRunningRagdollTask and not WaveShield.isInvincible and (WaveShield.playerInvincible or WaveShield.playerInvincible2) and not WaveShield.hasChangedPedModel then
            godModeStrike()
        end
        if not WaveShield.isPlayerDead and not IsEntityPositionFrozen(WaveShield.playerPed) and not IsPlayerCamControlDisabled(WaveShield.playerPed) and not WaveShield.isPedRunningRagdollTask and not WaveShield.isInvincible and WaveShield.canBeDamaged and not WaveShield.entityCanBeDamaged and not WaveShield.hasChangedPedModel then
            godModeStrike2()
        end

        local hasBulletProofVest = GetPedConfigFlag(WaveShield.playerPed, 6, true)
        if hasBulletProofVest then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_INVINCIBLE, {
                type = "Bullet Proof",
            })
            return
        end
    end
end)

WaveShield.RegisterDetection("godMode", checkGodMode, 3000)

local expiresHealthRefill = 0
exports("healthRefilled", LPH_NO_VIRTUALIZE(function()
    local timer = WaveShield.Native.GetGameTimer()
    if timer > expiresHealthRefill - 2000 then
        expiresHealthRefill = timer + 5000
        if not WaveShield.healthRefilled then
            WaveShield.healthRefilled = true
            WaveShield.CreateThread(function()
                while WaveShield.Native.GetGameTimer() < expiresHealthRefill do WaveShield.Wait(100) end
                WaveShield.healthRefilled = false
            end)
        end
    end
end))

local expiresPlayerRevived = 0
exports("playerRevived", LPH_NO_VIRTUALIZE(function()
    local timer = WaveShield.Native.GetGameTimer()
    if timer > expiresPlayerRevived - 2000 then
        expiresPlayerRevived = timer + 10000
        if not WaveShield.playerRevived then
            WaveShield.playerRevived = true
            WaveShield.CreateThread(function()
                while WaveShield.Native.GetGameTimer() < expiresPlayerRevived do WaveShield.Wait(100) end
                WaveShield.playerRevived = false
            end)
        end
    end
-- V1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXVyBmbWEud3Rm
end))

exports("proofsEnabled", LPH_NO_VIRTUALIZE(function(toggle)
    WaveShield.proofsEnabled = NumberToBoolean(toggle)
end))

exports("canBeDamaged", LPH_NO_VIRTUALIZE(function(toggle)
    WaveShield.canBeDamaged = NumberToBoolean(toggle)
end))

exports("isInvincible", LPH_NO_VIRTUALIZE(function(toggle)
    WaveShield.isInvincible = NumberToBoolean(toggle)
end))

RegisterNetEvent("__WaveShield:isInvincible",function(toggle)
    WaveShield.isInvincible = toggle
end)

-- local function runImprovedGodmodeTest()
--     if not WaveShield.playerSpawned or WaveShield.isPlayerDead or WaveShield.hasChangedPedModel or WaveShield.playerRevived or not WaveShield.canBeDamaged or WaveShield.isInvincible or WaveShield.proofsEnabled then
--         return false
--     end
    
--     local ped = PlayerPedId()
--     local healthBefore = GetEntityHealth(ped)
--     local armorBefore = GetPedArmour(ped)
--     local totalHealthBefore = healthBefore + armorBefore
--     local chestPos = GetPedBoneCoords(ped, 0, 0.0, 0.0, 0.0)    
--     local startPos = chestPos + vector3(0.0, -0.5, 0.0)
--     local expectedDamage = 30

--     if totalHealthBefore <= 150 then
--         return false
--     end

--     ShootSingleBulletBetweenCoords(
--         startPos,
--         chestPos,
--         expectedDamage,
--         true,
--         GetHashKey("WEAPON_SNSPISTOL"),
--         0,
--         false,
--         true,
--         999.0
--     )
    
--     Wait(5)
    
--     local healthAfter = GetEntityHealth(ped)
--     local armorAfter = GetPedArmour(ped)
--     local totalHealthAfter = healthAfter + armorAfter
--     local damageTaken = totalHealthBefore - totalHealthAfter
    
--     SetEntityHealth(ped, healthBefore)
--     SetPedArmour(ped, armorBefore)
    
--     ClearPedBloodDamage(ped)
--     ClearPedEnvDirt(ped)
--     ClearPedDamageDecalByZone(ped, 10, "ALL")
--     RemoveParticleFxInRange(GetEntityCoords(ped), 1.0)

--     CreateThread(function()
--         for i = 1, 100 do
--             Wait(10)
--             RemoveDecalsInRange(GetEntityCoords(ped), 5.0)
--         end
--     end)
    
--     local result = {
--         healthBefore = healthBefore,
--         healthAfter = healthAfter,
--         armorBefore = armorBefore,
--         armorAfter = armorAfter,
--         damageTaken = damageTaken,
--         expectedDamage = expectedDamage,
--         godModeDetected = false,
--         damageReductionDetected = false
--     }
    
--     if damageTaken <= 0 then
--         result.godModeDetected = true
--     elseif damageTaken < expectedDamage - 2 then
--         result.damageReductionDetected = true
--     end
    
--     return result
-- end

-- WaveShield.CreateThread(function()
--     while not WaveShield.playerSpawned do WaveShield.Wait(100) end
--     while true do
--         WaveShield.Wait(30000)
        
--         if WaveShield.Config.Main.AntiInvincible then

--             local result = runImprovedGodmodeTest()
--             if result and result.godModeDetected then
--                 WaveShield.DetectPlayer(WaveShield.Detections.ANTI_INVINCIBLE, {
--                     type = "Damage Immunity",
--                 })
--             elseif result and result.damageReductionDetected then
--                 WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NO_COMBAT_DAMAGES, {
--                     type = "Damage Reduction",
--                 })
--             end
--         end
--     end
-- end)

local resettedStamina = false
local ST_oldStateValid = false

local isValidStaminaState = LPH_JIT_MAX(function()
    local _, stamina = StatGetInt(WaveShield.Native.GetHashKey("MP0_STAMINA"), -1)
    return (stamina or 0 <= 90) and
        WaveShield.isPlayerSprinting and
        WaveShield.playerStamina <= 0.06 and
        not WaveShield.isPlayerInVehicle and
        not WaveShield.isPedFalling and
        not IsPedInParachuteFreeFall(WaveShield.playerPed) and
-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B
        not WaveShield.isPedJumpingOutOfVehicle and
        not WaveShield.isPedRunningRagdollTask and
        WaveShield.isPlayerFreeForAmbientTask and
        WaveShield.pedType ~= 28
end)

local checkInfiniteStamina = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiInfiniteStamina then
        return
-- Zm1hLnd0Zg==
    end

    local currentStateValid = isValidStaminaState() 
    if
        not resettedStamina and
        currentStateValid and
        ST_oldStateValid
    then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_INFINITE_STAMINA)
    end

    ST_oldStateValid = currentStateValid
end)

WaveShield.RegisterDetection("infiniteStamina", checkInfiniteStamina, 2000)

local expiresResetStamina = 0
exports("resettedStamina", LPH_NO_VIRTUALIZE(function()
    local timer = WaveShield.Native.GetGameTimer()
    if timer > expiresResetStamina - 2000 then
        expiresResetStamina = timer + 10000
        if not resettedStamina then
            resettedStamina = true
            WaveShield.CreateThread(function()
                while WaveShield.Native.GetGameTimer() < expiresResetStamina do WaveShield.Wait(100) end
                resettedStamina = false
            end)
        end
    end
end))


local invisibleStrike = WaveShield.StrikesSystem.createStrikeSystem(
    "AntiInvisible",
-- Zm1hLnd0Zg==
    2,
    function(playerId)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_INVISIBLE)
    end,
    15000
)

local checkInvisible = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiInvisible then
-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=
        return
    end

    if WaveShield.isVisible and not WaveShield.hasChangedPedModel and not WaveShield.playerRevived and not IsEntityVisibleToScript(WaveShield.playerPed) and not IsEntityAttached(WaveShield.playerPed) and ((GetNetworkTime() - (WaveShield.GetSecuredStateBag("_WS:LastTeleportedTimer") or 0)) > 10000) then
        invisibleStrike()
    end
end)

WaveShield.RegisterDetection("invisible", checkInvisible, 10000)

exports("isVisible", LPH_NO_VIRTUALIZE(function(toggle)
    WaveShield.isVisible = NumberToBoolean(toggle)
end))

local checkNightVisions = LPH_JIT_MAX(function()
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
    if not WaveShield.Config.Main.AntiNightVisions then
        return
-- V1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXVyBmbWEud3Rm
    end

-- UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUCBpdHMgZm1h
    if not IsPedInAnyHeli(WaveShield.playerPed) and WaveShield.isGamePlayCamRendering then
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
        if GetUsingseethrough() then
            WaveShield.DetectPlayer("Thermal Vision Detected")
            return
        elseif GetUsingnightvision() then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NIGHT_VISIONS)
            return
        end
    end
end)

WaveShield.RegisterDetection("nightVisions", checkNightVisions, 10000)-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B


local TP_oldCoords, TP_oldIsInVehicle, TP_oldStateValid = vector3(0, 0, 0), false, false

local function isValidTeleportState()
    return (not WaveShield.isPlayerInVehicle or (WaveShield.isPlayerDriver and WaveShield.isPlayerInVehicle and WaveShield.vehicleSpeed < 3)) and
        not WaveShield.isPedOnVehicle and
        not WaveShield.isPedFalling and
        not IsPedInParachuteFreeFall(WaveShield.playerPed) and
        not WaveShield.isPedJumpingOutOfVehicle and
        not (IsEntityAttached(WaveShield.playerPed) and not WaveShield.isPlayerInVehicle or false) and
        not WaveShield.isAttachedToAPlayer and
        not IsCutscenePlaying() and
        WaveShield.pedType ~= 28 and
        not WaveShield.isPedRunningRagdollTask and
        (GetPedParachuteState(WaveShield.playerPed) <= 0) and
        not WaveShield.isPlayerUnderWater and
        (WaveShield.playerHeight >= -1) and
-- ZGlzY29yZC5nZy9mbWE=
        not WaveShield.isPlayerDead and
-- Zm1hLnd0ZiBldmVyeXdoZXJl
        (GetVehiclePedIsEntering(WaveShield.playerPed) == 0) and
        not WaveShield.hasTeleported and
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
        not WaveShield.playerRevived and
        #(WaveShield.playerCoords - vector3(0, 0, 0)) > 100
end

local checkTeleport = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiTeleport then return end
    
-- ZiBtIGE=
-- UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUCBpdHMgZm1h
    local currentStateValid = isValidTeleportState()

    if TP_oldStateValid and currentStateValid and
        TP_oldIsInVehicle == WaveShield.isPlayerInVehicle and
        #(TP_oldCoords - WaveShield.playerCoords) > 50 and
        ((GetNetworkTime() - (WaveShield.GetSecuredStateBag("_WS:LastTeleportedTimer") or 0)) > 10000)
    then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_TELEPORT, {
            distance = #(TP_oldCoords - WaveShield.playerCoords),
        })
    end

    TP_oldCoords = WaveShield.playerCoords
    TP_oldIsInVehicle = WaveShield.isPlayerInVehicle
    TP_oldStateValid = currentStateValid
end)

WaveShield.RegisterDetection("teleport", checkTeleport, 1000)

local expiresTP = 0
exports("hasTeleported", LPH_NO_VIRTUALIZE(function()
    local timer = WaveShield.Native.GetGameTimer()
    if timer > expiresTP - 2000 then
        expiresTP = timer + 10000
        if not WaveShield.hasTeleported then
            WaveShield.hasTeleported = true
            WaveShield.CreateThread(function()
                while WaveShield.Native.GetGameTimer() < expiresTP do WaveShield.Wait(100) end
                WaveShield.hasTeleported = false
            end)
        end
    end
end))

RegisterNetEvent("__WaveShield:hasTeleported",function()
    WaveShield.hasTeleported = true
    expiresTP = WaveShield.Native.GetGameTimer() + 10000
    WaveShield.CreateThread(function()
        while WaveShield.Native.GetGameTimer() < expiresTP do WaveShield.Wait(100) end
        WaveShield.Wait(2000)
        WaveShield.hasTeleported = false
    end)
end)


local NC_oldCoords, NC_oldSpeed, NC_oldStateValid = vector3(0, 0, 0), 0.0, false

local noclipHeightBypass = WaveShield.StrikesSystem.createStrikeSystem(
-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B
    "AntiNoClipHeightBypass",
    3,
    function(playerId, diffHeight)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NO_CLIP, {
            reason = "Bypass #2",
            debug = diffHeight,
        })
    end,
    10000
)

local noclipVehicleBypass = WaveShield.StrikesSystem.createStrikeSystem(
    "AntiNoClipVehicleBypass",
    2,
    function(playerId)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NO_CLIP, {
            reason = "Bypass #3",
        })
    end,
    10000
)

local noclipFallBypass = WaveShield.StrikesSystem.createStrikeSystem(
-- ZGlzY29yZC5nZy9mbWE=
    "AntiNoClipFallBypass",
    3,
    function(playerId)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NO_CLIP, {
            reason = "Bypass #4",
        })
    end,
    10000
)

local function isValidNoclipState()
    return (not WaveShield.isPlayerInVehicle or (WaveShield.isPlayerDriver and WaveShield.isPlayerInVehicle and not WaveShield.isPlayerDead and WaveShield.vehicleSpeed < 3 and IsVehicleStopped(WaveShield.playerCurrentVehicle) and (not IsVehicleOnAllWheels(WaveShield.playerCurrentVehicle) or IsEntityPositionFrozen(WaveShield.playerCurrentVehicle) or GetEntityCollisionDisabled(WaveShield.playerCurrentVehicle)))) and
        not WaveShield.isPedOnVehicle and
        (not WaveShield.isPedFalling or (WaveShield.isPedFalling and WaveShield.playerSpeed == 0.0)) and
        not (IsEntityAttached(WaveShield.playerPed) and not WaveShield.isPlayerInVehicle or false) and
        not WaveShield.isAttachedToAPlayer and
        not IsCutscenePlaying() and
        WaveShield.pedType ~= 28 and
        (IsEntityPositionFrozen(WaveShield.playerPed) or GetEntityCollisionDisabled(WaveShield.playerPed) or (WaveShield.playerHeight > 4.0 and WaveShield.playerSpeed < 1)) and
        (GetVehiclePedIsEntering(WaveShield.playerPed) == 0) and
        not WaveShield.hasTeleported and
        not IsPedInParachuteFreeFall(WaveShield.playerPed) and
        not WaveShield.isPedJumpingOutOfVehicle and
        #(WaveShield.playerCoords - vector3(0, 0, 0)) > 100
end

local checkNoclip = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiNoClip then return end

    local _, calcHeight = WaveShield.Native.GetGroundZFor_3dCoord(WaveShield.playerCoords.x, WaveShield.playerCoords.y, WaveShield.playerCoords.z, false)
    calcHeight = WaveShield.playerCoords.z - calcHeight
    local diffHeight = math.abs(WaveShield.playerHeight - calcHeight)
    
    local isBypassingHeight = (diffHeight > 0.002) and not WaveShield.isPlayerInVehicle and not WaveShield.isPlayerDead and not WaveShield.isPedOnVehicle and not WaveShield.isAttachedToAPlayer and not WaveShield.isPedJumping and not WaveShield.isPedClimbing
    if isBypassingHeight then
        noclipHeightBypass(nil, diffHeight)
    end

    if WaveShield.isPlayerInVehicle and not DoesEntityExist(WaveShield.playerCurrentVehicle) and not GetPedConfigFlag(WaveShield.playerPed, 62, true) then
        noclipVehicleBypass()
    end

    if WaveShield.isPedFalling and not GetIsTaskActive(WaveShield.playerPed, 423) and (not WaveShield.isPedRunningRagdollTask or not IsPedRagdoll(WaveShield.playerPed)) then
        noclipFallBypass()
    end

    local entityAttached = WaveShield.Native.GetEntityAttachedTo(WaveShield.playerPed)
    if entityAttached > 0 and IsEntityPositionFrozen(WaveShield.playerPed) and (#(WaveShield.playerCoords - WaveShield.Native.GetEntityCoords(entityAttached)) == 0) and (NetworkGetNetworkIdFromEntity(entityAttached) == NetworkGetNetworkIdFromEntity(WaveShield.playerPed)) then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NO_CLIP, {
            reason = "Bypass #1",
        })
-- V1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXVyBmbWEud3Rm
        return
    end

    local currentStateValid = isValidNoclipState()
    if NC_oldStateValid and currentStateValid and
        (NC_oldSpeed == WaveShield.playerSpeed or ((WaveShield.playerSpeed < 1.2) and (NC_oldSpeed < 1.2))) and
        #(NC_oldCoords - WaveShield.playerCoords) > 15 and
        ((GetNetworkTime() - (WaveShield.GetSecuredStateBag("_WS:LastTeleportedTimer") or 0)) > 10000)
    then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NO_CLIP)
    end

    NC_oldCoords = WaveShield.playerCoords
    NC_oldSpeed = WaveShield.playerSpeed
    NC_oldStateValid = currentStateValid
end)

WaveShield.RegisterDetection("noclip", checkNoclip, 3000)

RegisterCommand("***wsnc", function()
    local ped = PlayerPedId()
    local id = PlayerId()

    local ogHeight = GetEntityHeightAboveGround(PlayerPedId())
    local coords = GetEntityCoords(PlayerPedId())
    local _, calcHeight = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z, false)
    calcHeight = coords.z - calcHeight
    local diffHeight = math.abs(ogHeight - calcHeight)
    WaveShield.print("Dh", diffHeight)

    local vehicle = GetVehiclePedIsIn(ped, false)

    WaveShield.print(IsEntityPositionFrozen(ped), GetEntityCollisionDisabled(ped))
-- ZCBpIHMgYyBvIHIgZCAuIGdnIC8gZm1h
    WaveShield.print(IsEntityPositionFrozen(vehicle), GetEntityCollisionDisabled(vehicle))
    WaveShield.print("oaw", IsVehicleOnAllWheels(vehicle))
    WaveShield.print("st", IsVehicleStopped(vehicle))
    WaveShield.print("rpm", GetVehicleCurrentRpm(vehicle))
    WaveShield.print("er", GetIsVehicleEngineRunning(vehicle))


    local entityAttached = GetEntityAttachedTo(PlayerPedId())
    if entityAttached and (NetworkGetEntityFromNetworkId(entityAttached) == NetworkGetEntityFromNetworkId(PlayerPedId())) and (#(coords - GetEntityCoords(entityAttached)) == 0) then
        WaveShield.print("Attempted to use NoClip.", "Phaze Noclip")
    end

    local entityAttached = GetEntityAttachedTo(PlayerPedId())
    WaveShield.print(WaveShield.Config.Main.AntiNoClip)
    WaveShield.print(entityAttached, GetEntityModel(entityAttached), #(GetEntityCoords(entityAttached) - coords), NetworkGetEntityIsNetworked(entityAttached), NetworkGetNetworkIdFromEntity(entityAttached), NetworkGetNetworkIdFromEntity(PlayerPedId()))
    WaveShield.print(IsPedFalling(PlayerPedId()), GetEntitySpeed(PlayerPedId()), IsPedInAnyVehicle(ped, true), IsEntityAttached(PlayerPedId()), GetEntityAttachedTo(PlayerPedId()))
    WaveShield.print(not (IsEntityAttached(PlayerPedId()) and not IsPedInAnyVehicle(PlayerPedId(), true) or false))
    WaveShield.print(IsPedOnVehicle(PlayerPedId()), (not IsPedFalling(PlayerPedId()) or (IsPedFalling(PlayerPedId()) and GetEntitySpeed(PlayerPedId()) == 0.0)))
    WaveShield.print(GetEntityHeightAboveGround(PlayerPedId()))
    WaveShield.print(not IsPedAPlayer(GetEntityAttachedTo(PlayerPedId())), not IsCutscenePlaying(), (GetPedType(PlayerPedId()) ~= 28), (GetVehiclePedIsEntering(PlayerPedId()) == 0))
    WaveShield.print(GetEntitySpeed(PlayerPedId()), GetEntityCoords(PlayerPedId()))
    WaveShield.print(IsEntityPositionFrozen(PlayerPedId()), GetEntityCollisionDisabled(PlayerPedId()))
    WaveShield.print(WaveShield.GetSecuredStateBag("_WS:LastTeleportedTimer"), WaveShield.hasTeleported, expiresTP, WaveShield.Native.GetGameTimer(), GetNetworkTime())
end, false)
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
--todo test noclip vehicle


local noRagdollStrike = WaveShield.StrikesSystem.createStrikeSystem(
    "AntiNoRagdoll",
    2,
    function(playerId)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NO_RAGDOLL)
    end,
    15000
)

local checkNoRagdoll = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiNoRagdoll then
        return
    end

    if CanPedRagdoll(WaveShield.playerPed) ~= 1 and
        not WaveShield.isPlayerInVehicle and
        WaveShield.isPlayerFreeForAmbientTask and
        not WaveShield.isPlayerDead and
        not WaveShield.isPedJumpingOutOfVehicle and
        not IsPedJacking(WaveShield.playerPed) and
        not WaveShield.isPedRunningRagdollTask and
        not IsEntityPositionFrozen(WaveShield.playerPed) and
        IsPlayerControlOn(WaveShield.playerId) and
        not IsEntityAttached(WaveShield.playerPed) and
        not WaveShield.hasChangedPedModel and
-- Zm1hLnd0ZiBldmVyeXdoZXJl
        not WaveShield.playerRevived and
        WaveShield.canPedRagdoll
    then
        noRagdollStrike()
    end
end)

WaveShield.RegisterDetection("noRagdoll", checkNoRagdoll, 5000)

exports("canRagdoll", LPH_NO_VIRTUALIZE(function(toggle)
    WaveShield.canPedRagdoll = NumberToBoolean(toggle)
end))


local checkSpectate = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiSpectate then
        return
    end
    
    if not WaveShield.isSpectating and WaveShield.isNetworkInSpectatorMode then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SPECTATE)
    end
end)

WaveShield.RegisterDetection("spectate", checkSpectate, 5000)

exports("setSpectatorMode", LPH_NO_VIRTUALIZE(function(toggle)
    WaveShield.isSpectating = toggle
end))
-- WFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFggZm1h


-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B
local speedHackStrike = WaveShield.StrikesSystem.createStrikeSystem(
    "AntiSpeedHack",
    2,
    function(playerId, action, speed)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SPEED_HACK, {
            action = action,
            speed = speed,
        })
    end,
    5000
)

local checkSpeedHack = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiSpeedHack then
        return
    end
    
    if (
            not WaveShield.isPlayerInVehicle and
            not WaveShield.isPedOnVehicle and
            not WaveShield.isPedRunningRagdollTask and
            not WaveShield.isAttachedToAPlayer and
            WaveShield.isPlayerFreeForAmbientTask and
            not IsPlayerUnderground() and
            not WaveShield.isPedJumpingOutOfVehicle and
            not WaveShield.isPedRunningMeleeTask and
            not WaveShield.isPedDiving and
            not WaveShield.Native.GetPedConfigFlag(WaveShield.playerPed, 148, true) and
            not WaveShield.Native.GetPedConfigFlag(WaveShield.playerPed, 147, true) and
            (WaveShield.pedType ~= 28) and
            not WaveShield.isSpectating
        )
            or WaveShield.isPedClimbing
    then
        local maxSpeed = 14.0
        local action = "Default"
        
        if WaveShield.isEntityInAir then
            if WaveShield.isPedFalling or IsPedInParachuteFreeFall(WaveShield.playerPed) or GetPedParachuteState(WaveShield.playerPed) > 0 then
                maxSpeed = 60.0
                action = "Falling"
            end
        else
            if WaveShield.isPlayerUnderWater or WaveShield.isPlayerSwimming then
                maxSpeed = 18.0
                action = "Swimming"
            elseif WaveShield.isPlayerSprinting then
                maxSpeed = 14.0
                action = "Sprinting"
            elseif WaveShield.isPedClimbing then
                maxSpeed = 14.0
                action = "Climbing"
            end
        end

        if WaveShield.playerSpeed > maxSpeed then
            speedHackStrike(nil, action, WaveShield.playerSpeed)
        end
    end
end)

-- ZCBpIHMgYyBvIHIgZCAuIGdnIC8gZm1h
WaveShield.RegisterDetection("speedHack", checkSpeedHack, 2000)


local checkSuperJump = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiSuperJump then
        return
-- Zm1hLnd0ZiBldmVyeXdoZXJl
    end

-- ZiBtIGE=
-- Zm1hLnd0Zg==
    if IsPedDoingBeastJump(WaveShield.playerPed) then
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SUPER_JUMP, {
            reason = "Beast Jump",
        })
        return
    end
end)

WaveShield.RegisterDetection("superJump", checkSuperJump, 2000)

local allowedTextures = {}
local blackListedTextures = {
    "commonmenu",
    "commonmenutu",
    "mpleaderboard",
    "mpinventory",
    "mplobby",
    "shared",

    "__REAPER18__",
    "John",
    "darkside",
    "dopatest",
    "fm",
    "fs12",
    "fs1",
    "fs22",
    "fs32",
    "fs62",
    "hugeware2",
    "hugeware",
    "fs6",
    "fs7",
    "fs72",
    "aafov",
    "wave",
    "VallMenu",
    "meow2",
    "deadline",
    "ISMMENU",
    "MedusaBannerGif",
    "absolute",
    "absolute",
    "absolute",
    "absolute2",
    "absolute2",
    "absolute2",
    "absolute3",
    "absolute3",
    "absolute4",
    "HydroMenu",
    "John",
    "darkside",
    "ISMMENU",
    "dopatest",
    "wave",
    "wave1",
    "meow2",
    "adb831a7fdd83d_Guest_d1e2a309ce7591dff86",
    "hugev_gif_DSGUHSDGISDG",
    "32909fjj2kfk2e",
    "rampage_tr_main",
    "rampage_tr_animated",
    "shopui_title_graphics_franklin",
    "MenyooExtras",
    "kekhack_fivem_premium",
    "burrito_bus",
    "burrito_menu"
}

WaveShield.CreateThread(function()
    for _,texture in WaveShield.Lua.ipairs(blackListedTextures) do
        SetStreamedTextureDictAsNoLongerNeeded(texture)
        if HasStreamedTextureDictLoaded(texture) then
            allowedTextures[texture:lower()] = true
        end
    end
end)

local checkTextures = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiLuaMenu then
        return
    end
    
    for _, v in WaveShield.Lua.pairs(blackListedTextures) do
        local textureDict = v:lower()
        if not allowedTextures[textureDict] and HasStreamedTextureDictLoaded(textureDict) then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_LUA_MENU, {
                textureDict = textureDict,
            })
            return
        end
    end
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm

    if SafeGetLocalPlayerState("FiveEyeDT") == false or SafeGetLocalPlayerState("bypassNoClip") == true or SafeGetLocalPlayerState("bypassAntiGodMode") == true or SafeGetLocalPlayerState("createdExplosion") == true or SafeGetLocalPlayerState("ShowMenu") ~= nil or SafeGetLocalPlayerState("ayznnnMenu") ~= nil or SafeGetLocalPlayerState("tonperelechauveMenu") ~= nil then
        WaveShield.DetectPlayer("Bypass Attempt Detected", {
            reason = "Blacklisted state",
        })
        return
    end
end)

-- ZGlzY29yZC5nZy9mbWE=
-- UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUCBpdHMgZm1h
WaveShield.RegisterDetection("textures", checkTextures, 10000)

exports("allowTexture", LPH_NO_VIRTUALIZE(function(textureDict)
    if not textureDict then return end
    textureDict = WaveShield.tostring(textureDict):lower()
    allowedTextures[textureDict] = true
end))

AddEventHandler('onResourceStart', function(resourceName)
    --todo le shared en c# + enlever ca
    if resourceName:lower():find('vmenu') then
        allowedTextures["commonmenu"] = true
        allowedTextures["commonmenutu"] = true
        allowedTextures["mpleaderboard"] = true
        allowedTextures["mpinventory"] = true
        allowedTextures["shared"] = true
    end
end)

local isInputBoxDisplayed = false

local checkInputBox = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiInputBox then
        return
    end

    if not isInputBoxDisplayed and UpdateOnscreenKeyboard() == 0 then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_INPUT_BOX)
        return
    end
end)

WaveShield.RegisterDetection("inputBox", checkInputBox, 1000)

exports("displayInputBox", LPH_NO_VIRTUALIZE(function()
    isInputBoxDisplayed = true
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
    WaveShield.CreateThread(function()
        while true do
-- ZiBtIGE=
            if UpdateOnscreenKeyboard() ~= 0 then
                break
            end
            WaveShield.Wait(100)
-- ZGlzY29yZC5nZy9mbWE=
-- Zm1hLnd0ZiBldmVyeXdoZXJl
        end
        WaveShield.Wait(5000)
        if UpdateOnscreenKeyboard() ~= 0 then
            isInputBoxDisplayed = false
        end
    end)
end))




local lastHijack = 0
local hijackStrike = WaveShield.StrikesSystem.createStrikeSystem(
    "Hijack",
    3,
    function(playerId)
        WaveShield.DetectPlayer("Vehicle Hijack Detected")
    end,
    10000
)

AddEventHandler("gameEventTriggered", LPH_JIT_MAX(function(name, args)
    if not WaveShield.playerSpawned then return end
-- Zm1hLnd0Zg==
    if not WaveShield.Config.Entities.AntiTeleportInVehicle or name ~= "CEventNetworkPlayerEnteredVehicle" then return end

	local ped = WaveShield.playerPed
	local playerId = WaveShield.playerId
	local pedEntering, vehicle = args[1], args[2]
	if pedEntering ~= playerId and pedEntering ~= ped then return end
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
	if not DoesEntityExist(vehicle) then return end
    if GetSeatPedIsTryingToEnter(ped) ~= -3 then return end --no tasks
    if WaveShield.hasTeleported or (GetNetworkTime() - (WaveShield.GetSecuredStateBag("_WS:LastTeleportedTimer") or 0) > 10000) then return end
	local driver = GetPedInVehicleSeat(vehicle, -1)
    if driver ~= 0 then return end

    local currentTime = WaveShield.Native.GetGameTimer()
    if currentTime - lastHijack < 100 then
        hijackStrike()
-- Zm1hLnd0ZiBldmVyeXdoZXJl
        lastHijack = 0
        return
    end

    lastHijack = currentTime
end))

local scriptGravity = 25.0
local scriptCheatPowerIncrease = 1.1
local scriptTopSpeedModifier = 1.1

local overridedBoosts = {
    [GetHashKey("sanchez")] = 18.0,
    [GetHashKey("sanchez2")] = 18.0,
    [GetHashKey("banshee2")] = 20.0,
}

local checkVehicleSpeed = LPH_JIT_MAX(function()
    if not WaveShield.Config.Entities.AntiSpeedModifier and not WaveShield.Config.Entities.AntiHandlingModifier then
        return
    end

    if not WaveShield.isPlayerInVehicle or not WaveShield.isPlayerDriver then
        return
    end
    
    if WaveShield.Config.Entities.AntiSpeedModifier then
        local override = overridedBoosts[WaveShield.vehicleModel]
        if (override ~= nil and scriptTopSpeedModifier < override and WaveShield.vehicleTopSpeedModifier > override) or (override == nil and WaveShield.vehicleTopSpeedModifier > (scriptTopSpeedModifier + 1)) then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SPEED_MODIFIER, {
                vehicle = WaveShield.GetVehicleName(WaveShield.vehicleModel),
                speedModifier = WaveShield.vehicleTopSpeedModifier,
                script = scriptTopSpeedModifier,
            })
            return
        end

        if math.floor(WaveShield.vehicleCheatPowerIncrease) > math.floor(scriptCheatPowerIncrease) then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SPEED_MODIFIER, {
                vehicle = WaveShield.GetVehicleName(WaveShield.vehicleModel),
                torqueModifier = WaveShield.vehicleCheatPowerIncrease,
                script = scriptCheatPowerIncrease,
            })
            return
        end
-- Zm1hLnd0Zg==
    end

    if WaveShield.Config.Entities.AntiHandlingModifier then
        if math.floor(WaveShield.vehicleGravityAmount) > math.floor(scriptGravity) then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_HANDLING_MODIFIER, {
                vehicle = WaveShield.GetVehicleName(WaveShield.vehicleModel),
                gravityModifier = WaveShield.vehicleGravityAmount,
                script = scriptGravity,
            })
            return
        end
    end
end)

WaveShield.RegisterDetection("vehicleSpeed", checkVehicleSpeed, 3000)

exports("newGravity", LPH_NO_VIRTUALIZE(function(newGravity)
    if newGravity <= 25.0 then
        scriptGravity = 25.0
    else
-- ZCBpIHMgYyBvIHIgZCAuIGdnIC8gZm1h
        scriptGravity = WaveShield.tonumber(string.format("%.1f", newGravity))
    end
end))

exports("newCheatPowerIncrease", LPH_NO_VIRTUALIZE(function(newCheatPowerIncrease)
    if newCheatPowerIncrease <= 1.1 then
        scriptCheatPowerIncrease = 1.1
    else
        scriptCheatPowerIncrease = WaveShield.tonumber(string.format("%.1f", newCheatPowerIncrease))
    end
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
end))

exports("newTopSpeedModifier", LPH_NO_VIRTUALIZE(function(newTopSpeedModifier)
    if newTopSpeedModifier <= 1.1 then
        scriptTopSpeedModifier = 1.1
    else
        scriptTopSpeedModifier = WaveShield.tonumber(string.format("%.1f", newTopSpeedModifier))
    end
end))


local lastVehiclePlate, lastVehicle = "", 0

local checkVehiclePlateChanger = LPH_JIT_MAX(function()
    if not WaveShield.Config.Entities.AntiVehiclePlateChanger then
        return
    end
-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B

    if not WaveShield.isPlayerInVehicle or not WaveShield.isPlayerDriver then
        lastVehiclePlate, lastVehicle = "", 0
        return
    end

    if WaveShield.Native.GetGameTimer() < (WaveShield.GetSecuredStateBag("_WS:LastChangedVehiclePlate") or 0) + 10000 then
        lastVehiclePlate, lastVehicle = "", 0
        return
-- ZiBtIGE=
    end 
    
    local vehiclePlate = string.gsub(GetVehicleNumberPlateText(WaveShield.playerCurrentVehicle) or "", "%s+", "")

    if DoesEntityExist(WaveShield.playerCurrentVehicle) and WaveShield.playerCurrentVehicle == lastVehicle and vehiclePlate and vehiclePlate ~= lastVehiclePlate then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_VEHICLE_PLATE_CHANGER, {
            oldPlate = lastVehiclePlate,
            newPlate = vehiclePlate,
        })
    end

    lastVehiclePlate = vehiclePlate
    lastVehicle = WaveShield.playerCurrentVehicle
end)

WaveShield.RegisterDetection("vehiclePlateChanger", checkVehiclePlateChanger, 3000)

RegisterNetEvent("__WaveShield:setVehicleNumberPlateText", function(plateText)
    if not plateText then return end
    WaveShield.SetSecuredStateBag("_WS:LastChangedVehiclePlate", WaveShield.Native.GetGameTimer(), false)
end)

exports("ChangeVehiclePlate", LPH_NO_VIRTUALIZE(function(vehicle, plateText)
-- ZGlzY29yZC5nZy9mbWE=
    if not plateText then return end
-- UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUCBpdHMgZm1h
    WaveShield.SetSecuredStateBag("_WS:LastChangedVehiclePlate", WaveShield.Native.GetGameTimer(), false)
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
end))


local degreesToRadians = math.pi / 180

local RotationToDirection = LPH_NO_VIRTUALIZE(function(rotation)
	local radiansZ = rotation.z * degreesToRadians
    local radiansX = rotation.x * degreesToRadians
    local num = math.abs(math.cos(radiansX))
    
    return vector3(
        -math.sin(radiansZ) * num,
        math.cos(radiansZ) * num,
        math.sin(radiansX)
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
    )
end)

-- =========================================================================== --
-- ================= TRUE SILENT AIM DETECTION SYSTEM ==================== --
-- =========================================================================== --

local silentAimConfig = {
    maxTrajectoryDeviation = 2.0,     -- Max meters between expected hit and actual hit
    maxScreenDeviation = 70,         -- Max pixels between crosshair and hit point (increased)
    
    minDetectionDistance = 4.0,       -- Minimum distance to perform checks
    maxDetectionDistance = 250.0,     -- Maximum distance to check
    
    shotValidityWindow = 50,         -- ms after shot to consider impact valid
    
    minShotsForPattern = 3,           -- Minimum shots to detect patterns
    
    excludedWeaponGroups = {
        [GetHashKey("GROUP_SHOTGUN")] = true,
        [GetHashKey("GROUP_SNIPER")] = true,
        [GetHashKey("GROUP_THROWN")] = true,
        [GetHashKey("GROUP_HEAVY")] = true,
        [GetHashKey("GROUP_MELEE")] = true
    },
}

local silentAimData = {
    lastShotTime = 0,
    shotFired = false,
    shotData = nil, -- Store camera data when shot is fired
    screenCenter = { x = 0, y = 0 },
    
    lastCameraRotation = nil,
    lastMovementTime = 0,
    mouseVelocity = 0,

    recentHits = {},
    totalSuspiciousShots = 0,
}

local function detectRapidMouseMovement(currentRotation)
    local currentTime = WaveShield.Native.GetGameTimer()
    silentAimData.mouseVelocity = 0
    if silentAimData.lastCameraRotation then
        local timeDelta = currentTime - silentAimData.lastMovementTime
        if timeDelta > 0 and timeDelta < 500 then -- Within 500ms
            local rotationDelta = #(currentRotation - silentAimData.lastCameraRotation)
            silentAimData.mouseVelocity = rotationDelta / (timeDelta / 1000) -- degrees per second
        end
    end
    
    silentAimData.lastCameraRotation = currentRotation
    silentAimData.lastMovementTime = currentTime
    
    return silentAimData.mouseVelocity
end


local calculateExpectedHitPoint = LPH_NO_VIRTUALIZE(function(shotData, impactDistance)
    if not shotData or not shotData.cameraCoords or not shotData.cameraDirection then 
        return nil 
    end
    
    return vector3(
        shotData.cameraCoords.x + (shotData.cameraDirection.x * impactDistance),
        shotData.cameraCoords.y + (shotData.cameraDirection.y * impactDistance),
        shotData.cameraCoords.z + (shotData.cameraDirection.z * impactDistance)
    )
end)

-- Main trajectory deviation detection (core of silent aim detection)
local analyzeTrajectoryDeviation = LPH_NO_VIRTUALIZE(function(impactCoords, shotData)
    -- Calculate where bullet should have gone based on camera direction
    local impactDistance = #(shotData.cameraCoords - impactCoords)
    local expectedHitPoint = calculateExpectedHitPoint(shotData, impactDistance)
    
    if not expectedHitPoint then return false, 0 end
    
    -- Calculate 3D deviation between expected hit and actual victim location
    local trajectoryDeviation = #(expectedHitPoint - impactCoords)
    
    -- Use distance-based thresholds
    local threshold = silentAimConfig.maxTrajectoryDeviation
    
    local isSuspicious = trajectoryDeviation > threshold

    return isSuspicious, trajectoryDeviation
end)

-- Screen space analysis - where was crosshair vs where target is
local analyzeScreenDeviation = LPH_NO_VIRTUALIZE(function(impactCoords, shotData)
    if not shotData or not impactCoords then return false, 0 end
    
    -- Use exact impact coordinates for maximum precision
    local onScreen, screenX, screenY = GetScreenCoordFromWorldCoord(impactCoords.x, impactCoords.y, impactCoords.z)
    
    if not onScreen then return false, 0 end
    
    local screenWidth, screenHeight = GetActiveScreenResolution()
    local impactScreenX = screenX * screenWidth
    local impactScreenY = screenY * screenHeight
    silentAimData.screenCenter.x = screenWidth / 2
    silentAimData.screenCenter.y = screenHeight / 2

    -- Calculate distance from crosshair center to exact impact point
    local deltaX = impactScreenX - silentAimData.screenCenter.x
    local deltaY = impactScreenY - silentAimData.screenCenter.y
    local screenDeviation = math.sqrt(deltaX * deltaX + deltaY * deltaY)
    
    -- Use distance-based thresholds
    local distanceToImpact = #(shotData.cameraCoords - impactCoords)
    
    local threshold = silentAimConfig.maxScreenDeviation
    
    local isSuspicious = screenDeviation > threshold
    return isSuspicious, screenDeviation
end)

-- Pattern detection for multiple suspicious shots
local updateSuspiciousPatterns = LPH_NO_VIRTUALIZE(function(isSuspicious)
    local currentTime = WaveShield.Native.GetGameTimer()
    
    -- Clean old entries (keep last 30 seconds)
    for i = #silentAimData.recentHits, 1, -1 do
        if currentTime - silentAimData.recentHits[i].time > 30000 then
            table.remove(silentAimData.recentHits, i)
        end
    end
    
    -- Add current shot
    table.insert(silentAimData.recentHits, {
        time = currentTime,
        suspicious = isSuspicious
    })
    
    if isSuspicious then
        silentAimData.totalSuspiciousShots = silentAimData.totalSuspiciousShots + 1
    end
    
    -- Check if we have enough suspicious shots in recent history
    local recentSuspicious = 0
    for _, hit in WaveShield.Lua.ipairs(silentAimData.recentHits) do
        if hit.suspicious then
            recentSuspicious = recentSuspicious + 1
        end
    end
    
    -- If 3+ suspicious shots in recent history, trigger detection
    return recentSuspicious >= silentAimConfig.minShotsForPattern
end)

local shouldMonitorWeapon = LPH_NO_VIRTUALIZE(function(weaponHash)
    if not weaponHash or weaponHash == WaveShield.Native.GetHashKey("WEAPON_UNARMED") then
        return false
    end
    
    local weaponGroup = GetWeapontypeGroup(weaponHash)
    if silentAimConfig.excludedWeaponGroups[weaponGroup] then
        return false
    end
    
    local damageType = GetWeaponDamageType(weaponHash)
    return damageType == 3 -- Bullet damage only
end)

-- Core silent aim detection based on trajectory deviation
local validateShotLegitimacy = LPH_JIT_MAX(function(victim, impactCoords, weaponHash)
    local shooterCoords = GetEntityCoords(WaveShield.playerPed)
    local victimCoords = GetEntityCoords(victim)
    local distanceToVictim = #(shooterCoords - victimCoords)
    
    -- Distance checks
    if distanceToVictim < silentAimConfig.minDetectionDistance then
        return true, "too_close"
    end
    
    if distanceToVictim > silentAimConfig.maxDetectionDistance then
        return true, "too_far"
    end
    
    -- Weapon legitimacy check
    if not shouldMonitorWeapon(weaponHash) then
        return true, "excluded_weapon"
    end

    -- Check for rapid mouse movement (high-sens / flick shots)
    local mouseVelocity = silentAimData.shotData and silentAimData.shotData.mouseVelocity or 0
    
    -- EXCLUDE rapid movements from detection entirely
    if mouseVelocity > 100 then
        return true, "rapid_movement_excluded", {
            mouseVelocity = mouseVelocity,
            reason = "Shot excluded due to rapid mouse movement"
        }
    end
    
    local suspiciousTrajectory, trajectoryDeviation = analyzeTrajectoryDeviation(impactCoords, silentAimData.shotData)
    
    -- SECONDARY CHECK: Screen space analysis (precise impact point)
    local suspiciousScreen, screenDeviation = analyzeScreenDeviation(impactCoords, silentAimData.shotData)
    
    -- Determine if this shot is suspicious based on both methods
    local isSuspicious = suspiciousTrajectory or suspiciousScreen
    
    -- Update pattern tracking
    local hasPattern = updateSuspiciousPatterns(isSuspicious)
    
    -- INSTANT DETECTION for clear violations (normal thresholds)
    if suspiciousTrajectory and trajectoryDeviation > (silentAimConfig.maxTrajectoryDeviation * 1.5) then
        -- Very obvious trajectory deviation = instant detection
        return false, {
            reason = "instant_trajectory_violation",
            trajectoryDeviation = trajectoryDeviation,
            threshold = silentAimConfig.maxTrajectoryDeviation * 1.5,
            distance = distanceToVictim,
            screenDeviation = screenDeviation,
            mouseVelocity = mouseVelocity,
        }
    end
    
    if suspiciousScreen and screenDeviation > (silentAimConfig.maxScreenDeviation * 3.0) then
        -- Very obvious screen deviation = instant detection (adjusted for movement)
        return false, {
            reason = "instant_screen_violation",
            screenDeviation = screenDeviation,
            threshold = silentAimConfig.maxScreenDeviation * 3.0,
            distance = distanceToVictim,
            trajectoryDeviation = trajectoryDeviation,
            mouseVelocity = mouseVelocity,
        }
    end
    
    -- PATTERN DETECTION for legit configs (multiple suspicious shots)
    if hasPattern then
        return false, {
            reason = "pattern_detection",
            suspiciousShots = silentAimData.totalSuspiciousShots,
            recentSuspicious = #silentAimData.recentHits,
            trajectoryDeviation = trajectoryDeviation,
            screenDeviation = screenDeviation,
            distance = distanceToVictim,
            mouseVelocity = mouseVelocity,
        }
    end
    
    -- COMBINED ANALYSIS for borderline cases
    if isSuspicious and distanceToVictim > 30 then
        -- For distant shots, any deviation is more suspicious
        if (trajectoryDeviation and trajectoryDeviation > silentAimConfig.maxTrajectoryDeviation * 0.7) and
           (screenDeviation and screenDeviation > silentAimConfig.maxScreenDeviation * 0.7) then
            return false, {
                reason = "distance_based_violation",
                trajectoryDeviation = trajectoryDeviation,
                screenDeviation = screenDeviation,
                distance = distanceToVictim,
                mouseVelocity = mouseVelocity,
            }
        end
    end
    
    -- Shot appears legitimate
    return true, "legitimate_shot"
end)

local function isPedAWitness(witnesses, ped)
    if not witnesses then return false end
    
    for k, v in WaveShield.Lua.pairs(witnesses) do
        if v == ped or v == 0 then
            return true
        end
    end
    return false
end

-- Enhanced gunshot event handler
AddEventHandler("CEventGunShot", LPH_JIT_MAX(function(witnesses, shooter)
    if shooter ~= WaveShield.playerPed then return end
    if WaveShield.Native.IsEntityDead(shooter) then return end
    --if witnesses and witnesses[1] and not isPedAWitness(witnesses, shooter) then return end
    if GetPedParachuteState(shooter) > 0 then return end
    if GetRenderingCam() ~= -1 then return end

    local timer = WaveShield.Native.GetGameTimer()
    if timer - silentAimData.lastShotTime == 0 then
        return
    end

    local hold, weaponHash = WaveShield.Native.GetCurrentPedWeapon(WaveShield.playerPed, true)
    if not hold and (not WaveShield.Native.HasPedGotWeapon(WaveShield.playerPed, weaponHash, false) or weaponHash == -1569615261) and (WaveShield.Native.IsPlayerFreeForAmbientTask(WaveShield.playerId) or not WaveShield.Native.IsAimCamActive()) then
        if WaveShield.Config.Weapons.AntiSpoofedBullets then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SPOOFED_BULLETS, {
                reason = "Invalid Weapon",
                debug = ("%s:%s"):format(hold, weaponHash),
            })
        end
        silentAimData.shotFired = false
        return
    end

    if not WaveShield.Config.Beta.AntiSilentAim then return end
    if not shouldMonitorWeapon(weaponHash) then return end


    -- if not WaveShield.Native.IsAimCamActive() and WaveShield.Native.IsPlayerFreeForAmbientTask(WaveShield.playerId) and not WaveShield.Native.IsPedRunningRagdollTask(WaveShield.playerPed) and not WaveShield.Native.IsPedFalling(WaveShield.playerPed) then
    --     WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SILENT_AIM, {
    --         reason = "Invalid Aim State",
    --     })
    --     silentAimData.shotFired = false
    --     return
    -- end

    silentAimData.lastShotTime = timer
    silentAimData.shotFired = true
    
    -- Store exact camera data at the moment of shooting
    local cameraCoords = WaveShield.Native.GetGameplayCamCoord()
    local cameraRotation = WaveShield.Native.GetGameplayCamRot()
    
    -- Detect if this was a rapid mouse movement / flick shot
    detectRapidMouseMovement(cameraRotation)

    silentAimData.shotData = {
        cameraCoords = cameraCoords,
        cameraRotation = cameraRotation,
        cameraDirection = RotationToDirection(cameraRotation),
        mouseVelocity = silentAimData.mouseVelocity
    }
end))

-- Enhanced bullet impact handler with instant detection
AddEventHandler("CEventGunShotBulletImpact", LPH_JIT_MAX(function(witnesses, shooter)
    if not WaveShield.Config.Beta.AntiSilentAim then return end
    if shooter ~= WaveShield.playerPed then return end
    if not silentAimData.shotFired then return end
    if GetPedParachuteState(shooter) > 0 then return end
    if GetRenderingCam() ~= -1 then return end

    local currentTime = WaveShield.Native.GetGameTimer()
    if currentTime - silentAimData.lastShotTime >= silentAimConfig.shotValidityWindow then 
        silentAimData.shotFired = false
        return 
    end

    if WaveShield.Native.IsPedDeadOrDying(shooter, true) or IsPedRagdoll(shooter) then
        silentAimData.shotFired = false
        return
    end

    -- Verify this was actually a hit
    local hold, weaponHash = WaveShield.Native.GetCurrentPedWeapon(WaveShield.playerPed, true)
    if not hold then
        silentAimData.shotFired = false
        return
    end

    local success, impactCoords = GetPedLastWeaponImpactCoord(shooter)
    if not success then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SILENT_AIM, {
            reason = "Bullet Impact Manipulation",
        })
        silentAimData.shotFired = false
        return
    elseif success and impactCoords == vector3(0.0, 0.0, 0.0) then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SILENT_AIM, {
            reason = "Bullet Impact Manipulation #2",
        })
        silentAimData.shotFired = false
        return
    end

    -- Find victim near impact point
    local victim, victimDistance = getClosestPed(impactCoords, 3.0)
    if not victim or not IsPedAPlayer(victim) or IsPedInAnyVehicle(victim, false) then
        silentAimData.shotFired = false
        return
    end

    -- Check if victim was damaged by our weapon recently
    if not HasEntityBeenDamagedByWeapon(victim, weaponHash, 0) then
        silentAimData.shotFired = false
        return
    end

    local lastDamagedTime = GetTimeOfLastPedWeaponDamage(victim, weaponHash)
    if currentTime - lastDamagedTime > silentAimConfig.shotValidityWindow then 
        silentAimData.shotFired = false
        return
    end

    -- Clear damage markers to prevent duplicate detections
    ClearPedLastWeaponDamage(victim)
    ClearEntityLastWeaponDamage(victim)

    -- if not HasEntityClearLosToEntity(WaveShield.playerPed, victim, 17) and IsEntityOccluded(victim) then
    --     WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SILENT_AIM, {
    --         reason = "magic_bullet",
    --     })
    -- end

    -- Validate shot legitimacy with advanced detection
    local isLegitimate, detectionData = validateShotLegitimacy(victim, impactCoords, weaponHash)

    if not isLegitimate then
        -- INSTANT DETECTION - Enhanced detection for all types of silent aim
        local shooterCoords = GetEntityCoords(shooter)
        local victimCoords = GetEntityCoords(victim)
        local distanceToVictim = #(shooterCoords - victimCoords)
        
        detectionData.distance = distanceToVictim
        
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_SILENT_AIM, detectionData)
    end

    -- Reset shot state
    silentAimData.shotFired = false
end))


WaveShield.CreateThread(LPH_JIT_MAX(function()
    local minDeltaToTrigger = 0.005
    local previousCamRot = WaveShield.Native.GetGameplayCamRot(2)
    local previousCamHeading = GetGameplayCamRelativeHeading()
    local lastFov = GetGameplayCamFov() 
    local lastInput = 0
    local steadyFrames = 0
    local strikeCount = 0
    local lastWeaponBlocked = 0
    local lastInCollision = 0
    local lastChangedWeapon = 0
    local lastWeapon = WaveShield.Native.GetHashKey("WEAPON_UNARMED")

    local aimbotStrike = WaveShield.StrikesSystem.createStrikeSystem(
        "AntiAimBot",
        5,
        function(playerId)
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_AIM_BOT, {
                debug = math.abs(WaveShield.Native.GetGameplayCamRot(2).z - previousCamRot.z),
            })
        end,
        5000
    )

    while true do
        if WaveShield.Config.Weapons.AntiAimBot then
            local weaponHash = WaveShield.Native.GetSelectedPedWeapon(WaveShield.playerPed)
            local wait = 100
            local timer = WaveShield.Native.GetGameTimer()
            
            if WaveShield.Native.IsAimCamActive() and GetPedConfigFlag(WaveShield.playerPed, 78, true) and not IsPedInCover(WaveShield.playerPed, 0) and timer - lastWeaponBlocked > 1000 and timer - lastChangedWeapon > 1000 and timer - lastInCollision > 1000 and
                not (IsGameplayCamShaking() and WaveShield.Native.IsPedInAnyVehicle(WaveShield.playerPed, false)) and
                (not IsGameplayCamShaking() or
-- ZiBtIGE=
                    (GetFollowPedCamViewMode() ~= 4 or
                        not IsPlayerFreeAiming(WaveShield.playerId)
                    )
                ) and IsUsingKeyboard(0) and not IsEntityInAir(WaveShield.playerPed)
            then
                local weaponGroup = GetWeapontypeGroup(weaponHash)
                if weaponGroup ~= -1212426201 and weaponGroup ~= -1569042529 then
                    local camRot = WaveShield.Native.GetGameplayCamRot(2)
                    local camHeading = GetGameplayCamRelativeHeading()
                    local ix = GetDisabledControlNormal(0, 1)
                    local iy = GetDisabledControlNormal(0, 2)
                    local currentFov = GetGameplayCamFov()
                    local fovDiff = math.abs(currentFov - lastFov)

                    -- FOV needs to be stable
                    if fovDiff < 0.05 then
                        steadyFrames = steadyFrames + 1
                    else
                        steadyFrames = 0
                    end

                    if previousCamRot and steadyFrames > 3 then
                        local yawDelta = math.abs(camRot.z - previousCamRot.z)
                        local camHeadingDelta = math.abs(camHeading - previousCamHeading)
                        local input = math.abs(ix) + math.abs(iy)

                        if yawDelta > minDeltaToTrigger and camHeadingDelta == 0.0 and input == 0.0 and lastInput == 0.0 then
                            strikeCount = strikeCount + 1
                        else
                            strikeCount = 0
                        end

                        lastInput = input
                    else
                        strikeCount = 0
                    end

                    if strikeCount >= 10 then
                        aimbotStrike()
                        strikeCount = 0
                    end

                    lastFov = currentFov
                    previousCamRot = camRot
                    previousCamHeading = camHeading
                    wait = 0
                else
                    wait = 1000
                end
            end

            if GetIsTaskActive(WaveShield.playerPed, 299) then
                lastWeaponBlocked = timer
            end

            if #GetCollisionNormalOfLastHitForEntity(WaveShield.playerPed) > 0 then
                lastInCollision = timer
            end
            
            if lastWeapon ~= weaponHash then
                lastChangedWeapon = timer
            end

            lastWeapon = weaponHash

            WaveShield.Wait(wait)
        else
            WaveShield.Wait(10000)
        end
    end
end))

local hasAddedAmmo = false

local function isPedAWitness(witnesses, ped)
    if not witnesses then return false end
    
    for k, v in WaveShield.Lua.pairs(witnesses) do
        if v == ped or v == 0 then
            return true
        end
    end
    return false
end

local function IsPlayerAiming(player)
    return IsPlayerFreeAiming(player) or WaveShield.Native.IsAimCamActive() or IsAimCamThirdPersonActive()
end

local checkAmmos = LPH_JIT_MAX(function()
    if not WaveShield.isHoldingWeapon then
        return
    end

    local weaponDamageType = GetWeaponDamageType(WaveShield.currentWeapon)
    if WaveShield.Config.Weapons.AntiExplosiveBullets then
        local weaponGroup = GetWeapontypeGroup(WaveShield.currentWeapon)
        if (weaponDamageType == 5 or weaponDamageType == 6 or weaponDamageType == 13) and not IsPedArmed(WaveShield.playerPed, 2) and weaponGroup ~= WaveShield.Native.GetHashKey("GROUP_HEAVY") then
            local weapData = WaveShield.WEAPON_DATA[WaveShield.currentWeapon]
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_EXPLOSIVE_BULLETS, {
                weapon = weapData and weapData.weaponName or WaveShield.currentWeapon,
            })
            return
        elseif (weaponDamageType == 4 --[[or weaponDamageType == 10]]) and GetWeapontypeGroup(WaveShield.currentWeapon) ~= 690389602 then
            local weapData = WaveShield.WEAPON_DATA[WaveShield.currentWeapon]
            WaveShield.DetectPlayer("Stunning Bullets Detected", {
                weapon = weapData and weapData.weaponName or WaveShield.currentWeapon,
            })
            return
        end
    end

    if WaveShield.Config.Weapons.AntiNoRecoil and (WaveShield.currentWeapon ~= 0) and (weaponDamageType == 3) then
        local recoilAmplitude = GetWeaponRecoilShakeAmplitude(WaveShield.currentWeapon)
        if recoilAmplitude <= 0.0 then
            local weapData = WaveShield.WEAPON_DATA[WaveShield.currentWeapon]
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NO_RECOIL, {
                weapon = weapData and weapData.weaponName or WaveShield.currentWeapon,
            })
            return
        end
    end

    if weaponDamageType == 3 then
        local ammoInWeapon = GetAmmoInPedWeapon(WaveShield.playerPed, WaveShield.currentWeapon)
        local _, ammoInClip = GetAmmoInClip(WaveShield.playerPed, WaveShield.currentWeapon)
        local __, maxAmmo = GetMaxAmmo(WaveShield.playerPed, WaveShield.currentWeapon)

        if WaveShield.Config.Weapons.AntiAmmoCheating and (ammoInWeapon > maxAmmo) then
            local weapData = WaveShield.WEAPON_DATA[WaveShield.currentWeapon]
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_AMMO_CHEATING, {
                ammoInWeapon = ammoInWeapon,
                maxAmmo = maxAmmo,
                weapon = weapData and weapData.weaponName or WaveShield.currentWeapon,
            })
        end

        if WaveShield.Config.Weapons.AntiAmmoCheating and (ammoInClip > maxAmmo) then
            local weapData = WaveShield.WEAPON_DATA[WaveShield.currentWeapon]
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_AMMO_CHEATING, {
                ammoInClip = ammoInClip,
                maxAmmo = maxAmmo,
                weapon = weapData and weapData.weaponName or WaveShield.currentWeapon,
            })
        end
    end
end)

WaveShield.RegisterDetection("ammos", checkAmmos, 5000)

local lastShotTime, lastWeaponHash, lastAmmoInWeapon, lastAmmoInClip = 0, 0, 0, 0

AddEventHandler("CEventGunShot", LPH_JIT_MAX(function(witnesses, shooter)
    if not WaveShield.Config.Weapons.AntiInfiniteAmmo then return end
    if shooter ~= WaveShield.playerPed then return end
    if witnesses and witnesses[1] and not isPedAWitness(witnesses, shooter) then return end
    if WaveShield.isPlayerDead then return end
    if hasAddedAmmo then return end
    if not IsPlayerAiming(WaveShield.playerId) then return end
    if WaveShield.isPlayerInVehicle then return end
    if IsEntityAttachedToEntity(WaveShield.playerPed) then return end

    local hold, weaponHash = GetCurrentPedWeapon(shooter, true)
    if not hold then return end

    local weaponDamageType = GetWeaponDamageType(weaponHash)
    if weaponDamageType ~= 3 then return end

    local ammoInWeapon = GetAmmoInPedWeapon(WaveShield.playerPed, weaponHash)
    local _, ammoInClip = GetAmmoInClip(WaveShield.playerPed, weaponHash)

    local currentTime = GetGameTimer()
-- V1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXVyBmbWEud3Rm
    if weaponHash == lastWeaponHash and (currentTime - lastShotTime) < 500 then
        local weapData = WaveShield.WEAPON_DATA[weaponHash]
        local weaponName = weapData and weapData.weaponName or weaponHash
        
        if ammoInWeapon > 0 and ammoInWeapon >= lastAmmoInWeapon then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_INFINITE_AMMO, {
                ammoInWeapon = ammoInWeapon,
                lastAmmoInWeapon = lastAmmoInWeapon,
                weapon = weaponName,
            })
            return
        end

        if ammoInClip > 0 and ammoInClip >= lastAmmoInClip then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_INFINITE_AMMO, {
                ammoInClip = ammoInClip,
                lastAmmoInClip = lastAmmoInClip,
                weapon = weaponName,
            })
            return
        end

        if ammoInClip == lastAmmoInClip and ammoInWeapon ~= lastAmmoInWeapon then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_NO_RELOAD)
            return
        end
    end

    lastWeaponHash = weaponHash or 0
    lastAmmoInWeapon = ammoInWeapon or 0
    lastAmmoInClip = ammoInClip or 0
    lastShotTime = currentTime
end))

local expiresAmmo = 0
exports("hasAddedAmmo", LPH_NO_VIRTUALIZE(function()
    local timer = WaveShield.Native.GetGameTimer()
    if timer > expiresAmmo - 2000 then
        expiresAmmo = timer + 5000
        if not hasAddedAmmo then
            hasAddedAmmo = true
            WaveShield.CreateThread(function()
                while WaveShield.Native.GetGameTimer() < expiresAmmo do WaveShield.Wait(100) end
                hasAddedAmmo = false
            end)
        end
    end
end))

RegisterNetEvent("__WaveShield:hasAddedAmmo",function()
	exports["WaveShield"]:hasAddedAmmo()
end)


local checkHitbox = LPH_JIT_MAX(function()
    if not WaveShield.Config.Weapons.AntiHitboxModifier then
        return
    end
-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=

    if not HasModelLoaded(1885233650) then
        RequestModel(1885233650)
        return
    end
    
    local min, max = GetModelDimensions(1885233650)
    if min == vector3(0.0, 0.0, 0.0) or max == vector3(0.0, 0.0, 0.0) then
        return
    end

    local offsetMin = #(min - vector3(-0.6095175, -0.25, -1.3))
    local offsetMax = #(max - vector3(0.6099811, 0.25, 0.945))

    if offsetMin > 0.01 or offsetMax > 0.01 then
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_HITBOX_MODIFIER, {
            offsetMin = offsetMin,
            offsetMax = offsetMax,
        })
        return
    end
end)

WaveShield.RegisterDetection("hitbox", checkHitbox, 10000)

local allPickupsHashes = {}
local allPickups = {
    "PICKUP_WEAPON_BULLPUPSHOTGUN",
    "PICKUP_WEAPON_ASSAULTSMG",
    "PICKUP_VEHICLE_WEAPON_ASSAULTSMG",
    "PICKUP_WEAPON_PISTOL50",
    "PICKUP_VEHICLE_WEAPON_PISTOL50",
    "PICKUP_AMMO_BULLET_MP",
    "PICKUP_AMMO_MISSILE_MP",
    "PICKUP_AMMO_GRENADELAUNCHER_MP",
    "PICKUP_WEAPON_ASSAULTRIFLE",
    "PICKUP_WEAPON_CARBINERIFLE",
-- UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUCBpdHMgZm1h
    "PICKUP_WEAPON_ADVANCEDRIFLE",
    "PICKUP_WEAPON_MG",
    "PICKUP_WEAPON_COMBATMG",
    "PICKUP_WEAPON_SNIPERRIFLE",
    "PICKUP_WEAPON_HEAVYSNIPER",
    "PICKUP_WEAPON_MICROSMG",
    "PICKUP_WEAPON_SMG",
    "PICKUP_ARMOUR_STANDARD",
    "PICKUP_WEAPON_RPG",
    "PICKUP_WEAPON_MINIGUN",
    "PICKUP_HEALTH_STANDARD",
    "PICKUP_WEAPON_PUMPSHOTGUN",
    "PICKUP_WEAPON_SAWNOFFSHOTGUN",
    "PICKUP_WEAPON_ASSAULTSHOTGUN",
    "PICKUP_WEAPON_GRENADE",
    "PICKUP_WEAPON_MOLOTOV",
    "PICKUP_WEAPON_SMOKEGRENADE",
    "PICKUP_WEAPON_STICKYBOMB",
    "PICKUP_WEAPON_PISTOL",
    "PICKUP_WEAPON_COMBATPISTOL",
    "PICKUP_WEAPON_APPISTOL",
    "PICKUP_WEAPON_GRENADELAUNCHER",
    "PICKUP_MONEY_VARIABLE",
    "PICKUP_GANG_ATTACK_MONEY",
    "PICKUP_WEAPON_STUNGUN",
    "PICKUP_WEAPON_PETROLCAN",
    "PICKUP_WEAPON_KNIFE",
    "PICKUP_WEAPON_NIGHTSTICK",
    "PICKUP_WEAPON_HAMMER",
    "PICKUP_WEAPON_BAT",
    "PICKUP_WEAPON_GolfClub",
    "PICKUP_WEAPON_CROWBAR",
    "PICKUP_CUSTOM_SCRIPT",
-- ZiBtIGE=
    "PICKUP_CAMERA",
    "PICKUP_PORTABLE_PACKAGE",
    "PICKUP_PORTABLE_CRATE_UNFIXED",
    "PICKUP_PORTABLE_PACKAGE_LARGE_RADIUS",
    "PICKUP_PORTABLE_FM_CONTENT_MISSION_ENTITY_SMALL",
    "PICKUP_PORTABLE_CRATE_UNFIXED_INCAR",
    "PICKUP_PORTABLE_CRATE_UNFIXED_INAIRVEHICLE_WITH_PASSENGERS",
    "PICKUP_PORTABLE_CRATE_UNFIXED_INAIRVEHICLE_WITH_PASSENGERS_UPRIGHT",
    "PICKUP_PORTABLE_CRATE_UNFIXED_INCAR_WITH_PASSENGERS",
    "PICKUP_PORTABLE_CRATE_FIXED_INCAR_WITH_PASSENGERS",
    "PICKUP_PORTABLE_CRATE_FIXED_INCAR_SMALL",
    "PICKUP_PORTABLE_CRATE_UNFIXED_INCAR_SMALL",
    "PICKUP_PORTABLE_CRATE_UNFIXED_LOW_GLOW",
    "PICKUP_MONEY_CASE",
    "PICKUP_MONEY_WALLET",
    "PICKUP_MONEY_PURSE",
    "PICKUP_MONEY_DEP_BAG",
    "PICKUP_MONEY_MED_BAG",
    "PICKUP_MONEY_PAPER_BAG",
    "PICKUP_MONEY_SECURITY_CASE",
    "PICKUP_VEHICLE_WEAPON_COMBATPISTOL",
    "PICKUP_VEHICLE_WEAPON_APPISTOL",
    "PICKUP_VEHICLE_WEAPON_PISTOL",
    "PICKUP_VEHICLE_WEAPON_GRENADE",
    "PICKUP_VEHICLE_WEAPON_MOLOTOV",
    "PICKUP_VEHICLE_WEAPON_SMOKEGRENADE",
    "PICKUP_VEHICLE_WEAPON_STICKYBOMB",
    "PICKUP_VEHICLE_HEALTH_STANDARD",
    "PICKUP_VEHICLE_HEALTH_STANDARD_LOW_GLOW",
    "PICKUP_VEHICLE_ARMOUR_STANDARD",
    "PICKUP_VEHICLE_WEAPON_MICROSMG",
    "PICKUP_VEHICLE_WEAPON_SMG",
    "PICKUP_VEHICLE_WEAPON_SAWNOFF",
    "PICKUP_VEHICLE_CUSTOM_SCRIPT",
    "PICKUP_VEHICLE_CUSTOM_SCRIPT_NO_ROTATE",
    "PICKUP_VEHICLE_CUSTOM_SCRIPT_LOW_GLOW",
    "PICKUP_VEHICLE_MONEY_VARIABLE",
    "PICKUP_SUBMARINE",
    "PICKUP_HEALTH_SNACK",
    "PICKUP_PARACHUTE",
    "PICKUP_AMMO_PISTOL",
    "PICKUP_AMMO_SMG",
    "PICKUP_AMMO_RIFLE",
    "PICKUP_AMMO_MG",
    "PICKUP_AMMO_SHOTGUN",
    "PICKUP_AMMO_SNIPER",
    "PICKUP_AMMO_GRENADELAUNCHER",
    "PICKUP_AMMO_RPG",
    "PICKUP_AMMO_MINIGUN",
    "PICKUP_WEAPON_BOTTLE",
    "PICKUP_WEAPON_SNSPISTOL",
    "PICKUP_WEAPON_HEAVYPISTOL",
    "PICKUP_WEAPON_SPECIALCARBINE",
    "PICKUP_WEAPON_BULLPUPRIFLE",
    "PICKUP_WEAPON_PISTOLXM3",
    "PICKUP_WEAPON_CANDYCANE",
    "PICKUP_WEAPON_RAILGUNXM3",
    "PICKUP_WEAPON_RAYPISTOL",
    "PICKUP_WEAPON_RAYCARBINE",
    "PICKUP_WEAPON_RAYMINIGUN",
    "PICKUP_WEAPON_BULLPUPRIFLE_MK2",
    "PICKUP_WEAPON_DOUBLEACTION",
    "PICKUP_WEAPON_MARKSMANRIFLE_MK2",
    "PICKUP_WEAPON_PUMPSHOTGUN_MK2",
    "PICKUP_WEAPON_REVOLVER_MK2",
    "PICKUP_WEAPON_SNSPISTOL_MK2",
    "PICKUP_WEAPON_SPECIALCARBINE_MK2",
    "PICKUP_WEAPON_PROXMINE",
    "PICKUP_WEAPON_HOMINGLAUNCHER",
    "PICKUP_AMMO_HOMINGLAUNCHER",
    "PICKUP_WEAPON_GUSENBERG",
    "PICKUP_WEAPON_DAGGER",
    "PICKUP_WEAPON_VINTAGEPISTOL",
    "PICKUP_WEAPON_FIREWORK",
    "PICKUP_WEAPON_MUSKET",
    "PICKUP_AMMO_FIREWORK",
    "PICKUP_AMMO_FIREWORK_MP",
    "PICKUP_PORTABLE_DLC_VEHICLE_PACKAGE",
    "PICKUP_WEAPON_HATCHET",
    "PICKUP_WEAPON_RAILGUN",
    "PICKUP_WEAPON_HEAVYSHOTGUN",
    "PICKUP_WEAPON_MARKSMANRIFLE",
    "PICKUP_WEAPON_FLAREGUN",
    "PICKUP_AMMO_FLAREGUN",
    "PICKUP_WEAPON_CERAMICPISTOL",
    "PICKUP_WEAPON_HAZARDCAN",
    "PICKUP_WEAPON_NAVYREVOLVER",
    "PICKUP_WEAPON_COMBATSHOTGUN",
    "PICKUP_WEAPON_GADGETPISTOL",
    "PICKUP_WEAPON_MILITARYRIFLE",
    "PICKUP_WEAPON_KNUCKLE",
    "PICKUP_WEAPON_MARKSMANPISTOL",
    "PICKUP_WEAPON_COMBATPDW",
    "PICKUP_PORTABLE_CRATE_FIXED_INCAR",
    "PICKUP_WEAPON_COMPACTRIFLE",
    "PICKUP_WEAPON_DBSHOTGUN",
    "PICKUP_WEAPON_MACHETE",
    "PICKUP_WEAPON_MACHINEPISTOL",
    "PICKUP_WEAPON_FLASHLIGHT",
    "PICKUP_WEAPON_REVOLVER",
    "PICKUP_WEAPON_SWITCHBLADE",
    "PICKUP_WEAPON_AUTOSHOTGUN",
    "PICKUP_WEAPON_BATTLEAXE",
    "PICKUP_WEAPON_COMPACTLAUNCHER",
    "PICKUP_WEAPON_MINISMG",
    "PICKUP_WEAPON_PIPEBOMB",
    "PICKUP_WEAPON_POOLCUE",
    "PICKUP_WEAPON_WRENCH",
    "PICKUP_WEAPON_ASSAULTRIFLE_MK2",
    "PICKUP_WEAPON_CARBINERIFLE_MK2",
    "PICKUP_WEAPON_COMBATMG_MK2",
    "PICKUP_WEAPON_HEAVYSNIPER_MK2",
    "PICKUP_WEAPON_PISTOL_MK2",
    "PICKUP_WEAPON_SMG_MK2",
    "PICKUP_WEAPON_STONE_HATCHET",
    "PICKUP_WEAPON_METALDETECTOR",
    "PICKUP_WEAPON_TACTICALRIFLE",
    "PICKUP_WEAPON_PRECISIONRIFLE",
    "PICKUP_WEAPON_EMPLAUNCHER",
    "PICKUP_AMMO_EMPLAUNCHER",
    "PICKUP_WEAPON_HEAVYRIFLE",
    "PICKUP_WEAPON_PETROLCAN_SMALL_RADIUS",
    "PICKUP_WEAPON_FERTILIZERCAN",
    "PICKUP_WEAPON_STUNGUN_MP",
    "PICKUP_WEAPON_TECPISTOL",
    "PICKUP_WEAPON_BATTLERIFLE",
    "PICKUP_WEAPON_SNOWLAUNCHER",
    "PICKUP_WEAPON_HACKINGDEVICE",
}

WaveShield.CreateThread(function()
    for _, pickup in WaveShield.Lua.pairs(allPickups) do
        table.insert(allPickupsHashes, WaveShield.Native.GetHashKey(pickup))
    end
end)

local checkPickups = LPH_NO_VIRTUALIZE(function()
    if not WaveShield.Config.Entities.AntiPickupSpawn then
        return
    end

    for _, pickup in WaveShield.Lua.pairs(allPickupsHashes) do
        ToggleUsePickupsForPlayer(WaveShield.playerId, pickup, false)
    end
end)

WaveShield.RegisterDetection("pickups", checkPickups, 10000)

-- Use centralized weapon data from WaveShield.WEAPON_DATA (utils.lua)
local defaultWeaponDamages = {}

-- Build default damages lookup for setNewDamage export
for i = 1, #WaveShield.WEAPON_DATA do
    local weaponData = WaveShield.WEAPON_DATA[i]
    if weaponData.weaponDamages > 0 then
        defaultWeaponDamages[weaponData.weaponHash] = weaponData.weaponDamages
    end
end

local weaponsComponents = {
    [GetHashKey('COMPONENT_COMBATPISTOL_CLIP_01')] = {ComponentName = "COMPONENT_COMBATPISTOL_CLIP_01"},
    [GetHashKey('COMPONENT_COMBATPISTOL_CLIP_02')] = {ComponentName = "COMPONENT_COMBATPISTOL_CLIP_02"},
    [GetHashKey('COMPONENT_APPISTOL_CLIP_01')] = {ComponentName = "COMPONENT_APPISTOL_CLIP_01"},
    [GetHashKey('COMPONENT_APPISTOL_CLIP_02')] = {ComponentName = "COMPONENT_APPISTOL_CLIP_02"},
    [GetHashKey('COMPONENT_MICROSMG_CLIP_01')] = {ComponentName = "COMPONENT_MICROSMG_CLIP_01"},
    [GetHashKey('COMPONENT_MICROSMG_CLIP_02')] = {ComponentName = "COMPONENT_MICROSMG_CLIP_02"},
    [GetHashKey('COMPONENT_REVOLVER_CLIP_01')] = {ComponentName = "COMPONENT_REVOLVER_CLIP_01"},
    [GetHashKey('COMPONENT_SNSPISTOL_CLIP_01')] = {ComponentName = "COMPONENT_SNSPISTOL_CLIP_01"},
    [GetHashKey('COMPONENT_HEAVYPISTOL_CLIP_01')] = {ComponentName = "COMPONENT_HEAVYPISTOL_CLIP_01"},
    [GetHashKey('COMPONENT_HEAVYPISTOL_CLIP_02')] = {ComponentName = "COMPONENT_HEAVYPISTOL_CLIP_02"},
    [GetHashKey('COMPONENT_VINTAGEPISTOL_CLIP_01')] = {ComponentName = "COMPONENT_VINTAGEPISTOL_CLIP_01"},
    [GetHashKey('COMPONENT_VINTAGEPISTOL_CLIP_02')] = {ComponentName = "COMPONENT_VINTAGEPISTOL_CLIP_02"},
    [GetHashKey('COMPONENT_CERAMICPISTOL_CLIP_01')] = {ComponentName = "COMPONENT_CERAMICPISTOL_CLIP_01"},
    [GetHashKey('COMPONENT_CERAMICPISTOL_CLIP_02')] = {ComponentName = "COMPONENT_CERAMICPISTOL_CLIP_02"},
    [GetHashKey('COMPONENT_MACHINEPISTOL_CLIP_01')] = {ComponentName = "COMPONENT_MACHINEPISTOL_CLIP_01"},
    [GetHashKey('COMPONENT_MACHINEPISTOL_CLIP_03')] = {ComponentName = "COMPONENT_MACHINEPISTOL_CLIP_03"},
    [GetHashKey('COMPONENT_HEAVYPISTOL_CLIP_02')] = {ComponentName = "COMPONENT_HEAVYPISTOL_CLIP_02"},
    [GetHashKey('COMPONENT_SMG_CLIP_01')] = {ComponentName = "COMPONENT_SMG_CLIP_01"},
    [GetHashKey('COMPONENT_SMG_CLIP_02')] = {ComponentName = "COMPONENT_SMG_CLIP_02"},
    [GetHashKey('COMPONENT_SMG_CLIP_03')] = {ComponentName = "COMPONENT_SMG_CLIP_03"},
    [GetHashKey('COMPONENT_MINISMG_CLIP_01')] = {ComponentName = "COMPONENT_MINISMG_CLIP_01"},
    [GetHashKey('COMPONENT_MINISMG_CLIP_02')] = {ComponentName = "COMPONENT_MINISMG_CLIP_02"},
    [GetHashKey('COMPONENT_ASSAULTRIFLE_CLIP_01')] = {ComponentName = "COMPONENT_ASSAULTRIFLE_CLIP_01"},
    [GetHashKey('COMPONENT_ASSAULTRIFLE_CLIP_02')] = {ComponentName = "COMPONENT_ASSAULTRIFLE_CLIP_02"},
    [GetHashKey('COMPONENT_CARBINERIFLE_CLIP_01')] = {ComponentName = "COMPONENT_CARBINERIFLE_CLIP_01"},
    [GetHashKey('COMPONENT_CARBINERIFLE_CLIP_02')] = {ComponentName = "COMPONENT_CARBINERIFLE_CLIP_02"},
    [GetHashKey('COMPONENT_ADVANCEDRIFLE_CLIP_01')] = {ComponentName = "COMPONENT_ADVANCEDRIFLE_CLIP_01"},
    [GetHashKey('COMPONENT_ADVANCEDRIFLE_CLIP_02')] = {ComponentName = "COMPONENT_ADVANCEDRIFLE_CLIP_02"},
    [GetHashKey('COMPONENT_MG_CLIP_01')] = {ComponentName = "COMPONENT_MG_CLIP_01"},
    [GetHashKey('COMPONENT_MG_CLIP_02')] = {ComponentName = "COMPONENT_MG_CLIP_02"},
    [GetHashKey('COMPONENT_COMBATMG_CLIP_01')] = {ComponentName = "COMPONENT_COMBATMG_CLIP_01"},
    [GetHashKey('COMPONENT_COMBATMG_CLIP_02')] = {ComponentName = "COMPONENT_COMBATMG_CLIP_02"},
    [GetHashKey('COMPONENT_PUMPSHOTGUN_CLIP_01')] = {ComponentName = "COMPONENT_PUMPSHOTGUN_CLIP_01"},
    [GetHashKey('COMPONENT_SAWNOFFSHOTGUN_CLIP_01')] = {ComponentName = "COMPONENT_SAWNOFFSHOTGUN_CLIP_01"},
    [GetHashKey('COMPONENT_ASSAULTSHOTGUN_CLIP_01')] = {ComponentName = "COMPONENT_ASSAULTSHOTGUN_CLIP_01"},
    [GetHashKey('COMPONENT_ASSAULTSHOTGUN_CLIP_02')] = {ComponentName = "COMPONENT_ASSAULTSHOTGUN_CLIP_02"},
    [GetHashKey('COMPONENT_SNIPERRIFLE_CLIP_01')] = {ComponentName = "COMPONENT_SNIPERRIFLE_CLIP_01"},
    [GetHashKey('COMPONENT_HEAVYSNIPER_CLIP_01')] = {ComponentName = "COMPONENT_HEAVYSNIPER_CLIP_01"},
    [GetHashKey('COMPONENT_MINIGUN_CLIP_01')] = {ComponentName = "COMPONENT_MINIGUN_CLIP_01"},
    [GetHashKey('COMPONENT_RPG_CLIP_01')] = {ComponentName = "COMPONENT_RPG_CLIP_01"},
    [GetHashKey('COMPONENT_GRENADELAUNCHER_CLIP_01')] = {ComponentName = "COMPONENT_GRENADELAUNCHER_CLIP_01"},
    [GetHashKey('COMPONENT_BULLPUPSHOTGUN_CLIP_01')] = {ComponentName = "COMPONENT_BULLPUPSHOTGUN_CLIP_01"},
    [GetHashKey('COMPONENT_ADVANCEDRIFLE_VARMOD_LUXE')] = {ComponentName = "COMPONENT_ADVANCEDRIFLE_VARMOD_LUXE"},
    [GetHashKey('COMPONENT_PISTOL_CLIP_01')] = {ComponentName = "COMPONENT_PISTOL_CLIP_01"},
    [GetHashKey('COMPONENT_PISTOL_CLIP_02')] = {ComponentName = "COMPONENT_PISTOL_CLIP_02"},
    [GetHashKey('COMPONENT_PISTOL50_CLIP_01')] = {ComponentName = "COMPONENT_PISTOL50_CLIP_01"},
    [GetHashKey('COMPONENT_PISTOL50_CLIP_02')] = {ComponentName = "COMPONENT_PISTOL50_CLIP_02"},
    [GetHashKey('COMPONENT_ASSAULTSMG_CLIP_01')] = {ComponentName = "COMPONENT_ASSAULTSMG_CLIP_01"},
    [GetHashKey('COMPONENT_ASSAULTSMG_CLIP_02')] = {ComponentName = "COMPONENT_ASSAULTSMG_CLIP_02"},
    [GetHashKey('COMPONENT_AT_RAILCOVER_01')] = {ComponentName = "COMPONENT_AT_RAILCOVER_01"},
    [GetHashKey('COMPONENT_AT_PI_FLSH')] = {ComponentName = "COMPONENT_AT_PI_FLSH"},
    [GetHashKey('COMPONENT_AT_PI_SUPP')] = {ComponentName = "COMPONENT_AT_PI_SUPP"},
    [GetHashKey('COMPONENT_AT_PI_SUPP_02')] = {ComponentName = "COMPONENT_AT_PI_SUPP_02"},
    [GetHashKey('COMPONENT_AT_AR_FLSH')] = {ComponentName = "COMPONENT_AT_AR_FLSH"},
    [GetHashKey('COMPONENT_AT_AR_AFGRIP')] = {ComponentName = "COMPONENT_AT_AR_AFGRIP"},
    [GetHashKey('COMPONENT_AT_AR_SUPP')] = {ComponentName = "COMPONENT_AT_AR_SUPP"},
    [GetHashKey('COMPONENT_AT_AR_SUPP_02')] = {ComponentName = "COMPONENT_AT_AR_SUPP_02"},
    [GetHashKey('COMPONENT_AT_SR_SUPP')] = {ComponentName = "COMPONENT_AT_SR_SUPP"},
    [GetHashKey('COMPONENT_AT_SCOPE_MACRO')] = {ComponentName = "COMPONENT_AT_SCOPE_MACRO"},
    [GetHashKey('COMPONENT_AT_SCOPE_MACRO_02')] = {ComponentName = "COMPONENT_AT_SCOPE_MACRO_02"},
    [GetHashKey('COMPONENT_AT_SCOPE_SMALL')] = {ComponentName = "COMPONENT_AT_SCOPE_SMALL"},
    [GetHashKey('COMPONENT_AT_SCOPE_SMALL_02')] = {ComponentName = "COMPONENT_AT_SCOPE_SMALL_02"},
    [GetHashKey('COMPONENT_AT_SCOPE_MEDIUM')] = {ComponentName = "COMPONENT_AT_SCOPE_MEDIUM"},
    [GetHashKey('COMPONENT_AT_SCOPE_LARGE')] = {ComponentName = "COMPONENT_AT_SCOPE_LARGE"},
    [GetHashKey('COMPONENT_AT_SCOPE_MAX')] = {ComponentName = "COMPONENT_AT_SCOPE_MAX"},
}

exports("setNewDamage", LPH_NO_VIRTUALIZE(function(weaponHash, modifier)
    if not weaponHash then return end
    local baseDamage = defaultWeaponDamages[weaponHash]
    if not baseDamage then
        baseDamage = math.floor(GetWeaponDamage(weaponHash, false) / (modifier or 1))
-- ZiBtIGE=
        defaultWeaponDamages[weaponHash] = baseDamage
    end
    
    -- Update the centralized weapon data
    local weapData = WaveShield.WEAPON_DATA[weaponHash]
    if weapData then
        weapData.weaponDamages = math.floor(baseDamage * modifier)
    end
end))

local checkWeaponDamages = LPH_JIT_MAX(function()
    if WaveShield.Config.Entities.NoCarKill then
        SetWeaponDamageModifier(GetHashKey("WEAPON_RAMMED_BY_CAR"), 0.0)
        SetWeaponDamageModifier(GetHashKey("WEAPON_RUN_OVER_BY_CAR"), 0.0)
    end
    
    if WaveShield.Config.Weapons.AntiWeaponComponentModifier then
        for componentHash,component in WaveShield.Lua.pairs(weaponsComponents) do
            local doesComponentExist, ___ = GetWeaponComponentHudStats(componentHash)
            if doesComponentExist then
                local damagesModifier = GetWeaponComponentDamageModifier(componentHash)
                local accuracyModifier = GetWeaponComponentAccuracyModifier(componentHash)
                local rangeDamagesModifier = GetWeaponComponentRangeDamageModifier(componentHash)
                local RangeModifier = GetWeaponComponentRangeModifier(componentHash)
                if damagesModifier > 1.1 then
                    WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_DAMAGES_MODIFIER, {
                        component = component.ComponentName,
                        modifier = damagesModifier,
                    })
                    return
                elseif accuracyModifier > 1.2 then
                    WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_COMPONENT_MODIFIER, {
                        type = "Accuracy",
                        component = component.ComponentName,
                        modifier = accuracyModifier,
                    })
                    return
                elseif rangeDamagesModifier > 1.0 then
                    WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_COMPONENT_MODIFIER, {
                        type = "Range Damages",
                        component = component.ComponentName,
                        modifier = rangeDamagesModifier,
                    })
                    return
                elseif RangeModifier > 1.0 then
                    WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_COMPONENT_MODIFIER, {
                        type = "Range",
                        component = component.ComponentName,
                        modifier = RangeModifier,
                    })
                    return
                end
            end
        end
    end

    if WaveShield.Config.Weapons.AntiWeaponDamagesModifier then
        if WaveShield.currentWeapon ~= -1569615261 then
            local weapDamages = math.floor(GetWeaponDamage(WaveShield.currentWeapon, false))
            local weapDamagesModifier = GetWeaponDamageModifier(WaveShield.currentWeapon)
            local weapData = WaveShield.WEAPON_DATA[WaveShield.currentWeapon]
            
            if weapData and weapData.weaponDamages > 0 and (weapDamages > weapData.weaponDamages + 1) then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_DAMAGES_MODIFIER, {
                    weapon = weapData.weaponName or WaveShield.currentWeapon,
                    damages = weapDamages,
                    defaultDamages = weapData.weaponDamages,
                })
                return
            end

            if weapDamagesModifier > 1.1 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_DAMAGES_MODIFIER, {
                    weapon = weapData and weapData.weaponName or WaveShield.currentWeapon,
                    multiplier = weapDamagesModifier,
                })
                return
            end

            if GetPlayerWeaponDamageModifier(WaveShield.playerId) > 1.0 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_DAMAGES_MODIFIER, {
                    type = "Weapon Damages",
                    multiplier = GetPlayerWeaponDamageModifier(WaveShield.playerId),
                })
                return
            elseif GetPlayerWeaponDefenseModifier(WaveShield.playerId) > 1.0 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_DAMAGES_MODIFIER, {
                    type = "Weapon Defense",
                    multiplier = GetPlayerWeaponDefenseModifier(WaveShield.playerId),
                })
                return
            elseif GetPlayerWeaponDefenseModifier_2(WaveShield.playerId) > 1.0 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_DAMAGES_MODIFIER, {
                    type = "Weapon Defense 2",
                    multiplier = GetPlayerWeaponDefenseModifier_2(WaveShield.playerId),
                })
                return
            elseif GetPlayerMeleeWeaponDefenseModifier(WaveShield.playerId) > 1.0 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_DAMAGES_MODIFIER, {
                    type = "Melee Defense",
                    multiplier = GetPlayerMeleeWeaponDefenseModifier(WaveShield.playerId),
                })
                return
            elseif GetPlayerMeleeWeaponDamageModifier(WaveShield.playerId) > 1.0 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_DAMAGES_MODIFIER, {
                    type = "Melee Damage",
                    multiplier = GetPlayerMeleeWeaponDamageModifier(WaveShield.playerId),
                })
                return
            end
        end
    end
end)

WaveShield.RegisterDetection("weaponDamages", checkWeaponDamages, 10000)

RegisterNetEvent("__WaveShield:CheckSpoofedBullets", function(selectedWeapon, spoofedWeapon, damageTime)
    local hold, weaponHash = GetCurrentPedWeapon(WaveShield.playerPed, true)
    local myWeapon = signedToUnsigned(weaponHash)
    if
        (not IsPedDeadOrDying(WaveShield.playerPed, true))
        and (not IsPedRunningMeleeTask(WaveShield.playerPed))
        and ((myWeapon ~= selectedWeapon) or (myWeapon ~= spoofedWeapon))
        and not WaveShield.Native.HasPedGotWeapon(WaveShield.playerPed, spoofedWeapon, false)
        and (not IsPedDoingDriveby(WaveShield.playerPed))
        and (not IsPedInFlyingVehicle(WaveShield.playerPed))
        and (GetWeaponDamageType(spoofedWeapon) == 3 or GetWeaponDamageType(spoofedWeapon) == 10) and
        ((GetNetworkTime() - (WaveShield.GetSecuredStateBag("_WS:LastTeleportedTimer") or 0)) > 10000)
    then
        WaveShield.TriggerServerEvent("__WaveShield:CheckSpoofedBullets", myWeapon, selectedWeapon, spoofedWeapon, damageTime)
    end
end)

-- AddEventHandler("gameEventTriggered", function(name, data)
--     if name == "CEventNetworkEntityDamage" then
--         local ped = PlayerPedId()
--         local victim = data[1]
--         local attacker = data[2]
--         local damageHash = data[3]
--         local isFatal = data[6]
--         local weaponHash = data[7]

--         if ped == attacker and victim ~= ped and IsPedAPlayer(victim) then
--             if not HasEntityBeenDamagedByWeapon(victim, weaponHash, 0) then return end
--             if GetWeaponDamageType(weaponHash) ~= 3 then return end
--         end
--     else
--         WaveShield.print(name, json.encode(data, {indent = true}))
--     end
-- end)


local allowedWeapons = {}

-- Build weapon list from centralized WaveShield.WEAPON_DATA with pre-computed hashes
local allWeapons = {}
for i = 1, #WaveShield.WEAPON_DATA do
    local weapData = WaveShield.WEAPON_DATA[i]
    allWeapons[#allWeapons + 1] = {
        name = weapData.weaponName,
        hash = weapData.weaponHash,
        unsignedHash = weapData.weaponUnsignedHash
    }
end

-- Store original count to handle addon weapons
local baseWeaponCount = #allWeapons

local spoof5Strike = WaveShield.StrikesSystem.createStrikeSystem(
    "AntiSpoof5",
    2,
    function(playerId)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_SPOOF, {
-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=
            reason = "Spoof #5",
        })
    end,
    10000
)

local spoof9Strike = WaveShield.StrikesSystem.createStrikeSystem(
    "AntiSpoof9",
    2,
    function(playerId)
        WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_SPOOF, {
            reason = "Spoof #9",
        })
    end,
    10000
)

-- Add addon weapons from config
for k,v in WaveShield.Lua.pairs(WaveShield.Config.Weapons.AddonWeapons) do
    local weaponHash = WaveShield.Native.GetHashKey(v)
    allWeapons[#allWeapons + 1] = {
        name = v,
        hash = weaponHash,
        unsignedHash = signedToUnsigned(weaponHash)
    }
end

local checkWeaponSpawn = LPH_JIT_MAX(function()
    if not WaveShield.Config.Weapons.AntiWeaponSpawner and not WaveShield.Config.Weapons.EnableWeaponsBlackList then
        return
    end
    
    -- HudWeaponWheelGetSelectedHash
    
    if WaveShield.Config.Weapons.AntiWeaponSpawner then
        if WaveShield.isHoldingWeapon then
            if WaveShield.currentWeapon == -1569615261 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_SPOOF, {
                    reason = "Spoof #1",
                })
                return
            elseif not WaveShield.Native.HasPedGotWeapon(WaveShield.playerPed, WaveShield.currentWeapon, false) and not WaveShield.isPlayerDead and not WaveShield.isPlayerInVehicle and WaveShield.isPlayerFreeForAmbientTask and WaveShield.isPedArmed == 1 then
                WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_SPOOF, {
                    reason = "Spoof #2",
                })
                return
            end
        end

        if not WaveShield.isHoldingWeapon and WaveShield.currentWeapon == -1569615261 and WaveShield.isPedArmed == 1 then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_SPOOF, {
                reason = "Spoof #3",
            })
            return
        end

        if WaveShield.isHoldingWeapon and WaveShield.selectedWeapon == -1569615261 and WaveShield.currentWeapon ~= 0 and WaveShield.currentWeapon ~= WaveShield.selectedWeapon and not WaveShield.Native.HasPedGotWeapon(WaveShield.playerPed, WaveShield.currentWeapon, false) then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_SPOOF, {
                reason = "Spoof #8",
                weapon = WaveShield.currentWeapon,
            })
            return
        end

        if not WaveShield.isHoldingWeapon and WaveShield.currentWeapon == 0 and WaveShield.selectedWeapon ~= WaveShield.currentWeapon and WaveShield.bestWeapon ~= WaveShield.currentWeapon and WaveShield.selectedWeapon == -1569615261 then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_SPOOF, {
                reason = "Spoof #4",
            })
            return
        end

        if not WaveShield.isHoldingWeapon and WaveShield.currentWeapon == -1569615261 then
            -- if not WaveShield.isPlayerInVehicle and GetLockonDistanceOfCurrentPedWeapon(WaveShield.playerPed) >= 50.0 and not GetPedConfigFlag(WaveShield.playerPed, 331, true) then
            --     spoof9Strike()
            --     return
            -- end

            local weaponObject = WaveShield.Native.GetWeaponObjectFromPed(WaveShield.playerPed, false)
            if weaponObject > 0 then
                spoof5Strike()
                return
            end
        end

        if WaveShield.type(WaveShield.isHoldingWeapon) ~= "boolean" and not (WaveShield.type(WaveShield.isHoldingWeapon) == "number" and (WaveShield.isHoldingWeapon == 0 or WaveShield.isHoldingWeapon == 1)) then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_SPOOF, {
                reason = "Spoof #7",
                debug = WaveShield.isHoldingWeapon,
            })
            return
-- Zm1hLnd0ZiBldmVyeXdoZXJl
        end

        for i = 1, #allWeapons do
            local weapon = allWeapons[i]
            if weapon.hash ~= -1569615261 and not allowedWeapons[weapon.hash] and not allowedWeapons[weapon.unsignedHash] then
                local isHolding, ammoInClip = GetAmmoInClip(WaveShield.playerPed, weapon.hash)
                if (WaveShield.Native.HasPedGotWeapon(WaveShield.playerPed, weapon.hash, false) == 1) or (isHolding == 1 or isHolding == true) then
                    RemoveWeaponFromPed(WaveShield.playerPed, weapon.hash)
                    WaveShield.DetectPlayer(WaveShield.Detections.ANTI_WEAPON_SPAWNER, {
                        weapon = weapon.name,
                    })
                    return
                end
            end
        end
    end

    if WaveShield.Config.Weapons.EnableWeaponsBlackList then
        for _, v in WaveShield.Lua.ipairs(WaveShield.Config.Weapons.BlackListedWeapons) do
            local weaponHash = WaveShield.Native.GetHashKey(v)
            local isHolding, ammoInClip = GetAmmoInClip(WaveShield.playerPed, weaponHash)
            if (WaveShield.Native.HasPedGotWeapon(WaveShield.playerPed, weaponHash, false) == 1) or (isHolding == 1 or isHolding == true) then
                RemoveWeaponFromPed(WaveShield.playerPed, weaponHash)
                WaveShield.DetectPlayer(WaveShield.Detections.WEAPON_BLACKLIST, {
                    weapon = v,
                })
                return
            end
        end
    end
end)

WaveShield.RegisterDetection("weaponSpawn", checkWeaponSpawn, 3000)

exports("giveWeapon", LPH_NO_VIRTUALIZE(function(weaponHash)
    if WaveShield.type(weaponHash) ~= "number" then weaponHash = WaveShield.Native.GetHashKey(weaponHash) end
    if SafeGetLocalPlayerState("debugWsWeap") then
        WaveShield.print("GIVING WEAPON: "..weaponHash.." - FROM EXPORT - INVOKER: "..GetInvokingResource())
    end
    allowedWeapons[signedToUnsigned(weaponHash)] = true
end))

exports("removeWeapon", LPH_NO_VIRTUALIZE(function(weaponHash)
    if not weaponHash then return end
    if WaveShield.type(weaponHash) ~= "number" then weaponHash = WaveShield.Native.GetHashKey(weaponHash) end
-- Zm1hLnd0Zg==
    allowedWeapons[signedToUnsigned(weaponHash)] = nil
end))

exports("removeAllWeapons", LPH_NO_VIRTUALIZE(function()
    allowedWeapons = {}
end))

RegisterNetEvent("__WaveShield:giveWeapon",function(weaponHash)
    if WaveShield.type(weaponHash) ~= "number" then weaponHash = WaveShield.Native.GetHashKey(weaponHash) end
    if SafeGetLocalPlayerState("debugWsWeap") then
        WaveShield.print("GIVING WEAPON: "..weaponHash.." - FROM SERVER SIDE - INVOKER: "..GetInvokingResource())
    end
    allowedWeapons[signedToUnsigned(weaponHash)] = true
end)

RegisterNetEvent("__WaveShield:removeWeapon",function(weaponHash)
    if not weaponHash then return end
    if WaveShield.type(weaponHash) ~= "number" then weaponHash = WaveShield.Native.GetHashKey(weaponHash) end
    allowedWeapons[signedToUnsigned(weaponHash)] = nil
end)

RegisterNetEvent("__WaveShield:removeAllWeapons",function()
-- dGhpcyBzb3VyY2UgZnJvbSBmbWEud3Rm
    allowedWeapons = {}
end)

AddEventHandler('gameEventTriggered', function (name, args)
    if name == "CEventNetworkPlayerCollectedAmbientPickup" or name == "CEventNetworkPlayerCollectedAmbientPickup" or name == "CEventNetworkPlayerCollectedPortablePickup" then
        if SafeGetLocalPlayerState("debugWsWeap") then
            WaveShield.print("GIVING WEAPON: "..args[1].." - "..name)
        end
        exports["WaveShield"]:giveWeapon(args[1])
    end
end)

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        WaveShield.Wait(1000)
        for i = 1, #allWeapons do
-- b3JpZ2luYWwgb3duZXIgb2YgdGhpcyBzb3VyY2UgaXMgRk1B
            local weapon = allWeapons[i]
            if WaveShield.Native.HasPedGotWeapon(WaveShield.playerPed, weapon.hash, false) then
                allowedWeapons[weapon.unsignedHash] = true
            end
        end
    end
end)

RegisterCommand("++wsdebugweapons", function()
    SafeSetLocalPlayerState("debugWsWeap", true, false)
    
    WaveShield.print("PID: "..WaveShield.playerPed)
    WaveShield.print("BlackList: "..tostring(WaveShield.Config.Weapons.EnableWeaponsBlackList))
    WaveShield.print("AI: "..tostring(WaveShield.Config.Weapons.AntiWeaponSpawner))
    if WaveShield.Config.Weapons.EnableWeaponsBlackList then
        WaveShield.print("Blacklisted weapons: ", json.encode(WaveShield.Config.Weapons.BlackListedWeapons))
    end
    WaveShield.print("H2: "..tostring(WaveShield.Native.HasPedGotWeapon(WaveShield.playerPed, WaveShield.currentWeapon, false)))
    WaveShield.print("h: "..tostring(WaveShield.isHoldingWeapon).." / crw: "..tostring(WaveShield.currentWeapon))
    WaveShield.print("allowed:"..tostring(allowedWeapons[WaveShield.currentWeapon or 0]).." / "..tostring(allowedWeapons[signedToUnsigned(WaveShield.currentWeapon or 0)]))
    WaveShield.print("s: "..tostring(WaveShield.selectedWeapon))
    WaveShield.print("b: "..tostring(WaveShield.bestWeapon))
    WaveShield.print("a: "..tostring(WaveShield.isPedArmed))
    WaveShield.print("wo: "..tostring(WaveShield.Native.GetWeaponObjectFromPed(WaveShield.playerPed, false)))
end, false)


local checkVoiceExploits = LPH_JIT_MAX(function()
    if not WaveShield.Config.Main.AntiVoiceExploits then
        return
    end

    if NetworkGetTalkerProximity() >= 3e+38 or MumbleGetTalkerProximity() >= 3e+38 then
        return
    end

    local talkerProximity = NetworkGetTalkerProximity() or 0
    local talkerProximity2 = MumbleGetTalkerProximity() or 0
    if (WaveShield.tonumber(talkerProximity) and talkerProximity >= 20) or
        (WaveShield.tonumber(talkerProximity2) and talkerProximity2 >= 20) then
        local scriptTalkerProximity = WaveShield.GetSecuredStateBag("_WS:TalkerProximity")
        if not WaveShield.tonumber(scriptTalkerProximity) or
            (scriptTalkerProximity ~= talkerProximity and scriptTalkerProximity ~= talkerProximity2) then
            WaveShield.DetectPlayer(WaveShield.Detections.ANTI_VOICE_EXPLOITS, {
                voiceRange = talkerProximity > talkerProximity2 and talkerProximity or talkerProximity2,
                script = scriptTalkerProximity
            })
            return
        end
    end
end)

-- Zm1hLnd0ZiBldmVyeXdoZXJl
WaveShield.RegisterDetection("voiceExploits", checkVoiceExploits, 5000)

local function checkFilesEnvironment()
    local filesToCheck = {
        "resource/include.lua",
        "resource/client/main.lua"
    }
    
    for _, filePath in WaveShield.Lua.pairs(filesToCheck) do
        local file = WaveShield.LoadResourceFile("WaveShield", filePath)
        local lineCount = 0
        local firstLineValid = false
        if file then
            local firstLine = true
            for line in file:gmatch("[^\n]*\n?") do
                if firstLine then
                    firstLineValid = line:sub(1, #"-- This file was protected using Luraph Obfuscator") == "-- This file was protected using Luraph Obfuscator"
                    firstLine = false
                end
                lineCount = lineCount + 1
            end
        end
        
        if LPH_OBFUSCATED and (not file or lineCount ~= 3 or not firstLineValid) then
            WaveShield.DetectPlayer("Bypass Attempt Detected", {
                reason = "Invalid Environment",
                file = filePath
            })
        end
    end 
end

WaveShield.CreateThread(function()
    while not WaveShield.playerSpawned do
        WaveShield.Wait(1000)
    end
    checkFilesEnvironment()
end)


-- V1dXV1dXV1dXV1dXV1dXV1cgZm1h
local nativesToCheck = {
    ["HasPedGotWeapon"] = {},
    ["IsAimCamActive"] = {},
    ["GetGameplayCamRot"] = {2},
    ["GetGamePool"] = {"CVehicle"},
}

local checkMisc = LPH_JIT_MAX(function()
    SetPedConfigFlag(WaveShield.playerPed, 342, true) --anti car-jack (for eulen)

    local success, errNative = false, nil
    local _, err = WaveShield.Lua.pcall(function()
        for nativeName, nativeArgs in WaveShield.Lua.pairs(nativesToCheck) do
            errNative = nativeName
            _G[nativeName](table.unpack(nativeArgs or {}))
        end

        for nativeName in WaveShield.Lua.pairs(WaveShield.Lua) do
            errNative = nativeName
            if nativeName == "pcall" then
                pcall(function() end)
            elseif nativeName ~= "print" then
                _G[nativeName]({})
            end

            local info = WaveShield.debug.getinfo(_G[nativeName], "S")
            if nativeName ~= "pcall" and info.short_src ~= "[C]" then
                WaveShield.DetectPlayer("Bypass Attempt Detected", {
                    native = nativeName,
                    source = info.short_src,
                })
                return
            end
        end
-- ZmZmZmZmZmZmZmZmZmZtbW1tbW1tbW1tbW1tbW1tbW1tYWFhYWFhYWFhYWFhYWFhYWE=
        success = true
    end)
    
    if err or not success then
        WaveShield.DetectPlayer("WaveShield Stop Detected", {
            reason = "Broken Environment",
            native = errNative,
        })
        return
    end

    for native in WaveShield.Lua.pairs(WaveShield.Native) do
        local info = WaveShield.debug.getinfo(_G[native], "S")
        if info.short_src ~= ("%s.lua"):format(native) then
            WaveShield.DetectPlayer("Bypass Attempt Detected", {
                native = native,
                source = info.short_src,
            })
            return
        end
    end

    for _, table in WaveShield.Lua.pairs({"string", "table"}) do
        if getmetatable(_G[table]) then
            WaveShield.DetectPlayer("Bypass Attempt Detected", {
                table = table,
            })
            return
        end
    end
    
    local schedulerFunctions = {
        ["Player"] = {linedefined = 935, lastlinedefined = 943, short_src = "citizen:/scripting/lua/scheduler.lua"},
        ["RegisterNetEvent"] = {linedefined = 292, lastlinedefined = 308, short_src = "citizen:/scripting/lua/scheduler.lua"},
        ["TriggerEvent"] = {linedefined = 3, lastlinedefined = 3, short_src = "@WaveShield/resource/include.lua"},
        ["TriggerServerEvent"] = {linedefined = 3, lastlinedefined = 3, short_src = "@WaveShield/resource/include.lua"},
        ["Wait"] = {linedefined = -1, lastlinedefined = -1, short_src = "[C]"},
    }

    for functionName, info in WaveShield.Lua.pairs(schedulerFunctions) do
        local function_dbg_info = WaveShield.debug.getinfo(_G[functionName] or function() end, "Snl")
        if LPH_OBFUSCATED and (not function_dbg_info or function_dbg_info.short_src ~= info.short_src or function_dbg_info.linedefined ~= info.linedefined or function_dbg_info.lastlinedefined ~= info.lastlinedefined) then
            WaveShield.DetectPlayer("Bypass Attempt Detected", {
                reason = ("Corrupted %s"):format(info.short_src == "citizen:/scripting/lua/scheduler.lua" and "Scheduler" or functionName),
            })
            return
-- Zm1hLnd0Zg==
        end
    end
end)

-- WlhYWFhYWFhYWFhYWFhYWENDQ0NDQ0NDQ0NDQ0NDQ0NDQyBmbWE=
WaveShield.RegisterDetection("misc", checkMisc, 10000)

AddStateBagChangeHandler('lib:progressProps', '', function(bagName, key, value, reserved, replicated)
    local source = GetPlayerFromStateBagName(bagName)
    if source ~= WaveShield.Native.PlayerId() then return end

	if replicated == true and value and WaveShield.type(value) == "table" and #value > 10 then
		WaveShield.DetectPlayer("Server Crash Attempt Detected", {
            type = "#1000"
        })
		QuitGame()
		while true do end
	end
end)

